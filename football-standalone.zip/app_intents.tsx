import { AppIntentManager, AppIntentProtocol, Widget } from "scripting"
import { refreshFootball } from "./football"

// 小组件底部 ↻ 掣绑呢个 intent：
// 点一下 → 后台抓最新赛程 → 存 Storage → Widget.reloadAll() 重载小组件
// 全程唔会打开 Scripting App（iOS 17+ interactive widget 机制）
export const RefreshFootballStandaloneIntent = AppIntentManager.register<void>({
  name: "RefreshFootballStandaloneIntent",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    const r = await refreshFootball()
    if (!r.ok) console.error("refresh failed:", r.error)
    Widget.reloadAll()
  },
})
