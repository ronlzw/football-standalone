import { AppIntentManager, AppIntentProtocol, Widget } from "scripting"
import { refreshBroadcastIfStale, refreshFootball, refreshPrevMatches } from "./football"
import { prevViewKey, refreshingAtKey, tvViewKey } from "./const"

// 小组件底部 ↻ 掣绑呢个 intent：
// 点一下 → 写手动刷新时间戳＋重载（底部时间变 "…"）→ 后台全刷新 → 清时间戳＋重载
// 全程唔会打开 Scripting App（iOS 17+ interactive widget 机制）；
// 时间戳 30 秒过期（WidgetView 凭 isRefreshingFresh 判断），intent 中途被系统杀咗都唔会永远卡住 "…"
export const RefreshFootballStandaloneIntent = AppIntentManager.register<void>({
  name: "RefreshFootballStandaloneIntent",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    Storage.set(refreshingAtKey, Date.now())
    Widget.reloadAll()
    try {
      const r = await refreshFootball()
      if (!r.ok) console.error("refresh failed:", r.error)
    } finally {
      Storage.set(refreshingAtKey, 0)
      Widget.reloadAll()
    }
  },
})

// 小组件右上角日期掣绑呢个 intent（1.0.13，主版 v1.1.85 同款）：
// 点一下 → 之前八场过旧（24 小时）就先抓一次 → 翻转之前八场视图开关 → Widget.reloadAll() 重载小组件
// 再点一下即返现时八场；之前场次 24 小时内已抓就即刻翻，唔等网络
export const TogglePrevFootballStandaloneIntent = AppIntentManager.register<void>({
  name: "TogglePrevFootballStandaloneIntent",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    const r = await refreshPrevMatches()
    if (!r.ok) console.error("prev refresh failed:", r.error)
    const cur = Storage.get<boolean>(prevViewKey) ?? false
    Storage.set(prevViewKey, !cur)
    // 1.0.21：同电视视图互斥——开之前八场就关电视视图
    if (!cur) Storage.set(tvViewKey, false)
    Widget.reloadAll()
  },
})

// 小组件底部 TV 掣绑呢个 intent（1.0.21，主版 v1.1.97 同款）：
// 直播表 6 小时内未更新就先抓一次（唔会触发足球全刷新）→ 翻转电视视图开关 → Widget.reloadAll() 重载
// 再点一下即返现时八场；直播表 6 小时内已抓就即刻翻，唔等网络；开电视就关之前八场（互斥）
export const ToggleTvFootballStandaloneIntent = AppIntentManager.register<void>({
  name: "ToggleTvFootballStandaloneIntent",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    await refreshBroadcastIfStale()
    const cur = Storage.get<boolean>(tvViewKey) ?? false
    Storage.set(tvViewKey, !cur)
    if (!cur) Storage.set(prevViewKey, false)
    Widget.reloadAll()
  },
})
