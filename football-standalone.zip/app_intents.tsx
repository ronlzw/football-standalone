import { AppIntentManager, AppIntentProtocol, Widget } from "scripting"
import { refreshFootball, refreshPrevMatches } from "./football"
import { prevViewKey, refreshingAtKey } from "./const"

// 小组件底部 ↻ 掣绑呢个 intent：
// 点一下 → 写手动刷新时间戳＋重载（底部时间变 "…"）→ 后台全刷新 → 清时间戳＋重载
// 全程唔会打开 Scripting App（iOS 17+ interactive widget 机制）；
// 时间戳 30 秒过期（WidgetView 凭 isRefreshingFresh 判断），intent 中途被系统杀咗都唔会永远卡住 "…"
export const RefreshFootballStandaloneIntent = AppIntentManager.register<void>({
  name: "RefreshFootballStandaloneIntent",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    Storage.set(refreshingAtKey, Date.now())
    Widget.reloadAll()
    try {
      const r = await refreshFootball()
      if (!r.ok) console.error("refresh failed:", r.error)
    } finally {
      Storage.set(refreshingAtKey, 0)
      Widget.reloadAll()
    }
  },
})

// 小组件右上角日期掣绑呢个 intent（1.0.13，主版 v1.1.85 同款）：
// 点一下 → 之前八场过旧（24 小时）就先抓一次 → 翻转之前八场视图开关 → Widget.reloadAll() 重载小组件
// 再点一下即返现时八场；之前场次 24 小时内已抓就即刻翻，唔等网络
export const TogglePrevFootballStandaloneIntent = AppIntentManager.register<void>({
  name: "TogglePrevFootballStandaloneIntent",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    const r = await refreshPrevMatches()
    if (!r.ok) console.error("prev refresh failed:", r.error)
    const cur = Storage.get<boolean>(prevViewKey) ?? false
    Storage.set(prevViewKey, !cur)
    Widget.reloadAll()
  },
})
