import { AppIntentManager, AppIntentProtocol, Widget } from "scripting"
import { refreshFootball } from "./football"
import { prevViewKey } from "./const"

// 小组件底部 ↻ 掣绑呢个 intent：
// 点一下 → 后台抓最新赛程 → 存 Storage → Widget.reloadAll() 重载小组件
// 全程唔会打开 Scripting App（iOS 17+ interactive widget 机制）
export const RefreshFootballStandaloneIntent = AppIntentManager.register<void>({
  name: "RefreshFootballStandaloneIntent",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    const r = await refreshFootball()
    if (!r.ok) console.error("refresh failed:", r.error)
    Widget.reloadAll()
  },
})

// 小组件右上角日期掣绑呢个 intent（1.0.13，主版 v1.1.85 同款）：
// 点一下 → 翻转之前八场视图开关 → Widget.reloadAll() 重载小组件
// 再点一下即返现时八场；开关本身唔会触发抓取，之前八场数据由刷新时一并抓返嚟
export const TogglePrevFootballStandaloneIntent = AppIntentManager.register<void>({
  name: "TogglePrevFootballStandaloneIntent",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    const cur = Storage.get<boolean>(prevViewKey) ?? false
    Storage.set(prevViewKey, !cur)
    Widget.reloadAll()
  },
})
