export const footballKey = "footballStandaloneData"
/** 自定义关注球队（页面顶部填写）：存用户输入嘅原文，每行一间；冇存／空即用默认 10 间 */
export const teamsKey = "footballStandaloneTeams"
/** 国家队设定（排名范围＋单选）：JSON {cutoff, picks[]}；冇存即默认前 40、零单选 */
export const ntKey = "footballStandaloneNT"
export const derbyKey = "footballStandaloneDerbies"
/** 之前八场视图开关（右上角掣切换用）：true = 显示之前八场，false = 显示现时八场；冇存即关 */
export const prevViewKey = "footballStandalonePrevView"
/** 透明壁纸模式开关（设置页 Toggle）：布尔值；冇存即关 */
export const transparentKey = "footballStandaloneTransparent"
/** 透明模式浅色反色开关：true = 浅色用白字（反色），false = 浅色黑字（主题色，默认） */
export const transparentLightInverseKey = "footballStandaloneTransparentLightInverse"
/** 透明模式深色反色开关：true = 深色用黑字（反色），false = 深色白字（主题色，默认） */
export const transparentDarkInverseKey = "footballStandaloneTransparentDarkInverse"

/** 手机时区（Intl 读机身设定，解析唔到就返空字串，调用方会省略 tz 参数） */
export function phoneTimeZone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone ?? ""
  } catch {
    return ""
  }
}

/** 手机本地日期 YYYY-MM-DD（en-CA 格式，唔指定时区即系手机时区） */
export function localYMD(d: Date): string {
  return new Intl.DateTimeFormat("en-CA", {
    year: "numeric", month: "2-digit", day: "2-digit",
  }).format(d)
}

export type MatchTeam = { name: string; code: string; logo: string }
export type Match = {
  id: number
  league: string
  /** FotMob 联赛 logo（leaguelogo/{primaryId}.png），旧缓存可能冇 */
  leagueLogo: string
  home: MatchTeam
  away: MatchTeam
  /** ISO 时间（手机本地时区 offset） */
  date: string
  /** NS / LIVE / FT / AET / PEN / CANC */
  status: string
  elapsed: number | null
  /** 半场休息（FotMob liveTime.short == "HT"；VPS 旧数据／缓存冇呢个字段即当唔系） */
  ht?: boolean
  /** 点球比分（主／客；净 PEN 完场同进行中点球先有，FotMob home/away.penScore；旧缓存冇即当无） */
  ph?: number | null
  pa?: number | null
  gh: number | null
  ga: number | null
}
export type FootballData = {
  /** 手机本地日期 YYYY-MM-DD */
  date: string
  /** 上次成功刷新时间（失败唔会郁佢：底部「↻ 时间」同过期判断都以呢个为准） */
  fetchedAt: number
  /** 上次尝试刷新时间（不论成败，v1.1.23 起） */
  lastAttemptAt?: number
  matches: Match[]
  /** 之前八场（紧贴现时显示首场之前、最近已完场；旧缓存冇呢个字段即当空） */
  prevMatches?: Match[]
  lastError?: string
}

export const LIVE = new Set(["LIVE"])
export const DONE = new Set(["FT", "AET", "PEN"])
export const OFF = new Set(["CANC"])

/** 刷新档位（v1.1.23）：按缓存中今日比赛状态决定几耐算过期 + 几耐后叫系统重画 */
export type RefreshTier = { name: string; staleMs: number; reloadMin: number }
export function refreshTier(data: FootballData | null, now = Date.now()): RefreshTier {
  // 无缓存：当普通档（run 本身会因为无缓存而抓）
  if (data == null) return { name: "normal", staleMs: 15 * 60 * 1000, reloadMin: 15 }
  const today = (data.matches ?? []).filter((m) => isToday(m.date))
  // 有进行中比赛：最密
  if (today.some((m) => LIVE.has(m.status)))
    return { name: "live", staleMs: 2 * 60 * 1000, reloadMin: 3 }
  // 30 分钟内有未开波比赛开球（或啱啱开波 15 分钟内但状态未转 LIVE）：次密
  const upcoming = today
    .filter((m) => !DONE.has(m.status) && !OFF.has(m.status))
    .map((m) => new Date(m.date).getTime())
    .filter((t) => Number.isFinite(t))
  if (upcoming.length > 0) {
    const minsToKo = (Math.min(...upcoming) - now) / 60000
    if (minsToKo <= 30 && minsToKo >= -15)
      return { name: "pre-match", staleMs: 5 * 60 * 1000, reloadMin: 5 }
  }
  // 今日无比赛，或者全部完场/取消：最疏
  if (today.length === 0 || today.every((m) => DONE.has(m.status) || OFF.has(m.status)))
    return { name: "idle", staleMs: 60 * 60 * 1000, reloadMin: 60 }
  // 其他（今日仲有比赛但未就开波）：保持现状
  return { name: "normal", staleMs: 15 * 60 * 1000, reloadMin: 15 }
}

const WEEK = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"]
/** "9月30日 周三"（入 YYYY-MM-DD） */
export function dateTitle(ymd: string): string {
  const [y, mo, d] = ymd.split("-").map(Number)
  const dt = new Date(y, mo - 1, d)
  return `${mo}月${d}日 ${WEEK[dt.getDay()]}`
}

export type KoParts = { date: string; time: string; time12: string; weekday: string }
/** 开球时间：{ "9月30日", "19:00", "下午7:00", "周三" } */
export function koParts(iso: string): KoParts {
  const d = new Date(iso)
  const h = d.getHours()
  const hh = String(h).padStart(2, "0")
  const mm = String(d.getMinutes()).padStart(2, "0")
  const ap = h < 12 ? "上午" : "下午"
  const h12 = h % 12 === 0 ? 12 : h % 12
  return {
    date: `${d.getMonth() + 1}月${d.getDate()}日`,
    time: `${hh}:${mm}`,
    time12: `${ap}${h12}:${mm}`,
    weekday: WEEK[d.getDay()],
  }
}

/** "下午4:18"（更新时间用，12小时制，v1.1.47 起跟 FotMob；同 koParts.time12 同一格式） */
export function clockZh(ts: number): string {
  const d = new Date(ts)
  const h = d.getHours()
  const mm = String(d.getMinutes()).padStart(2, "0")
  const ap = h < 12 ? "上午" : "下午"
  const h12 = h % 12 === 0 ? 12 : h % 12
  return `${ap}${h12}:${mm}`
}

/** ISO 时间系咪今日（电话本地日期） */
export function isToday(iso: string): boolean {
  const d = new Date(iso)
  const n = new Date()
  return (
    d.getFullYear() === n.getFullYear() &&
    d.getMonth() === n.getMonth() &&
    d.getDate() === n.getDate()
  )
}

/** —— 小组件语言（2026-10-28 语言修复；原有 koParts/clockZh/dateTitle 保持不变，页面继续用） —— */
export type WidgetLoc = "hans" | "hk" | "tw" | "en"
const WEEK_HANT = ["週日", "週一", "週二", "週三", "週四", "週五", "週六"]
export const WIDGET_WORDS: Record<WidgetLoc, { live: string; done: string; off: string; today: string; noMatch: string; loadFail: string; prevLabel: string; prevNoMatch: string }> = {
  hans: { live: "进行中", done: "完场", off: "延期", today: "今天", noMatch: "今日无比赛", loadFail: "赛程加载失败", prevLabel: "之前八场", prevNoMatch: "之前无已完场" },
  hk: { live: "進行中", done: "完場", off: "延期", today: "今天", noMatch: "今日無比賽", loadFail: "賽程載入失敗", prevLabel: "之前八場", prevNoMatch: "之前無已完場" },
  tw: { live: "進行中", done: "完場", off: "延期", today: "今天", noMatch: "今日無比賽", loadFail: "賽程載入失敗", prevLabel: "之前八場", prevNoMatch: "之前無已完場" },
  en: { live: "Live", done: "Full-Time", off: "Postponed", today: "Today", noMatch: "No matches today", loadFail: "Couldn't load fixtures", prevLabel: "Previous 8", prevNoMatch: "No previous results" },
}
/** 小组件标题日期：跟手机语言（en 用 Intl 短格式，失败回退简体格式） */
export function widgetDateTitle(ymd: string, loc: WidgetLoc): string {
  const [y, mo, d] = ymd.split("-").map(Number)
  const dt = new Date(y, mo - 1, d)
  if (loc === "en") {
    try { return new Intl.DateTimeFormat("en", { weekday: "short", month: "short", day: "numeric" }).format(dt) } catch { /* fallthrough */ }
  }
  const week = loc === "hans" ? WEEK[dt.getDay()] : WEEK_HANT[dt.getDay()]
  return `${mo}月${d}日 ${week}`
}
/** 小组件开球星期／12 小时时间：跟手机语言（en 用 Intl，失败回退 koParts） */
export function widgetKo(iso: string, loc: WidgetLoc): { weekday: string; time12: string } {
  const ko = koParts(iso)
  if (loc === "en") {
    try {
      const d = new Date(iso)
      return {
        weekday: new Intl.DateTimeFormat("en", { weekday: "short" }).format(d),
        time12: new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit", hour12: true }).format(d),
      }
    } catch { return { weekday: ko.weekday, time12: ko.time12 } }
  }
  if (loc === "hans") return { weekday: ko.weekday, time12: ko.time12 }
  return { weekday: ko.weekday.replace("周", "週"), time12: ko.time12 }
}
/** 小组件底部更新时间：跟手机语言（en 用 Intl，失败回退 clockZh） */
export function widgetClock(ts: number, loc: WidgetLoc): string {
  if (loc === "en") {
    try { return new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit", hour12: true }).format(new Date(ts)) } catch { return clockZh(ts) }
  }
  return clockZh(ts)
}

/** FotMob 比赛页（独立版：tz 跟手机时区，冇手机时区就省略参数等 FotMob 自己判断；有装 FotMob App 会经 universal link 入 App 嗰场，冇装就开网页版） */
export function fotmobUrl(m: Match): string {
  const tz = phoneTimeZone()
  return tz
    ? `https://www.fotmob.com/match/${m.id}?tz=${tz}`
    : `https://www.fotmob.com/match/${m.id}`
}
