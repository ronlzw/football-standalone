export const footballKey = "footballStandaloneData"
/** 自定义关注球队（页面顶部填写）：存用户输入嘅原文，每行一间；冇存／空即用默认 10 间 */
export const teamsKey = "footballStandaloneTeams"
/** 国家队设定（排名范围＋单选）：JSON {cutoff, picks[]}；冇存即默认前 40、零单选 */
export const ntKey = "footballStandaloneNT"
export const derbyKey = "footballStandaloneDerbies"
/** App 页写低嘅 Scripting 语言设定（"hans" | "hk" | "tw" | "en"；1.0.20 起小组件读佢，唔直接读进程 locale——小组件进程 locale 系 iPhone 系统语言，唔等于 Scripting 设定） */
export const langKey = "footballStandaloneLang"
/** 之前八场视图开关（右上角掣切换用）：true = 显示之前八场，false = 显示现时八场；冇存即关 */
export const prevViewKey = "footballStandalonePrevView"
/** 之前八场上次抓取时间（毫秒；refreshFootball／切换 intent 共用，24 小时内唔重抓） */
export const prevFetchedAtKey = "footballStandalonePrevAt"
/** 电视直播视图开关（1.0.21，主版 v1.1.97 同款）：true = 显示电视视图，false = 显示现时八场；冇存即关；同之前八场视图互斥 */
export const tvViewKey = "footballStandaloneTvView"
/** 远程直播表缓存（1.0.21）：Hark 每日写去 Drive、Fry 同步去 VPS 公开链接嘅 football-broadcast.json，widget 抓返嚟存呢度 */
export const broadcastRemoteKey = "footballStandaloneBroadcastRemote"
/** 远程直播表（1.0.21，主版 v1.1.97 同款）：Hark 每日 04:00 查 livesoccertv 写 Drive，Fry hook 每日 05:xx 同步去 VPS */
export const REMOTE_BROADCAST_URL = "https://yt.adi-ronnie.top/api/football-broadcast.json"
/** 直播表几耐算旧（1.0.21）：Hark 每日先更新一次，6 小时内唔重抓；413KB 档唔可以每次刷新都攞 */
export const BROADCAST_STALE_MS = 6 * 60 * 60 * 1000
/** 手动刷新进行中时间戳（毫秒；Refresh intent 开头写，finally 清 0；小组件底部 30 秒内显示 "…"） */
export const refreshingAtKey = "footballStandaloneRefreshingAt"
/** 透明壁纸模式开关（设置页 Toggle）：布尔值；冇存即关 */
export const transparentKey = "footballStandaloneTransparent"
/** 透明模式浅色反色开关：true = 浅色用白字（反色），false = 浅色黑字（主题色，默认） */
export const transparentLightInverseKey = "footballStandaloneTransparentLightInverse"
/** 透明模式深色反色开关：true = 深色用黑字（反色），false = 深色白字（主题色，默认） */
export const transparentDarkInverseKey = "footballStandaloneTransparentDarkInverse"

/** 手机时区（Intl 读机身设定，解析唔到就返空字串，调用方会省略 tz 参数） */
export function phoneTimeZone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone ?? ""
  } catch {
    return ""
  }
}

/** 手机本地日期 YYYY-MM-DD（en-CA 格式，唔指定时区即系手机时区） */
export function localYMD(d: Date): string {
  return new Intl.DateTimeFormat("en-CA", {
    year: "numeric", month: "2-digit", day: "2-digit",
  }).format(d)
}

export type MatchTeam = { name: string; code: string; logo: string }
export type Match = {
  id: number
  league: string
  /** FotMob 联赛 logo（leaguelogo/{primaryId}.png），旧缓存可能冇 */
  leagueLogo: string
  home: MatchTeam
  away: MatchTeam
  /** ISO 时间（手机本地时区 offset） */
  date: string
  /** NS / LIVE / FT / AET / PEN / CANC */
  status: string
  elapsed: number | null
  /** 半场休息（FotMob liveTime.short == "HT"；VPS 旧数据／缓存冇呢个字段即当唔系） */
  ht?: boolean
  /** 点球比分（主／客；净 PEN 完场同进行中点球先有，FotMob home/away.penScore；旧缓存冇即当无） */
  ph?: number | null
  pa?: number | null
  gh: number | null
  ga: number | null
}
export type FootballData = {
  /** 手机本地日期 YYYY-MM-DD */
  date: string
  /** 上次成功刷新时间（失败唔会郁佢：底部「↻ 时间」同过期判断都以呢个为准） */
  fetchedAt: number
  /** 上次尝试刷新时间（不论成败，v1.1.23 起） */
  lastAttemptAt?: number
  matches: Match[]
  /** 之前八场（紧贴现时显示首场之前、最近已完场；旧缓存冇呢个字段即当空） */
  prevMatches?: Match[]
  lastError?: string
}

export const LIVE = new Set(["LIVE"])
export const DONE = new Set(["FT", "AET", "PEN"])
export const OFF = new Set(["CANC"])

/** 刷新档位（v1.1.23）：按缓存中今日比赛状态决定几耐算过期 + 几耐后叫系统重画 */
export type RefreshTier = { name: string; staleMs: number; reloadMin: number }
export function refreshTier(data: FootballData | null, now = Date.now()): RefreshTier {
  // 无缓存：当普通档（run 本身会因为无缓存而抓）
  if (data == null) return { name: "normal", staleMs: 15 * 60 * 1000, reloadMin: 15 }
  const today = (data.matches ?? []).filter((m) => isToday(m.date))
  // 有进行中比赛：最密
  if (today.some((m) => LIVE.has(m.status)))
    return { name: "live", staleMs: 2 * 60 * 1000, reloadMin: 3 }
  // 30 分钟内有未开波比赛开球（或开波 120 分钟内但状态未转 LIVE，FotMob 数据滞后）：次密；
  // 开波超过 120 分钟仲系 NS 嘅场（延期未更新／数据缺口）唔计入最近开球，免得佢遮住就开波嗰场
  const upcoming = today
    .filter((m) => !DONE.has(m.status) && !OFF.has(m.status))
    .map((m) => (new Date(m.date).getTime() - now) / 60000)
    .filter((mins) => Number.isFinite(mins) && mins >= -120)
  if (upcoming.length > 0) {
    const minsToKo = Math.min(...upcoming)
    if (minsToKo <= 30)
      return { name: "pre-match", staleMs: 5 * 60 * 1000, reloadMin: 5 }
  }
  // 今日无比赛，或者全部完场/取消：最疏
  if (today.length === 0 || today.every((m) => DONE.has(m.status) || OFF.has(m.status)))
    return { name: "idle", staleMs: 60 * 60 * 1000, reloadMin: 60 }
  // 其他（今日仲有比赛但未就开波）：保持现状
  return { name: "normal", staleMs: 15 * 60 * 1000, reloadMin: 15 }
}

/** 手动刷新标志新鲜期（毫秒）：intent 中途被系统杀咗、finally 跑唔到时，底部 "…" 最多显示咁耐 */
export const REFRESHING_FRESH_MS = 30 * 1000
/** 手动刷新标志系咪新鲜（null／0／超过 30 秒即当唔系） */
export function isRefreshingFresh(at: number | null | undefined, now = Date.now()): boolean {
  return at != null && Number.isFinite(at) && at > 0 && now - at < REFRESHING_FRESH_MS
}

const WEEK = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"]
/** "9月30日 周三"（入 YYYY-MM-DD） */
export function dateTitle(ymd: string): string {
  const [y, mo, d] = ymd.split("-").map(Number)
  const dt = new Date(y, mo - 1, d)
  return `${mo}月${d}日 ${WEEK[dt.getDay()]}`
}

export type KoParts = { date: string; time: string; time12: string; weekday: string }
/** 开球日同今日相差几日（电话本地日期；负数即系过去） */
export function koDayDiff(iso: string): number {
  const d = new Date(iso)
  const n = new Date()
  const dayMs = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime()
  return Math.round((dayMs(d) - dayMs(n)) / 86400000)
}
/** 开球时间：{ "9月30日", "19:00", "下午7:00", "周三" }；
 *  weekday 规则（用户 2026-11-15 定）：diff 1 → 明天、2 → 后天、0／3–6 → 星期几、<0 或 ≥7 → 日期；
 *  明天／后天优先过星期几，免得「星期一」令人以为系今个星期一（下星期一要写日期嘅旧规则照旧） */
export function koParts(iso: string): KoParts {
  const d = new Date(iso)
  const h = d.getHours()
  const hh = String(h).padStart(2, "0")
  const mm = String(d.getMinutes()).padStart(2, "0")
  const ap = h < 12 ? "上午" : "下午"
  const h12 = h % 12 === 0 ? 12 : h % 12
  const date = `${d.getMonth() + 1}月${d.getDate()}日`
  const diff = koDayDiff(iso)
  const weekday = diff === 1 ? "明天" : diff === 2 ? "后天" : diff >= 0 && diff < 7 ? WEEK[d.getDay()] : date
  return {
    date,
    time: `${hh}:${mm}`,
    time12: `${ap}${h12}:${mm}`,
    weekday,
  }
}

/** "下午4:18"（更新时间用，12小时制，v1.1.47 起跟 FotMob；同 koParts.time12 同一格式） */
export function clockZh(ts: number): string {
  const d = new Date(ts)
  const h = d.getHours()
  const mm = String(d.getMinutes()).padStart(2, "0")
  const ap = h < 12 ? "上午" : "下午"
  const h12 = h % 12 === 0 ? 12 : h % 12
  return `${ap}${h12}:${mm}`
}

/** ISO 时间系咪今日（电话本地日期） */
export function isToday(iso: string): boolean {
  const d = new Date(iso)
  const n = new Date()
  return (
    d.getFullYear() === n.getFullYear() &&
    d.getMonth() === n.getMonth() &&
    d.getDate() === n.getDate()
  )
}

/** —— 小组件语言（2026-10-28 语言修复；原有 koParts/clockZh/dateTitle 保持不变，页面继续用） —— */
export type WidgetLoc = "hans" | "hk" | "tw" | "en"
const WEEK_HANT = ["週日", "週一", "週二", "週三", "週四", "週五", "週六"]
export const WIDGET_WORDS: Record<WidgetLoc, { live: string; done: string; off: string; today: string; noMatch: string; loadFail: string; prevLabel: string; prevNoMatch: string; tvNoData: string }> = {
  hans: { live: "进行中", done: "完场", off: "延期", today: "今天", noMatch: "今日无比赛", loadFail: "赛程加载失败", prevLabel: "之前八场", prevNoMatch: "之前无已完场", tvNoData: "暂无直播资料" },
  hk: { live: "進行中", done: "完場", off: "延期", today: "今天", noMatch: "今日無比賽", loadFail: "賽程載入失敗", prevLabel: "之前八場", prevNoMatch: "之前無已完場", tvNoData: "暫無直播資料" },
  tw: { live: "進行中", done: "完場", off: "延期", today: "今天", noMatch: "今日無比賽", loadFail: "賽程載入失敗", prevLabel: "之前八場", prevNoMatch: "之前無已完場", tvNoData: "暫無直播資料" },
  en: { live: "Live", done: "Full-Time", off: "Postponed", today: "Today", noMatch: "No matches today", loadFail: "Couldn't load fixtures", prevLabel: "Previous 8", prevNoMatch: "No previous results", tvNoData: "No broadcast info" },
}
/** 小组件标题日期：跟手机语言（en 用 Intl 短格式，失败回退简体格式） */
export function widgetDateTitle(ymd: string, loc: WidgetLoc): string {
  const [y, mo, d] = ymd.split("-").map(Number)
  const dt = new Date(y, mo - 1, d)
  if (loc === "en") {
    try { return new Intl.DateTimeFormat("en", { weekday: "short", month: "short", day: "numeric" }).format(dt) } catch { /* fallthrough */ }
  }
  const week = loc === "hans" ? WEEK[dt.getDay()] : WEEK_HANT[dt.getDay()]
  return `${mo}月${d}日 ${week}`
}
/** 小组件开球星期／12 小时时间：跟手机语言（en 用 Intl，失败回退 koParts）；
 *  同 koParts 一样，7 日以外写日期唔写星期几（en 用 "Nov 12" 格式）；
 *  1.0.21 明天／后天（用户 2026-11-15 定）：diff 1 → 明天／Tomorrow、2 → 后天／Day after tomorrow；
 *  hk／tw「明天」不变、「后天」→「後天」（现行 replace("周","週") 转唔到后字，要显式处理）；
 *  en 冇 Intl 写法，写死字串。 */
export function widgetKo(iso: string, loc: WidgetLoc): { weekday: string; time12: string } {
  const ko = koParts(iso)
  if (loc === "en") {
    try {
      const d = new Date(iso)
      const time12 = new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit", hour12: true }).format(d)
      const diff = koDayDiff(iso)
      if (diff === 1) return { weekday: "Tomorrow", time12 }
      if (diff === 2) return { weekday: "Day after tomorrow", time12 }
      if (diff < 0 || diff >= 7) {
        return { weekday: new Intl.DateTimeFormat("en", { month: "short", day: "numeric" }).format(d), time12 }
      }
      return {
        weekday: new Intl.DateTimeFormat("en", { weekday: "short" }).format(d),
        time12,
      }
    } catch { return { weekday: ko.weekday, time12: ko.time12 } }
  }
  if (loc === "hans") return { weekday: ko.weekday, time12: ko.time12 }
  return { weekday: ko.weekday.replace("周", "週").replace("后", "後"), time12: ko.time12 }
}
/** 小组件底部更新时间：跟手机语言（en 用 Intl，失败回退 clockZh） */
export function widgetClock(ts: number, loc: WidgetLoc): string {
  if (loc === "en") {
    try { return new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit", hour12: true }).format(new Date(ts)) } catch { return clockZh(ts) }
  }
  return clockZh(ts)
}

/** FotMob 比赛页（独立版：tz 跟手机时区，冇手机时区就省略参数等 FotMob 自己判断；有装 FotMob App 会经 universal link 入 App 嗰场，冇装就开网页版） */
export function fotmobUrl(m: Match): string {
  const tz = phoneTimeZone()
  return tz
    ? `https://www.fotmob.com/match/${m.id}?tz=${tz}`
    : `https://www.fotmob.com/match/${m.id}`
}

/** —— 电视直播视图（1.0.21，主版 v1.1.97–1.1.100 同款移植） —— */

export type BroadcastMatch = {
  home: string
  away: string
  competition: string
  kickoff_utc: string
  url: string
  channels: Record<string, string[]>
}
export type BroadcastTable = {
  updated_at: string
  source: string
  matches: BroadcastMatch[]
  /** 本机上次成功抓到远程表嘅时间（毫秒；缓存档先有，校验唔理佢） */
  fetchedAt?: number
}

/** 校验远程直播表（1.0.21，照士碌架 parseBroadcastTable 严格作风）：顶层系
 *  { updated_at, source, matches: [{ home, away, competition, kickoff_utc, url, channels: {国家: [台名]} }] }；
 *  任一项唔啱形就成个当无效（回 null，用缓存顶住），唔会静鸡鸡丢走个别场次。 */
export function parseBroadcastTable(json: unknown): BroadcastTable | null {
  if (json == null || typeof json !== "object" || Array.isArray(json)) return null
  const o = json as { updated_at?: unknown; source?: unknown; matches?: unknown }
  if (typeof o.updated_at !== "string" || typeof o.source !== "string") return null
  if (!Array.isArray(o.matches)) return null
  const matches: BroadcastMatch[] = []
  for (const m of o.matches) {
    if (m == null || typeof m !== "object" || Array.isArray(m)) return null
    const e = m as { home?: unknown; away?: unknown; competition?: unknown; kickoff_utc?: unknown; url?: unknown; channels?: unknown }
    if (typeof e.home !== "string" || typeof e.away !== "string") return null
    if (typeof e.competition !== "string" || typeof e.kickoff_utc !== "string" || typeof e.url !== "string") return null
    if (e.channels == null || typeof e.channels !== "object" || Array.isArray(e.channels)) return null
    const channels: Record<string, string[]> = {}
    for (const [c, list] of Object.entries(e.channels as Record<string, unknown>)) {
      if (typeof c !== "string" || !Array.isArray(list) || !list.every((x) => typeof x === "string")) return null
      channels[c] = [...(list as string[])]
    }
    matches.push({ home: e.home, away: e.away, competition: e.competition, kickoff_utc: e.kickoff_utc, url: e.url, channels })
  }
  return { updated_at: o.updated_at, source: o.source, matches }
}

/** 队名规范化（配对用）：小写、去重音、去标点空白。FotMob 同 LSTV 大部分队名经呢步已一致（2026-11-16 至 22 档 63/81 场直接对上）。 */
export function teamNorm(name: string): string {
  return (name ?? "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "")
}

/** LSTV 队名 → FotMob 队名（key 已规范化）：2026-11-16 至 22 档逐场对过 FotMob day API 得出（13 对）；
 *  Milan／Olympiakos 两项来自 2026-11-15 livesoccertv 核查笔记（LSTV 用短名，FotMob 用全名），嗰期窗口未有呢两队，未逐场验证。 */
export const TEAM_ALIASES: Record<string, string> = {
  borussiamgladbach: "Borussia Mönchengladbach",
  celtadevigo: "Celta Vigo",
  deportivolacoruna: "Deportivo A Coruña",
  internazionale: "Inter",
  irelandrepublic: "Ireland",
  korearepublic: "South Korea",
  koln: "1. FC Köln",
  olympiquelyonnais: "Lyon",
  olympiquemarseille: "Marseille",
  psg: "Paris Saint-Germain",
  stuttgart: "VfB Stuttgart",
  paris: "Paris FC",
  angerssco: "Angers",
  unitedarabemirates: "UAE",
  milan: "AC Milan",
  olympiakos: "Olympiacos",
  olympiakospiraeus: "Olympiacos",
}

/** 队名系咪同一队：规范化相等，或者 LSTV 名经 alias 表对上 FotMob 名。 */
export function sameTeam(lstvName: string, fotmobName: string): boolean {
  const a = teamNorm(lstvName)
  const b = teamNorm(fotmobName)
  if (a === b) return true
  const aliased = TEAM_ALIASES[a]
  return aliased != null && teamNorm(aliased) === b
}

/** FotMob 场 ↔ 直播表场配对（1.0.21）：两队名（任一主客次序）＋同一 UTC 日期；
 *  同对同日多场就取开球最接近嗰场。开球时间唔做硬性条件——友谊赛 LSTV 同 FotMob
 *  开球时间实测可差 0.5–2 小时（2026-11-17 五场），联赛场时间一致。
 *  回 null 即系直播表入面冇呢场（例如唔喺十大赛事范围），唔系错误。 */
export function broadcastForMatch(m: Match, table: BroadcastTable | null): BroadcastMatch | null {
  if (table == null || !Array.isArray(table.matches) || table.matches.length === 0) return null
  const day = new Date(m.date).toISOString().slice(0, 10)
  const ko = new Date(m.date).getTime()
  let best: BroadcastMatch | null = null
  let bestGap = Infinity
  for (const b of table.matches) {
    if ((b.kickoff_utc ?? "").slice(0, 10) !== day) continue
    const fwd = sameTeam(b.home, m.home.name) && sameTeam(b.away, m.away.name)
    const rev = sameTeam(b.home, m.away.name) && sameTeam(b.away, m.home.name)
    if (!fwd && !rev) continue
    const gap = Math.abs(new Date(b.kickoff_utc).getTime() - ko)
    if (gap < bestGap) {
      best = b
      bestGap = gap
    }
  }
  return best
}

/** LSTV 频道名 → Gary 台（1.0.21）：2026-11-16 经屋企隧道核实 Gary m3u（763 台）逐项对出；
 *  countries 系 LSTV 国家名原样（同一 LSTV 名喺唔同国家可以对去唔同 Gary 台，例如 Sky Sport Premier League 德／紐西兰）；
 *  confidence: sure = 确定；probable = DAZN 加拿大线性台（某场可能行另一条 DAZN feed，名对唔出）；ambiguous = DAZN 德国 1 台为主、2 台溢出（边场行边条对唔出）。
 *  未核实嘅台唔入表——界面只显示有映射嘅台，唔估。 */
export type TvChannelMap = { lstv: string; countries: string[]; gary: string; group: string; confidence: "sure" | "probable" | "ambiguous" }
export const TV_CHANNEL_MAP: TvChannelMap[] = [
  { lstv: "Sky Sports Main Event", countries: ["Great Britain", "Ireland Republic"], gary: "Sky Sports Main Event UK", group: "Sports - EU", confidence: "sure" },
  { lstv: "Sky Sports Premier League", countries: ["Great Britain", "Ireland Republic"], gary: "Sky Sports Premier League UK", group: "Sports - EU", confidence: "sure" },
  { lstv: "Sky Sports Football", countries: ["Great Britain", "Ireland Republic"], gary: "Sky Sports Football UK", group: "Sports - EU", confidence: "sure" },
  { lstv: "TNT Sports 1", countries: ["Great Britain", "Ireland Republic"], gary: "TNT Sports 1 UK", group: "Sports - EU", confidence: "sure" },
  { lstv: "TNT Sports Ultimate", countries: ["Great Britain"], gary: "TNT Sports Ultimate UHD UK", group: "4K UHD", confidence: "sure" },
  { lstv: "Canal+ Foot", countries: ["Andorra", "France", "Switzerland"], gary: "CANAL+ Foot FR", group: "Sports - EU", confidence: "sure" },
  { lstv: "DAZN1 Germany", countries: ["Austria", "Germany"], gary: "DAZN 1 DE", group: "Sports - EU", confidence: "sure" },
  { lstv: "DAZN2 Germany", countries: ["Austria", "Germany"], gary: "DAZN 2 DE", group: "Sports - EU", confidence: "sure" },
  { lstv: "Sky Sport Premier League", countries: ["Austria", "Germany", "Switzerland"], gary: "Sky Sport Premier League DE", group: "Sports - EU", confidence: "sure" },
  { lstv: "Sky Sport Premier League", countries: ["New Zealand"], gary: "SKY Sport Premier League NZ", group: "Sports - OC", confidence: "sure" },
  { lstv: "Sky Sport Calcio", countries: ["Italy", "San Marino"], gary: "Sky Sport Calcio IT", group: "Sports - EU", confidence: "sure" },
  { lstv: "Sky Sport Bundesliga 1", countries: ["Austria", "Germany", "Switzerland"], gary: "Sky Sport Bundesliga DE", group: "Sports - EU", confidence: "sure" },
  { lstv: "Sky Sport Max", countries: ["Italy", "San Marino"], gary: "Sky Sport Max IT", group: "Sports - EU", confidence: "sure" },
  { lstv: "Sky Sport Arena", countries: ["Italy", "San Marino"], gary: "Sky Sport Arena IT", group: "Sports - EU", confidence: "sure" },
  { lstv: "Premier Sports 1", countries: ["Great Britain", "Ireland Republic"], gary: "Premier Sports 1 UK", group: "Sports - EU", confidence: "sure" },
  { lstv: "Premier Sports 2", countries: ["Great Britain", "Ireland Republic", "Mongolia"], gary: "Premier Sports 2 UK", group: "Sports - EU", confidence: "sure" },
  { lstv: "CCTV-5 Sports", countries: ["China"], gary: "CCTV5 CN", group: "Sports - Asia", confidence: "sure" },
  { lstv: "ESPN Deportes", countries: ["Guam", "Northern Mariana Islands", "Puerto Rico", "U.S. Virgin Islands", "USA"], gary: "ESPN Deportes", group: "Sports - NA", confidence: "sure" },
  { lstv: "CBS Sports Network", countries: ["Puerto Rico", "USA"], gary: "CBS Sports Network", group: "Sports - NA", confidence: "sure" },
  { lstv: "Fubo Sports Network", countries: ["USA"], gary: "Fubo Sports Network", group: "Sports - NA", confidence: "sure" },
  { lstv: "USA Network", countries: ["USA"], gary: "USA Network", group: "US", confidence: "sure" },
  { lstv: "beIN SPORTS", countries: ["USA"], gary: "beIN SPORTS", group: "Sports - NA", confidence: "sure" },
  { lstv: "Fox Soccer Plus", countries: ["USA"], gary: "FOX Soccer Plus", group: "Sports - NA", confidence: "sure" },
  { lstv: "UNIVERSO", countries: ["Puerto Rico", "USA"], gary: "Universo", group: "US", confidence: "sure" },
  { lstv: "DAZN Canada", countries: ["Canada"], gary: "DAZN 1 CA", group: "DAZN", confidence: "probable" },
  { lstv: "DAZN Germany", countries: ["Germany", "Liechtenstein"], gary: "DAZN 1 DE", group: "Sports - EU", confidence: "ambiguous" },
]

/** 国家优先级（1.0.21）：加拿大先、英国、美国、澳洲／新西兰、然后德／意／法／西／荷／港／中；表外国家排最后（按 LSTV 国家名字母序）。 */
const COUNTRY_PRIORITY = ["Canada", "Great Britain", "Ireland Republic", "USA", "Australia", "New Zealand", "Germany", "Austria", "Switzerland", "Italy", "San Marino", "France", "Andorra", "Spain", "Netherlands", "Hong Kong", "China"]
function countryRank(country: string): number {
  const i = COUNTRY_PRIORITY.indexOf(country)
  return i === -1 ? COUNTRY_PRIORITY.length : i
}

/** 一场嘅 Gary 直播台（1.0.21）：直播表 channels 按国家优先级排，每国 LSTV 名经 TV_CHANNEL_MAP 对 Gary 原名＋group；
 *  同一 Gary 台去重（取优先级最高嗰国）；最多 8 粒胶囊。probable／ambiguous 映射照纳入（DAZN 加拿大／德国）。
 *  无映射嗰台唔出（例如 fuboTV Canada、Peacock、Stan Sport、Migu、Viaplay 全部唔喺 Gary 入面）。 */
export function tvChannelsFor(b: BroadcastMatch | null): { name: string; group: string }[] {
  if (b == null) return []
  const out: { name: string; group: string }[] = []
  const seen = new Set<string>()
  const countries = Object.keys(b.channels ?? {}).sort((a, c) => countryRank(a) - countryRank(c) || a.localeCompare(c))
  for (const country of countries) {
    for (const lstv of b.channels[country] ?? []) {
      const hit = TV_CHANNEL_MAP.find((e) => e.countries.includes(country) && e.lstv === lstv)
      if (hit == null || seen.has(hit.gary)) continue
      seen.add(hit.gary)
      out.push({ name: hit.gary, group: hit.group })
      if (out.length >= 8) return out
    }
  }
  return out
}

/** 电视视图场次（1.0.22）：LIVE 先（按开球排），唔够 max 就用未开波 NS（按开球排）补足到 max 场；LIVE 已够 max 就净 LIVE。FT／AET／PEN／CANC 唔出。 */
export function pickTvMatches(matches: Match[], max: number, now = Date.now()): Match[] {
  const live = matches
    .filter((m) => LIVE.has(m.status))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, max)
  if (live.length >= max) return live
  const ns = matches
    .filter((m) => m.status === "NS" && new Date(m.date).getTime() > now)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, max - live.length)
  return [...live, ...ns]
}

/** 字大约阔度（1.0.21，照士碌架 1.0.42 校准）：中文／全角字约 1 字 = fontSize，拉丁字母约 0.50 × fontSize */
export function textWidthPt(s: string, fontSize: number = 10): number {
  let w = 0
  for (const ch of s) {
    const code = ch.codePointAt(0) ?? 0
    w += code > 0x2e7f || code === 0x3000 ? fontSize : fontSize * 0.5
  }
  return w
}

/** 胶囊类别显示（1.0.21）：Gary 名以 DAZN 开头嘅台（DAZN 1 CA／1 DE／2 DE）净显示台名，唔显示类别——
 *  用户话 DAZN 台全部都喺 DAZN 入面，睇名已知，唔使再睇类别。 */
export function tvCapsuleShowsGroup(name: string): boolean {
  return !name.startsWith("DAZN")
}

/** 胶囊分行（1.0.21，照士碌架 1.0.52 胶囊版）：每项阔度 = textWidthPt(台名,12) + 5 + textWidthPt(分类,10) + 16
 *  （胶囊左右 padding 8+8；5 = 台名同分类间距）；唔显示类别嘅台（DAZN，见 tvCapsuleShowsGroup）阔度只计台名＋16。
 *  sep 系胶囊之间间距（6）；firstRowDeduct 系第一行要预留嘅阔度（主版 v1.1.97–1.1.99 系 tv 图标连间距 17，
 *  v1.1.100 删走行左 tv 图标之后调用位传 0）。单个项目本身超宽就独占一行。次序唔变、唔丢项目。 */
export function flowTvRows(items: { name: string; group: string }[], maxWidth: number, sep: number = 6, firstRowDeduct: number = 0): { name: string; group: string }[][] {
  const rows: { name: string; group: string }[][] = []
  let row: { name: string; group: string }[] = []
  let rowW = 0
  let limit = maxWidth - firstRowDeduct
  for (const it of items) {
    const w = textWidthPt(it.name, 12) + (tvCapsuleShowsGroup(it.name) ? 5 + textWidthPt(it.group, 10) : 0) + 16
    const add = row.length === 0 ? w : rowW + sep + w
    if (row.length > 0 && add > limit) {
      rows.push(row)
      row = [it]
      rowW = w
      limit = maxWidth
    } else {
      row.push(it)
      rowW = add
    }
  }
  if (row.length > 0) rows.push(row)
  return rows
}
