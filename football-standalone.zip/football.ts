import { DONE, FootballData, Match, footballKey, localYMD, teamsKey , ntKey, derbyKey} from "./const"
import { DERBIES, DERBY_CATS, DERBY_TEAMS } from "./derby"
export { DERBIES, DERBY_CATS, DERBY_TEAMS } from "./derby"

// ============ FotMob 过滤（同 VPS update.py 一致，电话端直抓用） ============

const CLUB_IDS = new Set([10260, 8650, 9825, 8455, 8586, 8456, 8633, 8634, 9823, 9847])
// 用户 2026-10-27 要求删除：法国杯同名 Arsenal 假名场（Sporting BM vs Arsenal，GLP）
const BLOCKED_MATCH_IDS = new Set([6503684])
const CLUB_NAMES = new Set([
  "manchester united", "man utd", "manchester utd", "liverpool", "arsenal",
  "chelsea", "tottenham", "tottenham hotspur", "manchester city", "man city",
  "real madrid", "barcelona", "barca", "bayern", "bayern munich",
  "bayern münchen", "fc bayern", "psg", "paris saint germain",
  "paris saint-germain", "paris sg",
])
// FIFA 世界排名（2026 年 10 月榜：FIFA 10 月 7 日更新，下次 11 月 18 日；两个来源 FotMob／allsport 41–50 一致）
// 顺序即排名：1–40 承接旧 TOP40（9 月榜顺序不变，10 月榜 1–39 相同，第 40 位由塞尔维亚换成刚果民主共和国）；41–50 系 10 月榜
export type NTDef = { key: string; en: string; rank?: number; hans: string; hk: string; tw: string; aliases?: string[] }
export const NT_RANKING: NTDef[] = [
  { key: "spain", en: "Spain", rank: 1, hans: "西班牙", hk: "西班牙", tw: "西班牙" },
  { key: "argentina", en: "Argentina", rank: 2, hans: "阿根廷", hk: "阿根廷", tw: "阿根廷" },
  { key: "france", en: "France", rank: 3, hans: "法国", hk: "法國", tw: "法國" },
  { key: "england", en: "England", rank: 4, hans: "英格兰", hk: "英格蘭", tw: "英格蘭" },
  { key: "portugal", en: "Portugal", rank: 5, hans: "葡萄牙", hk: "葡萄牙", tw: "葡萄牙" },
  { key: "brazil", en: "Brazil", rank: 6, hans: "巴西", hk: "巴西", tw: "巴西" },
  { key: "morocco", en: "Morocco", rank: 7, hans: "摩洛哥", hk: "摩洛哥", tw: "摩洛哥" },
  { key: "belgium", en: "Belgium", rank: 8, hans: "比利时", hk: "比利時", tw: "比利時" },
  { key: "netherlands", en: "Netherlands", rank: 9, hans: "荷兰", hk: "荷蘭", tw: "荷蘭" },
  { key: "mexico", en: "Mexico", rank: 10, hans: "墨西哥", hk: "墨西哥", tw: "墨西哥" },
  { key: "colombia", en: "Colombia", rank: 11, hans: "哥伦比亚", hk: "哥倫比亞", tw: "哥倫比亞" },
  { key: "switzerland", en: "Switzerland", rank: 12, hans: "瑞士", hk: "瑞士", tw: "瑞士" },
  { key: "germany", en: "Germany", rank: 13, hans: "德国", hk: "德國", tw: "德國" },
  { key: "croatia", en: "Croatia", rank: 14, hans: "克罗地亚", hk: "克羅地亞", tw: "克羅地亞" },
  { key: "italy", en: "Italy", rank: 15, hans: "意大利", hk: "義大利", tw: "義大利" },
  { key: "usa", en: "USA", rank: 16, hans: "美国", hk: "美國", tw: "美國", aliases: ["united states"] },
  { key: "japan", en: "Japan", rank: 17, hans: "日本", hk: "日本", tw: "日本" },
  { key: "senegal", en: "Senegal", rank: 18, hans: "塞内加尔", hk: "塞內加爾", tw: "塞內加爾" },
  { key: "norway", en: "Norway", rank: 19, hans: "挪威", hk: "挪威", tw: "挪威" },
  { key: "uruguay", en: "Uruguay", rank: 20, hans: "乌拉圭", hk: "烏拉圭", tw: "烏拉圭" },
  { key: "denmark", en: "Denmark", rank: 21, hans: "丹麦", hk: "丹麥", tw: "丹麥" },
  { key: "austria", en: "Austria", rank: 22, hans: "奥地利", hk: "奧地利", tw: "奧地利" },
  { key: "iran", en: "Iran", rank: 23, hans: "伊朗", hk: "伊朗", tw: "伊朗", aliases: ["ir iran"] },
  { key: "ecuador", en: "Ecuador", rank: 24, hans: "厄瓜多尔", hk: "厄瓜多爾", tw: "厄瓜多爾" },
  { key: "egypt", en: "Egypt", rank: 25, hans: "埃及", hk: "埃及", tw: "埃及" },
  { key: "australia", en: "Australia", rank: 26, hans: "澳大利亚", hk: "澳洲", tw: "澳大利亞" },
  { key: "canada", en: "Canada", rank: 27, hans: "加拿大", hk: "加拿大", tw: "加拿大" },
  { key: "algeria", en: "Algeria", rank: 28, hans: "阿尔及利亚", hk: "阿爾及利亞", tw: "阿爾及利亞" },
  { key: "ivory coast", en: "Ivory Coast", rank: 29, hans: "科特迪瓦", hk: "象牙海岸", tw: "象牙海岸", aliases: ["côte d'ivoire", "cote d'ivoire"] },
  { key: "nigeria", en: "Nigeria", rank: 30, hans: "尼日利亚", hk: "尼日利亞", tw: "奈及利亞" },
  { key: "turkiye", en: "Turkiye", rank: 31, hans: "土耳其", hk: "土耳其", tw: "土耳其", aliases: ["turkey", "türkiye"] },
  { key: "south korea", en: "South Korea", rank: 32, hans: "韩国", hk: "南韓", tw: "韓國", aliases: ["korea republic"] },
  { key: "paraguay", en: "Paraguay", rank: 33, hans: "巴拉圭", hk: "巴拉圭", tw: "巴拉圭" },
  { key: "sweden", en: "Sweden", rank: 34, hans: "瑞典", hk: "瑞典", tw: "瑞典" },
  { key: "russia", en: "Russia", rank: 35, hans: "俄罗斯", hk: "俄羅斯", tw: "俄羅斯" },
  { key: "ukraine", en: "Ukraine", rank: 36, hans: "乌克兰", hk: "烏克蘭", tw: "烏克蘭" },
  { key: "poland", en: "Poland", rank: 37, hans: "波兰", hk: "波蘭", tw: "波蘭" },
  { key: "hungary", en: "Hungary", rank: 38, hans: "匈牙利", hk: "匈牙利", tw: "匈牙利" },
  { key: "wales", en: "Wales", rank: 39, hans: "威尔士", hk: "威爾斯", tw: "威爾斯" },
  { key: "dr congo", en: "DR Congo", rank: 40, hans: "刚果民主共和国", hk: "剛果民主共和國", tw: "剛果民主共和國", aliases: ["congo dr", "democratic republic of the congo"] },
  { key: "greece", en: "Greece", rank: 41, hans: "希腊", hk: "希臘", tw: "希臘" },
  { key: "cameroon", en: "Cameroon", rank: 42, hans: "喀麦隆", hk: "喀麥隆", tw: "喀麥隆" },
  { key: "scotland", en: "Scotland", rank: 43, hans: "苏格兰", hk: "蘇格蘭", tw: "蘇格蘭" },
  { key: "serbia", en: "Serbia", rank: 44, hans: "塞尔维亚", hk: "塞爾維亞", tw: "塞爾維亞" },
  { key: "slovakia", en: "Slovakia", rank: 45, hans: "斯洛伐克", hk: "斯洛伐克", tw: "斯洛伐克" },
  { key: "panama", en: "Panama", rank: 46, hans: "巴拿马", hk: "巴拿馬", tw: "巴拿馬" },
  { key: "mali", en: "Mali", rank: 47, hans: "马里", hk: "馬利", tw: "馬利" },
  { key: "south africa", en: "South Africa", rank: 48, hans: "南非", hk: "南非", tw: "南非" },
  { key: "venezuela", en: "Venezuela", rank: 49, hans: "委内瑞拉", hk: "委內瑞拉", tw: "委內瑞拉" },
  { key: "chile", en: "Chile", rank: 50, hans: "智利", hk: "智利", tw: "智利" },
]
// 世界全部国家队（v1.1.69 起）：Wikipedia 各洲国家队名单核实，共 221 间；
// 前 50 系上面 NT_RANKING（FIFA 2026 年 10 月榜），其余 171 间按洲＋英文名顺序；
// NT_ALL 按 FIFA 排名排（1–211 有排名，冇排名嘅 10 间排最尾、原洲顺序）；
// 范围前10/20/30/40/50 只取 NT_RANKING 前 N 间，唔受 NT_ALL 顺序影响。
export const NT_REST: NTDef[] = [
  { key: "afghanistan", en: "Afghanistan", rank: 168, hans: "阿富汗", hk: "阿富汗", tw: "阿富汗" },
  { key: "bahrain", en: "Bahrain", rank: 97, hans: "巴林", hk: "巴林", tw: "巴林" },
  { key: "bangladesh", en: "Bangladesh", rank: 182, hans: "孟加拉国", hk: "孟加拉國", tw: "孟加拉國" },
  { key: "bhutan", en: "Bhutan", rank: 192, hans: "不丹", hk: "不丹", tw: "不丹" },
  { key: "brunei", en: "Brunei", rank: 196, hans: "文莱", hk: "汶萊", tw: "汶萊", aliases: ["brunei darussalam"] },
  { key: "cambodia", en: "Cambodia", rank: 177, hans: "柬埔寨", hk: "柬埔寨", tw: "柬埔寨" },
  { key: "china", en: "China", rank: 96, hans: "中国", hk: "中國", tw: "中國", aliases: ["china pr"] },
  { key: "chinese taipei", en: "Chinese Taipei", rank: 176, hans: "中国台北", hk: "中國台北", tw: "中華台北" },
  { key: "guam", en: "Guam", rank: 203, hans: "关岛", hk: "關島", tw: "關島" },
  { key: "hong kong", en: "Hong Kong", rank: 153, hans: "香港", hk: "香港", tw: "香港", aliases: ["hong kong, china"] },
  { key: "india", en: "India", rank: 138, hans: "印度", hk: "印度", tw: "印度" },
  { key: "indonesia", en: "Indonesia", rank: 116, hans: "印尼", hk: "印尼", tw: "印尼" },
  { key: "iraq", en: "Iraq", rank: 63, hans: "伊拉克", hk: "伊拉克", tw: "伊拉克" },
  { key: "jordan", en: "Jordan", rank: 72, hans: "约旦", hk: "約旦", tw: "約旦" },
  { key: "north korea", en: "North Korea", rank: 121, hans: "朝鲜", hk: "北韓", tw: "北韓", aliases: ["korea dpr"] },
  { key: "kuwait", en: "Kuwait", rank: 134, hans: "科威特", hk: "科威特", tw: "科威特" },
  { key: "kyrgyzstan", en: "Kyrgyzstan", rank: 104, hans: "吉尔吉斯斯坦", hk: "吉爾吉斯斯坦", tw: "吉爾吉斯斯坦", aliases: ["kyrgyz republic"] },
  { key: "laos", en: "Laos", rank: 188, hans: "老挝", hk: "老撾", tw: "老撾" },
  { key: "lebanon", en: "Lebanon", rank: 112, hans: "黎巴嫩", hk: "黎巴嫩", tw: "黎巴嫩" },
  { key: "macau", en: "Macau", rank: 193, hans: "澳门", hk: "澳門", tw: "澳門", aliases: ["macao"] },
  { key: "malaysia", en: "Malaysia", rank: 133, hans: "马来西亚", hk: "馬來西亞", tw: "馬來西亞" },
  { key: "maldives", en: "Maldives", rank: 173, hans: "马尔代夫", hk: "馬爾代夫", tw: "馬爾代夫" },
  { key: "mongolia", en: "Mongolia", rank: 190, hans: "蒙古", hk: "蒙古", tw: "蒙古" },
  { key: "myanmar", en: "Myanmar", rank: 159, hans: "缅甸", hk: "緬甸", tw: "緬甸", aliases: ["burma"] },
  { key: "nepal", en: "Nepal", rank: 178, hans: "尼泊尔", hk: "尼泊爾", tw: "尼泊爾" },
  { key: "northern mariana islands", en: "Northern Mariana Islands", hans: "北马里亚纳群岛", hk: "北馬里亞納群島", tw: "北馬里亞納群島" },
  { key: "oman", en: "Oman", rank: 81, hans: "阿曼", hk: "阿曼", tw: "阿曼" },
  { key: "pakistan", en: "Pakistan", rank: 197, hans: "巴基斯坦", hk: "巴基斯坦", tw: "巴基斯坦" },
  { key: "palestine", en: "Palestine", rank: 92, hans: "巴勒斯坦", hk: "巴勒斯坦", tw: "巴勒斯坦" },
  { key: "philippines", en: "Philippines", rank: 136, hans: "菲律宾", hk: "菲律賓", tw: "菲律賓" },
  { key: "qatar", en: "Qatar", rank: 60, hans: "卡塔尔", hk: "卡塔爾", tw: "卡塔爾" },
  { key: "saudi arabia", en: "Saudi Arabia", rank: 55, hans: "沙特阿拉伯", hk: "沙特阿拉伯", tw: "沙烏地阿拉伯" },
  { key: "singapore", en: "Singapore", rank: 149, hans: "新加坡", hk: "新加坡", tw: "新加坡" },
  { key: "sri lanka", en: "Sri Lanka", rank: 184, hans: "斯里兰卡", hk: "斯里蘭卡", tw: "斯里蘭卡" },
  { key: "syria", en: "Syria", rank: 86, hans: "叙利亚", hk: "敘利亞", tw: "敘利亞" },
  { key: "tajikistan", en: "Tajikistan", rank: 100, hans: "塔吉克斯坦", hk: "塔吉克斯坦", tw: "塔吉克斯坦" },
  { key: "thailand", en: "Thailand", rank: 93, hans: "泰国", hk: "泰國", tw: "泰國" },
  { key: "timor-leste", en: "Timor-Leste", rank: 202, hans: "东帝汶", hk: "東帝汶", tw: "東帝汶", aliases: ["east timor"] },
  { key: "turkmenistan", en: "Turkmenistan", rank: 139, hans: "土库曼斯坦", hk: "土庫曼斯坦", tw: "土庫曼斯坦" },
  { key: "united arab emirates", en: "United Arab Emirates", rank: 65, hans: "阿联酋", hk: "阿聯酋", tw: "阿聯酋", aliases: ["uae"] },
  { key: "uzbekistan", en: "Uzbekistan", rank: 59, hans: "乌兹别克斯坦", hk: "烏茲別克斯坦", tw: "烏茲別克斯坦" },
  { key: "vietnam", en: "Vietnam", rank: 99, hans: "越南", hk: "越南", tw: "越南" },
  { key: "yemen", en: "Yemen", rank: 144, hans: "也门", hk: "也門", tw: "也門" },
  { key: "angola", en: "Angola", rank: 83, hans: "安哥拉", hk: "安哥拉", tw: "安哥拉" },
  { key: "benin", en: "Benin", rank: 89, hans: "贝宁", hk: "貝寧", tw: "貝寧" },
  { key: "botswana", en: "Botswana", rank: 141, hans: "博茨瓦纳", hk: "博茨瓦納", tw: "博茨瓦納" },
  { key: "burkina faso", en: "Burkina Faso", rank: 62, hans: "布基纳法索", hk: "布基納法索", tw: "布基納法索" },
  { key: "burundi", en: "Burundi", rank: 140, hans: "布隆迪", hk: "布隆迪", tw: "布隆迪" },
  { key: "cabo verde", en: "Cabo Verde", rank: 68, hans: "佛得角", hk: "佛得角", tw: "佛得角", aliases: ["cape verde"] },
  { key: "central african republic", en: "Central African Republic", rank: 145, hans: "中非共和国", hk: "中非共和國", tw: "中非共和國" },
  { key: "chad", en: "Chad", rank: 181, hans: "乍得", hk: "乍得", tw: "乍得" },
  { key: "comoros", en: "Comoros", rank: 107, hans: "科摩罗", hk: "科摩羅", tw: "科摩羅" },
  { key: "congo", en: "Congo", rank: 132, hans: "刚果共和国", hk: "剛果共和國", tw: "剛果共和國", aliases: ["republic of the congo", "congo republic"] },
  { key: "djibouti", en: "Djibouti", rank: 195, hans: "吉布提", hk: "吉布提", tw: "吉布提" },
  { key: "equatorial guinea", en: "Equatorial Guinea", rank: 103, hans: "赤道几内亚", hk: "赤道幾內亞", tw: "赤道幾內亞" },
  { key: "eritrea", en: "Eritrea", rank: 183, hans: "厄立特里亚", hk: "厄立特里亞", tw: "厄立特里亞" },
  { key: "eswatini", en: "Eswatini", rank: 164, hans: "斯威士兰", hk: "斯威士蘭", tw: "斯威士蘭", aliases: ["swaziland"] },
  { key: "ethiopia", en: "Ethiopia", rank: 147, hans: "埃塞俄比亚", hk: "埃塞俄比亞", tw: "埃塞俄比亞" },
  { key: "gabon", en: "Gabon", rank: 85, hans: "加蓬", hk: "加蓬", tw: "加蓬" },
  { key: "gambia", en: "Gambia", rank: 109, hans: "冈比亚", hk: "岡比亞", tw: "岡比亞", aliases: ["the gambia"] },
  { key: "ghana", en: "Ghana", rank: 70, hans: "加纳", hk: "加納", tw: "加納" },
  { key: "guinea", en: "Guinea", rank: 82, hans: "几内亚", hk: "幾內亞", tw: "幾內亞" },
  { key: "guinea-bissau", en: "Guinea-Bissau", rank: 124, hans: "几内亚比绍", hk: "幾內亞比紹", tw: "幾內亞比紹" },
  { key: "kenya", en: "Kenya", rank: 114, hans: "肯尼亚", hk: "肯尼亞", tw: "肯尼亞" },
  { key: "lesotho", en: "Lesotho", rank: 150, hans: "莱索托", hk: "萊索托", tw: "萊索托" },
  { key: "liberia", en: "Liberia", rank: 146, hans: "利比里亚", hk: "利比里亞", tw: "利比里亞" },
  { key: "libya", en: "Libya", rank: 113, hans: "利比亚", hk: "利比亞", tw: "利比亞" },
  { key: "madagascar", en: "Madagascar", rank: 106, hans: "马达加斯加", hk: "馬達加斯加", tw: "馬達加斯加" },
  { key: "malawi", en: "Malawi", rank: 131, hans: "马拉维", hk: "馬拉維", tw: "馬拉維" },
  { key: "mauritania", en: "Mauritania", rank: 110, hans: "毛里塔尼亚", hk: "毛里塔尼亞", tw: "毛里塔尼亞" },
  { key: "mauritius", en: "Mauritius", rank: 179, hans: "毛里求斯", hk: "毛里求斯", tw: "毛里求斯" },
  { key: "mozambique", en: "Mozambique", rank: 98, hans: "莫桑比克", hk: "莫桑比克", tw: "莫桑比克" },
  { key: "namibia", en: "Namibia", rank: 123, hans: "纳米比亚", hk: "納米比亞", tw: "納米比亞" },
  { key: "niger", en: "Niger", rank: 111, hans: "尼日尔", hk: "尼日爾", tw: "尼日爾" },
  { key: "reunion", en: "Réunion", hans: "留尼汪", hk: "留尼汪", tw: "留尼汪", aliases: ["reunion"] },
  { key: "rwanda", en: "Rwanda", rank: 119, hans: "卢旺达", hk: "盧旺達", tw: "盧旺達" },
  { key: "sao tome and principe", en: "São Tomé and Príncipe", rank: 194, hans: "圣多美和普林西比", hk: "聖多美和普林西比", tw: "聖多美和普林西比", aliases: ["sao tome and principe"] },
  { key: "seychelles", en: "Seychelles", rank: 205, hans: "塞舌尔", hk: "塞舌爾", tw: "塞舌爾" },
  { key: "sierra leone", en: "Sierra Leone", rank: 130, hans: "塞拉利昂", hk: "塞拉利昂", tw: "塞拉利昂" },
  { key: "somalia", en: "Somalia", rank: 200, hans: "索马里", hk: "索馬里", tw: "索馬里" },
  { key: "south sudan", en: "South Sudan", rank: 170, hans: "南苏丹", hk: "南蘇丹", tw: "南蘇丹" },
  { key: "sudan", en: "Sudan", rank: 118, hans: "苏丹", hk: "蘇丹", tw: "蘇丹" },
  { key: "tanzania", en: "Tanzania", rank: 115, hans: "坦桑尼亚", hk: "坦桑尼亞", tw: "坦桑尼亞" },
  { key: "togo", en: "Togo", rank: 120, hans: "多哥", hk: "多哥", tw: "多哥" },
  { key: "tunisia", en: "Tunisia", rank: 61, hans: "突尼斯", hk: "突尼斯", tw: "突尼斯" },
  { key: "uganda", en: "Uganda", rank: 87, hans: "乌干达", hk: "烏干達", tw: "烏干達" },
  { key: "zambia", en: "Zambia", rank: 91, hans: "赞比亚", hk: "贊比亞", tw: "贊比亞" },
  { key: "zimbabwe", en: "Zimbabwe", rank: 129, hans: "津巴布韦", hk: "津巴布韋", tw: "津巴布韋" },
  { key: "anguilla", en: "Anguilla", rank: 210, hans: "安圭拉", hk: "安圭拉", tw: "安圭拉" },
  { key: "antigua and barbuda", en: "Antigua and Barbuda", rank: 162, hans: "安提瓜和巴布达", hk: "安提瓜和巴布達", tw: "安提瓜和巴布達" },
  { key: "aruba", en: "Aruba", rank: 185, hans: "阿鲁巴", hk: "阿魯巴", tw: "阿魯巴" },
  { key: "bahamas", en: "Bahamas", rank: 208, hans: "巴哈马", hk: "巴哈馬", tw: "巴哈馬" },
  { key: "barbados", en: "Barbados", rank: 174, hans: "巴巴多斯", hk: "巴巴多斯", tw: "巴巴多斯" },
  { key: "belize", en: "Belize", rank: 180, hans: "伯利兹", hk: "伯利茲", tw: "伯利茲" },
  { key: "bermuda", en: "Bermuda", rank: 171, hans: "百慕大", hk: "百慕大", tw: "百慕大" },
  { key: "bonaire", en: "Bonaire", hans: "博内尔", hk: "博內爾", tw: "博內爾" },
  { key: "british virgin islands", en: "British Virgin Islands", rank: 209, hans: "英属维尔京群岛", hk: "英屬維爾京群島", tw: "英屬維爾京群島" },
  { key: "cayman islands", en: "Cayman Islands", rank: 198, hans: "开曼群岛", hk: "開曼群島", tw: "開曼群島" },
  { key: "costa rica", en: "Costa Rica", rank: 54, hans: "哥斯达黎加", hk: "哥斯達黎加", tw: "哥斯達黎加" },
  { key: "cuba", en: "Cuba", rank: 163, hans: "古巴", hk: "古巴", tw: "古巴" },
  { key: "curacao", en: "Curaçao", rank: 80, hans: "库拉索", hk: "庫拉索", tw: "庫拉索", aliases: ["curacao"] },
  { key: "dominica", en: "Dominica", rank: 186, hans: "多米尼克", hk: "多米尼克", tw: "多米尼克" },
  { key: "dominican republic", en: "Dominican Republic", rank: 135, hans: "多米尼加共和国", hk: "多米尼加共和國", tw: "多米尼加共和國" },
  { key: "el salvador", en: "El Salvador", rank: 102, hans: "萨尔瓦多", hk: "薩爾瓦多", tw: "薩爾瓦多" },
  { key: "french guiana", en: "French Guiana", hans: "法属圭亚那", hk: "法屬圭亞那", tw: "法屬圭亞那" },
  { key: "grenada", en: "Grenada", rank: 169, hans: "格林纳达", hk: "格林納達", tw: "格林納達" },
  { key: "guadeloupe", en: "Guadeloupe", hans: "瓜德罗普", hk: "瓜德羅普", tw: "瓜德羅普" },
  { key: "guatemala", en: "Guatemala", rank: 95, hans: "危地马拉", hk: "危地馬拉", tw: "危地馬拉" },
  { key: "guyana", en: "Guyana", rank: 142, hans: "圭亚那", hk: "圭亞那", tw: "圭亞那" },
  { key: "haiti", en: "Haiti", rank: 84, hans: "海地", hk: "海地", tw: "海地" },
  { key: "honduras", en: "Honduras", rank: 67, hans: "洪都拉斯", hk: "洪都拉斯", tw: "洪都拉斯" },
  { key: "jamaica", en: "Jamaica", rank: 69, hans: "牙买加", hk: "牙買加", tw: "牙買加" },
  { key: "martinique", en: "Martinique", hans: "马提尼克", hk: "馬提尼克", tw: "馬提尼克" },
  { key: "montserrat", en: "Montserrat", rank: 172, hans: "蒙特塞拉特", hk: "蒙特塞拉特", tw: "蒙特塞拉特" },
  { key: "nicaragua", en: "Nicaragua", rank: 137, hans: "尼加拉瓜", hk: "尼加拉瓜", tw: "尼加拉瓜" },
  { key: "puerto rico", en: "Puerto Rico", rank: 155, hans: "波多黎各", hk: "波多黎各", tw: "波多黎各" },
  { key: "saint kitts and nevis", en: "Saint Kitts and Nevis", rank: 151, hans: "圣基茨和尼维斯", hk: "聖基茨和尼維斯", tw: "聖基茨和尼維斯" },
  { key: "saint lucia", en: "Saint Lucia", rank: 165, hans: "圣卢西亚", hk: "聖盧西亞", tw: "聖盧西亞" },
  { key: "saint martin", en: "Saint Martin", hans: "法属圣马丁", hk: "法屬聖馬丁", tw: "法屬聖馬丁" },
  { key: "saint vincent and the grenadines", en: "Saint Vincent and the Grenadines", rank: 166, hans: "圣文森特和格林纳丁斯", hk: "聖文森特和格林納丁斯", tw: "聖文森特和格林納丁斯" },
  { key: "sint maarten", en: "Sint Maarten", hans: "荷属圣马丁", hk: "荷屬聖馬丁", tw: "荷屬聖馬丁" },
  { key: "suriname", en: "Suriname", rank: 128, hans: "苏里南", hk: "蘇里南", tw: "蘇里南" },
  { key: "trinidad and tobago", en: "Trinidad and Tobago", rank: 105, hans: "特立尼达和多巴哥", hk: "特立尼達和多巴哥", tw: "特立尼達和多巴哥" },
  { key: "turks and caicos islands", en: "Turks and Caicos Islands", rank: 204, hans: "特克斯和凯科斯群岛", hk: "特克斯和凱科斯群島", tw: "特克斯和凱科斯群島" },
  { key: "us virgin islands", en: "US Virgin Islands", rank: 206, hans: "美属维尔京群岛", hk: "美屬維爾京群島", tw: "美屬維爾京群島" },
  { key: "bolivia", en: "Bolivia", rank: 78, hans: "玻利维亚", hk: "玻利維亞", tw: "玻利維亞" },
  { key: "peru", en: "Peru", rank: 53, hans: "秘鲁", hk: "秘魯", tw: "秘魯" },
  { key: "american samoa", en: "American Samoa", rank: 191, hans: "美属萨摩亚", hk: "美屬薩摩亞", tw: "美屬薩摩亞" },
  { key: "cook islands", en: "Cook Islands", rank: 187, hans: "库克群岛", hk: "庫克群島", tw: "庫克群島" },
  { key: "fiji", en: "Fiji", rank: 154, hans: "斐济", hk: "斐濟", tw: "斐濟" },
  { key: "kiribati", en: "Kiribati", hans: "基里巴斯", hk: "基里巴斯", tw: "基里巴斯" },
  { key: "new caledonia", en: "New Caledonia", rank: 156, hans: "新喀里多尼亚", hk: "新喀里多尼亞", tw: "新喀里多尼亞" },
  { key: "new zealand", en: "New Zealand", rank: 88, hans: "新西兰", hk: "新西蘭", tw: "紐西蘭" },
  { key: "papua new guinea", en: "Papua New Guinea", rank: 167, hans: "巴布亚新几内亚", hk: "巴布亞新幾內亞", tw: "巴布亞新幾內亞" },
  { key: "samoa", en: "Samoa", rank: 189, hans: "萨摩亚", hk: "薩摩亞", tw: "薩摩亞" },
  { key: "solomon islands", en: "Solomon Islands", rank: 152, hans: "所罗门群岛", hk: "所羅門群島", tw: "所羅門群島" },
  { key: "tahiti", en: "Tahiti", rank: 157, hans: "塔希提", hk: "塔希提", tw: "塔希提" },
  { key: "tonga", en: "Tonga", rank: 199, hans: "汤加", hk: "湯加", tw: "湯加" },
  { key: "tuvalu", en: "Tuvalu", hans: "图瓦卢", hk: "圖瓦盧", tw: "圖瓦盧" },
  { key: "vanuatu", en: "Vanuatu", rank: 161, hans: "瓦努阿图", hk: "瓦努阿圖", tw: "瓦努阿圖" },
  { key: "albania", en: "Albania", rank: 66, hans: "阿尔巴尼亚", hk: "阿爾巴尼亞", tw: "阿爾巴尼亞" },
  { key: "andorra", en: "Andorra", rank: 175, hans: "安道尔", hk: "安道爾", tw: "安道爾" },
  { key: "armenia", en: "Armenia", rank: 108, hans: "亚美尼亚", hk: "亞美尼亞", tw: "亞美尼亞" },
  { key: "azerbaijan", en: "Azerbaijan", rank: 127, hans: "阿塞拜疆", hk: "阿塞拜疆", tw: "阿塞拜疆" },
  { key: "belarus", en: "Belarus", rank: 94, hans: "白俄罗斯", hk: "白俄羅斯", tw: "白俄羅斯" },
  { key: "bosnia and herzegovina", en: "Bosnia and Herzegovina", rank: 57, hans: "波斯尼亚和黑塞哥维那", hk: "波斯尼亞和黑塞哥維那", tw: "波斯尼亞和黑塞哥維那" },
  { key: "bulgaria", en: "Bulgaria", rank: 90, hans: "保加利亚", hk: "保加利亞", tw: "保加利亞" },
  { key: "cyprus", en: "Cyprus", rank: 125, hans: "塞浦路斯", hk: "塞浦路斯", tw: "塞浦路斯" },
  { key: "czechia", en: "Czechia", rank: 51, hans: "捷克", hk: "捷克", tw: "捷克", aliases: ["czech republic"] },
  { key: "estonia", en: "Estonia", rank: 122, hans: "爱沙尼亚", hk: "愛沙尼亞", tw: "愛沙尼亞" },
  { key: "faroe islands", en: "Faroe Islands", rank: 126, hans: "法罗群岛", hk: "法羅群島", tw: "法羅群島" },
  { key: "finland", en: "Finland", rank: 75, hans: "芬兰", hk: "芬蘭", tw: "芬蘭" },
  { key: "georgia", en: "Georgia", rank: 74, hans: "格鲁吉亚", hk: "格魯吉亞", tw: "格魯吉亞" },
  { key: "gibraltar", en: "Gibraltar", rank: 201, hans: "直布罗陀", hk: "直布羅陀", tw: "直布羅陀" },
  { key: "iceland", en: "Iceland", rank: 73, hans: "冰岛", hk: "冰島", tw: "冰島" },
  { key: "israel", en: "Israel", rank: 77, hans: "以色列", hk: "以色列", tw: "以色列" },
  { key: "kazakhstan", en: "Kazakhstan", rank: 117, hans: "哈萨克斯坦", hk: "哈薩克斯坦", tw: "哈薩克斯坦" },
  { key: "kosovo", en: "Kosovo", rank: 76, hans: "科索沃", hk: "科索沃", tw: "科索沃" },
  { key: "latvia", en: "Latvia", rank: 143, hans: "拉脱维亚", hk: "拉脫維亞", tw: "拉脫維亞" },
  { key: "liechtenstein", en: "Liechtenstein", rank: 207, hans: "列支敦士登", hk: "列支敦士登", tw: "列支敦士登" },
  { key: "lithuania", en: "Lithuania", rank: 148, hans: "立陶宛", hk: "立陶宛", tw: "立陶宛" },
  { key: "luxembourg", en: "Luxembourg", rank: 101, hans: "卢森堡", hk: "盧森堡", tw: "盧森堡" },
  { key: "malta", en: "Malta", rank: 160, hans: "马耳他", hk: "馬耳他", tw: "馬耳他" },
  { key: "moldova", en: "Moldova", rank: 158, hans: "摩尔多瓦", hk: "摩爾多瓦", tw: "摩爾多瓦" },
  { key: "montenegro", en: "Montenegro", rank: 79, hans: "黑山", hk: "黑山", tw: "黑山" },
  { key: "northern ireland", en: "Northern Ireland", rank: 64, hans: "北爱尔兰", hk: "北愛爾蘭", tw: "北愛爾蘭" },
  { key: "north macedonia", en: "North Macedonia", rank: 71, hans: "北马其顿", hk: "北馬其頓", tw: "北馬其頓" },
  { key: "ireland", en: "Ireland", rank: 56, hans: "爱尔兰", hk: "愛爾蘭", tw: "愛爾蘭", aliases: ["republic of ireland"] },
  { key: "romania", en: "Romania", rank: 58, hans: "罗马尼亚", hk: "羅馬尼亞", tw: "羅馬尼亞" },
  { key: "san marino", en: "San Marino", rank: 211, hans: "圣马力诺", hk: "聖馬力諾", tw: "聖馬力諾" },
  { key: "slovenia", en: "Slovenia", rank: 52, hans: "斯洛文尼亚", hk: "斯洛文尼亞", tw: "斯洛文尼亞" },
]
export const NT_ALL: NTDef[] = [...NT_RANKING, ...NT_REST].sort((a, b) => (a.rank ?? 999) - (b.rank ?? 999))
const ALIASES: Record<string, string> = {
  "korea republic": "south korea",
  "ir iran": "iran",
  "côte d'ivoire": "ivory coast",
  "cote d'ivoire": "ivory coast",
  "turkiye": "turkey",
}
const JUNK_LEAGUE = [
  "kvinner", "damer", "women", "woman", "ladies", "female",
  "girls", "u21", "u20", "u19", "u18", "u17", "u16", "u15",
  "youth", "junior",
]
const CODE_MAP: Record<string, string> = {
  "manchester united": "MUN", "man united": "MUN", "man utd": "MUN",
  "liverpool": "LIV", "arsenal": "ARS", "chelsea": "CHE",
  "tottenham": "TOT", "tottenham hotspur": "TOT",
  "manchester city": "MCI", "man city": "MCI",
  "real madrid": "RMA", "barcelona": "BAR",
  "bayern münchen": "BAY", "bayern munich": "BAY", "fc bayern": "BAY",
  "paris saint-germain": "PSG", "paris saint germain": "PSG",
  "paris sg": "PSG", "psg": "PSG",
  "spain": "ESP", "argentina": "ARG", "france": "FRA", "england": "ENG",
  "brazil": "BRA", "morocco": "MAR", "portugal": "POR", "belgium": "BEL",
  "netherlands": "NED", "mexico": "MEX", "colombia": "COL", "germany": "GER",
  "croatia": "CRO", "switzerland": "SUI", "italy": "ITA",
  "usa": "USA", "united states": "USA",
  "japan": "JPN", "senegal": "SEN", "norway": "NOR", "uruguay": "URU",
  "denmark": "DEN", "iran": "IRN", "ir iran": "IRN",
  "austria": "AUT", "egypt": "EGY", "ecuador": "ECU", "nigeria": "NGA",
  "turkey": "TUR", "türkiye": "TUR", "turkiye": "TUR",
  "australia": "AUS", "algeria": "ALG", "canada": "CAN",
  "ivory coast": "CIV", "côte d'ivoire": "CIV", "cote d'ivoire": "CIV",
  "south korea": "KOR", "korea republic": "KOR",
  "ukraine": "UKR", "paraguay": "PAR", "russia": "RUS", "poland": "POL",
  "sweden": "SWE", "wales": "WAL", "hungary": "HUN", "serbia": "SRB",
}
const LOGO = (id: number) => `https://images.fotmob.com/image_resources/logo/teamlogo/${id}.png`

// ============ 自定义关注球队（v1.1.47：页面顶部填写，取代默认 10 间） ============

// ============ 两级菜单：联赛 → 球队（译名跟手机系统语言） ============

/** 球队：id 全部经 FotMob 2026/2027 联赛积分榜核实；en 系 FotMob 原名；
 *  short 系 FotMob 短名（同原名唔同时先写）；aliases 系旧版沿用嘅英文别名；
 *  legacy 系旧版中文名（新版三地写法覆盖唔到嘅旧输入，解析旧清单用） */
export type TeamDef = {
  id: number
  en: string
  short?: string
  aliases?: string[]
  legacy?: string[]
  hans: string
  hk: string
  tw: string
}

export type LeagueDef = {
  key: string
  en: string
  hans: string
  hk: string
  tw: string
  teams: TeamDef[]
}

export const LEAGUES: LeagueDef[] = [
  { key: "epl", en: "Premier League", hans: "英超", hk: "英超", tw: "英超", teams: [
    { id: 8456, en: "Manchester City", short: "Man City", hans: "曼城", hk: "曼城", tw: "曼城" },
    { id: 9825, en: "Arsenal", hans: "阿森纳", hk: "阿仙奴", tw: "阿森納" },
    { id: 10204, en: "Brighton & Hove Albion", short: "Brighton", legacy: ["白礼顿"], hans: "布莱顿", hk: "白禮頓", tw: "布萊頓" },
    { id: 8650, en: "Liverpool", hans: "利物浦", hk: "利物浦", tw: "利物浦" },
    { id: 8455, en: "Chelsea", legacy: ["车路士"], hans: "切尔西", hk: "車路士", tw: "切爾西" },
    { id: 9937, en: "Brentford", hans: "布伦特福德", hk: "賓福特", tw: "布倫特福德" },
    { id: 8463, en: "Leeds United", short: "Leeds", hans: "利兹联", hk: "列斯聯", tw: "里茲聯" },
    { id: 10261, en: "Newcastle United", short: "Newcastle", legacy: ["纽卡素"], hans: "纽卡", hk: "紐卡素", tw: "紐卡索" },
    { id: 10252, en: "Aston Villa", legacy: ["阿士东维拉"], hans: "维拉", hk: "維拉", tw: "維拉" },
    { id: 8667, en: "Hull City", short: "Hull", hans: "赫尔城", hk: "侯城", tw: "赫爾城" },
    { id: 8668, en: "Everton", legacy: ["爱华顿"], hans: "埃弗顿", hk: "愛華頓", tw: "艾佛頓" },
    { id: 9902, en: "Ipswich Town", short: "Ipswich", hans: "伊普斯维奇", hk: "葉士域治", tw: "伊普斯威奇" },
    { id: 8678, en: "AFC Bournemouth", short: "Bournemouth", hans: "伯恩茅斯", hk: "般尼茅夫", tw: "伯恩茅斯" },
    { id: 8586, en: "Tottenham Hotspur", short: "Tottenham", hans: "热刺", hk: "熱刺", tw: "熱刺" },
    { id: 9879, en: "Fulham", hans: "富勒姆", hk: "富咸", tw: "富勒姆" },
    { id: 10260, en: "Manchester United", short: "Man United", aliases: ["Man Utd", "Manchester Utd"], hans: "曼联", hk: "曼聯", tw: "曼聯" },
    { id: 9826, en: "Crystal Palace", hans: "水晶宫", hk: "水晶宮", tw: "水晶宮" },
    { id: 10203, en: "Nottingham Forest", short: "Nottm Forest", legacy: ["诺定咸森林"], hans: "诺丁汉森林", hk: "諾定咸森林", tw: "諾丁漢森林" },
    { id: 8669, en: "Coventry City", short: "Coventry", hans: "考文垂", hk: "高雲地利", tw: "考文垂" },
    { id: 8472, en: "Sunderland", hans: "桑德兰", hk: "新特蘭", tw: "桑德蘭" },
  ] },
  { key: "laliga", en: "LaLiga", hans: "西甲", hk: "西甲", tw: "西甲", teams: [
    { id: 8634, en: "Barcelona", aliases: ["Barca"], hans: "巴萨", hk: "巴塞", tw: "巴薩" },
    { id: 9906, en: "Atlético Madrid", legacy: ["马体会"], hans: "马竞", hk: "馬體會", tw: "馬競" },
    { id: 8633, en: "Real Madrid", legacy: ["皇家马德里", "皇家馬德里"], hans: "皇马", hk: "皇馬", tw: "皇馬" },
    { id: 8603, en: "Real Betis", hans: "贝蒂斯", hk: "貝迪斯", tw: "貝提斯" },
    { id: 8560, en: "Real Sociedad", hans: "皇家社会", hk: "皇家蘇斯達", tw: "皇家社會" },
    { id: 8302, en: "Sevilla", legacy: ["西维尔"], hans: "塞维利亚", hk: "西維爾", tw: "塞維亞" },
    { id: 9866, en: "Deportivo Alavés", hans: "阿拉维斯", hk: "阿拉維斯", tw: "阿拉維斯" },
    { id: 8315, en: "Athletic Club", hans: "毕尔巴鄂", hk: "畢爾包", tw: "畢爾包" },
    { id: 9910, en: "Celta Vigo", hans: "塞尔塔", hk: "切爾達", tw: "塞爾塔" },
    { id: 10205, en: "Villarreal", legacy: ["维拉利尔"], hans: "比利亚雷亚尔", hk: "維拉利爾", tw: "比利亞雷亞爾" },
    { id: 9783, en: "Deportivo A Coruña", hans: "拉科鲁尼亚", hk: "拉科魯尼亞", tw: "拉科魯尼亞" },
    { id: 8371, en: "Osasuna", hans: "奥萨苏纳", hk: "奧沙辛拿", tw: "奧薩蘇納" },
    { id: 8696, en: "Racing Santander", hans: "桑坦德竞技", hk: "桑坦德", tw: "桑坦德競技" },
    { id: 8581, en: "Levante", hans: "莱万特", hk: "利雲特", tw: "萊萬特" },
    { id: 10268, en: "Elche", hans: "埃尔切", hk: "艾爾切", tw: "艾爾切" },
    { id: 8370, en: "Rayo Vallecano", hans: "巴列卡诺", hk: "華歷簡奴", tw: "巴列卡諾" },
    { id: 8305, en: "Getafe", hans: "赫塔菲", hk: "基達菲", tw: "赫塔菲" },
    { id: 8558, en: "Espanyol", hans: "西班牙人", hk: "愛斯賓奴", tw: "西班牙人" },
    { id: 10267, en: "Valencia", legacy: ["华伦西亚"], hans: "瓦伦西亚", hk: "華倫西亞", tw: "瓦倫西亞" },
    { id: 9864, en: "Málaga", hans: "马拉加", hk: "馬拉加", tw: "馬拉加" },
  ] },
  { key: "seriea", en: "Serie A", hans: "意甲", hk: "意甲", tw: "意甲", teams: [
    { id: 8543, en: "Lazio", hans: "拉齐奥", hk: "拉素", tw: "拉齊奧" },
    { id: 8636, en: "Inter", legacy: ["国际米兰", "國際米蘭"], hans: "国米", hk: "國米", tw: "國米" },
    { id: 8686, en: "Roma", hans: "罗马", hk: "羅馬", tw: "羅馬" },
    { id: 10171, en: "Como", hans: "科莫", hk: "科莫", tw: "科莫" },
    { id: 8564, en: "Milan", legacy: ["AC米兰"], hans: "米兰", hk: "AC米蘭", tw: "AC米蘭" },
    { id: 9891, en: "Frosinone", hans: "弗罗西诺内", hk: "弗羅西諾內", tw: "弗羅西諾內" },
    { id: 9885, en: "Juventus", legacy: ["祖云达斯"], hans: "尤文", hk: "祖雲達斯", tw: "祖文特斯" },
    { id: 9804, en: "Torino", hans: "都灵", hk: "拖連奴", tw: "都靈" },
    { id: 8529, en: "Cagliari", hans: "卡利亚里", hk: "卡利亞里", tw: "卡利亞里" },
    { id: 9875, en: "Napoli", legacy: ["拿玻里"], hans: "那不勒斯", hk: "拿玻里", tw: "拿坡里" },
    { id: 8524, en: "Atalanta", hans: "亚特兰大", hk: "阿特蘭大", tw: "亞特蘭大" },
    { id: 9888, en: "Lecce", hans: "莱切", hk: "萊切", tw: "萊切" },
    { id: 9857, en: "Bologna", hans: "博洛尼亚", hk: "博洛尼亞", tw: "波隆那" },
    { id: 7943, en: "Sassuolo", hans: "萨索洛", hk: "薩斯索羅", tw: "薩索洛" },
    { id: 6504, en: "Monza", hans: "蒙扎", hk: "蒙沙", tw: "蒙扎" },
    { id: 10233, en: "Genoa", hans: "热那亚", hk: "熱拿亞", tw: "熱那亞" },
    { id: 8600, en: "Udinese", hans: "乌迪内斯", hk: "烏甸尼斯", tw: "烏迪內斯" },
    { id: 8535, en: "Fiorentina", hans: "佛罗伦萨", hk: "費倫天拿", tw: "佛羅倫斯" },
    { id: 10167, en: "Parma", hans: "帕尔马", hk: "帕爾馬", tw: "帕爾馬" },
    { id: 7881, en: "Venezia", hans: "威尼斯", hk: "威尼斯", tw: "威尼斯" },
  ] },
  { key: "bundesliga", en: "Bundesliga", hans: "德甲", hk: "德甲", tw: "德甲", teams: [
    { id: 9823, en: "Bayern München", aliases: ["Bayern", "Bayern Munich", "FC Bayern"], hans: "拜仁", hk: "拜仁", tw: "拜仁" },
    { id: 9789, en: "Borussia Dortmund", short: "Dortmund", legacy: ["多蒙特"], hans: "多特", hk: "多蒙特", tw: "多特蒙德" },
    { id: 8358, en: "Freiburg", hans: "弗赖堡", hk: "弗賴堡", tw: "弗萊堡" },
    { id: 8178, en: "Bayer Leverkusen", short: "Leverkusen", legacy: ["利华古逊"], hans: "勒沃库森", hk: "利華古遜", tw: "勒沃庫森" },
    { id: 178475, en: "RB Leipzig", hans: "莱比锡", hk: "萊比錫", tw: "萊比錫" },
    { id: 8697, en: "Werder Bremen", hans: "不莱梅", hk: "雲達不萊梅", tw: "雲達不萊梅" },
    { id: 9905, en: "Mainz 05", short: "Mainz", hans: "美因茨", hk: "緬恩斯", tw: "美因茨" },
    { id: 8232, en: "Elversberg", hans: "埃尔弗斯贝格", hk: "艾華斯堡", tw: "艾爾弗斯貝格" },
    { id: 8406, en: "Augsburg", hans: "奥格斯堡", hk: "奧格斯堡", tw: "奧格斯堡" },
    { id: 8226, en: "Hoffenheim", hans: "霍芬海姆", hk: "賀芬咸", tw: "霍芬海姆" },
    { id: 9790, en: "Hamburger SV", hans: "汉堡", hk: "漢堡", tw: "漢堡" },
    { id: 8722, en: "1. FC Köln", short: "Köln", hans: "科隆", hk: "科隆", tw: "科隆" },
    { id: 8460, en: "Paderborn", hans: "帕德博恩", hk: "柏達邦", tw: "帕德博恩" },
    { id: 9810, en: "Eintracht Frankfurt", short: "Frankfurt", hans: "法兰克福", hk: "法蘭克福", tw: "法蘭克福" },
    { id: 10269, en: "VfB Stuttgart", hans: "斯图加特", hk: "史特加", tw: "斯圖加特" },
    { id: 10189, en: "Schalke 04", hans: "沙尔克", hk: "史浩克04", tw: "沙爾克04" },
    { id: 8149, en: "Union Berlin", hans: "柏林联合", hk: "柏林聯", tw: "柏林聯" },
    { id: 9788, en: "Borussia Mönchengladbach", short: "M'gladbach", hans: "门兴", hk: "慕遜加柏", tw: "門興" },
  ] },
  { key: "ligue1", en: "Ligue 1", hans: "法甲", hk: "法甲", tw: "法甲", teams: [
    { id: 9847, en: "Paris Saint-Germain", short: "PSG", aliases: ["Paris Saint Germain", "Paris SG"], hans: "巴黎", hk: "巴黎", tw: "巴黎" },
    { id: 9851, en: "Rennes", hans: "雷恩", hk: "雷恩", tw: "雷恩" },
    { id: 8639, en: "Lille", hans: "里尔", hk: "里爾", tw: "里爾" },
    { id: 9829, en: "Monaco", hans: "摩纳哥", hk: "摩納哥", tw: "摩納哥" },
    { id: 9748, en: "Lyon", hans: "里昂", hk: "里昂", tw: "里昂" },
    { id: 6379, en: "Paris FC", hans: "巴黎FC", hk: "巴黎FC", tw: "巴黎FC" },
    { id: 8588, en: "Lens", hans: "朗斯", hk: "朗斯", tw: "朗斯" },
    { id: 8592, en: "Marseille", hans: "马赛", hk: "馬賽", tw: "馬賽" },
    { id: 8689, en: "Lorient", hans: "洛里昂", hk: "羅連安特", tw: "洛里昂" },
    { id: 9831, en: "Nice", hans: "尼斯", hk: "尼斯", tw: "尼斯" },
    { id: 9941, en: "Toulouse", hans: "图卢兹", hk: "圖盧茲", tw: "圖盧茲" },
    { id: 8583, en: "Auxerre", hans: "欧塞尔", hk: "歐塞爾", tw: "歐塞爾" },
    { id: 8521, en: "Brest", hans: "布雷斯特", hk: "布雷斯特", tw: "布雷斯特" },
    { id: 8121, en: "Angers", hans: "昂热", hk: "昂熱", tw: "昂熱" },
    { id: 8682, en: "Le Mans", hans: "勒芒", hk: "勒芒", tw: "勒芒" },
    { id: 9848, en: "Strasbourg", hans: "斯特拉斯堡", hk: "史特拉斯堡", tw: "斯特拉斯堡" },
    { id: 10242, en: "Troyes", hans: "特鲁瓦", hk: "特魯瓦", tw: "特魯瓦" },
    { id: 9746, en: "Le Havre", hans: "勒阿弗尔", hk: "勒哈弗爾", tw: "勒阿弗爾" },
  ] },
  { key: "ligaportugal", en: "Liga Portugal", hans: "葡超", hk: "葡超", tw: "葡超", teams: [
    { id: 9773, en: "FC Porto", legacy: ["波图"], hans: "波尔图", hk: "波圖", tw: "波爾圖" },
    { id: 9772, en: "Benfica", legacy: ["宾菲加"], hans: "本菲卡", hk: "賓菲加", tw: "本菲卡" },
    { id: 9768, en: "Sporting CP", hans: "葡萄牙体育", hk: "士砵亭", tw: "葡萄牙體育" },
    { id: 1567, en: "Santa Clara", hans: "圣克拉拉", hk: "聖卡拉拉", tw: "聖克拉拉" },
    { id: 158085, en: "Arouca", hans: "阿罗卡", hk: "阿洛卡", tw: "阿羅卡" },
    { id: 1786, en: "Académico Viseu", hans: "维塞乌", hk: "維塞烏", tw: "維塞烏" },
    { id: 9764, en: "Gil Vicente", hans: "吉维森特", hk: "基爾維辛迪", tw: "吉維森特" },
    { id: 9780, en: "Alverca", hans: "阿尔维卡", hk: "阿華卡", tw: "阿爾維卡" },
    { id: 10264, en: "Braga", hans: "布拉加", hk: "布拉加", tw: "布拉加" },
    { id: 8348, en: "Moreirense", hans: "莫雷伦斯", hk: "莫里倫斯", tw: "莫雷倫斯" },
    { id: 1634, en: "Famalicão", hans: "法马利康", hk: "法馬利卡奧", tw: "法馬利康" },
    { id: 1074320, en: "Estrela da Amadora", hans: "阿马多拉之星", hk: "艾馬多拉星", tw: "阿馬多拉之星" },
    { id: 7844, en: "Vitória de Guimarães", hans: "吉马良斯", hk: "甘馬雷斯", tw: "吉馬良斯" },
    { id: 10212, en: "Marítimo", hans: "马里迪莫", hk: "馬里迪莫", tw: "馬里迪莫" },
    { id: 10214, en: "Nacional", hans: "国民队", hk: "國民隊", tw: "國民隊" },
    { id: 212821, en: "Casa Pia AC", hans: "卡萨皮亚", hk: "卡沙比亞", tw: "卡薩皮亞" },
    { id: 7841, en: "Rio Ave", hans: "里奥阿维", hk: "里奧艾維", tw: "里奧阿維" },
    { id: 7842, en: "Estoril", hans: "埃斯托里尔", hk: "艾斯托里爾", tw: "埃斯托里爾" },
  ] },
  { key: "eredivisie", en: "Eredivisie", hans: "荷甲", hk: "荷甲", tw: "荷甲", teams: [
    { id: 10235, en: "Feyenoord", legacy: ["飞燕诺"], hans: "费耶诺德", hk: "飛燕諾", tw: "飛燕諾" },
    { id: 8593, en: "Ajax", legacy: ["阿积士"], hans: "阿贾克斯", hk: "阿積士", tw: "阿賈克斯" },
    { id: 8640, en: "PSV Eindhoven", hans: "埃因霍温", hk: "燕豪芬", tw: "埃因霍溫" },
    { id: 8611, en: "FC Twente", hans: "特温特", hk: "川迪", tw: "特溫特" },
    { id: 10229, en: "AZ Alkmaar", hans: "阿尔克马尔", hk: "阿爾克馬爾", tw: "阿爾克馬爾" },
    { id: 6422, en: "Fortuna Sittard", hans: "福图纳锡塔德", hk: "幸運薛達", tw: "福圖納錫塔德" },
    { id: 10228, en: "SC Heerenveen", hans: "海伦芬", hk: "海倫芬", tw: "海倫芬" },
    { id: 8674, en: "FC Groningen", hans: "格罗宁根", hk: "格羅寧根", tw: "格羅寧根" },
    { id: 6433, en: "Go Ahead Eagles", hans: "前进之鹰", hk: "前進之鷹", tw: "前進之鷹" },
    { id: 7788, en: "Cambuur", hans: "坎布尔", hk: "甘堡爾", tw: "坎布爾" },
    { id: 9908, en: "FC Utrecht", hans: "乌得勒支", hk: "烏德勒支", tw: "烏德勒支" },
    { id: 8464, en: "NEC Nijmegen", hans: "奈梅亨", hk: "尼美根", tw: "奈梅亨" },
    { id: 10218, en: "Excelsior", hans: "精英队", hk: "精英隊", tw: "精英隊" },
    { id: 8614, en: "Sparta Rotterdam", hans: "鹿特丹斯巴达", hk: "鹿特丹斯巴達", tw: "鹿特丹斯巴達" },
    { id: 6413, en: "PEC Zwolle", hans: "兹沃勒", hk: "施禾利", tw: "茲沃勒" },
    { id: 6414, en: "Telstar", hans: "特尔斯达", hk: "泰斯達", tw: "特爾斯達" },
    { id: 10217, en: "ADO Den Haag", hans: "海牙", hk: "海牙", tw: "海牙" },
    { id: 8525, en: "Willem II", hans: "威廉二世", hk: "威廉二世", tw: "威廉二世" },
  ] },
  { key: "scotprem", en: "Scottish Premiership", hans: "苏超", hk: "蘇超", tw: "蘇超", teams: [
    { id: 9925, en: "Celtic", hans: "凯尔特人", hk: "些路迪", tw: "塞爾提克" },
    { id: 8548, en: "Rangers", hans: "流浪者", hk: "格拉斯哥流浪", tw: "流浪者" },
    { id: 9860, en: "Heart of Midlothian", short: "Hearts", hans: "哈茨", hk: "赫斯", tw: "哈茨" },
    { id: 9938, en: "Dundee United", hans: "邓迪联", hk: "登地聯", tw: "鄧迪聯" },
    { id: 8284, en: "Dundee FC", short: "Dundee", hans: "邓迪", hk: "登地", tw: "鄧迪" },
    { id: 9800, en: "St. Mirren", hans: "圣米伦", hk: "聖美倫", tw: "聖米倫" },
    { id: 8596, en: "Falkirk", hans: "福尔柯克", hk: "福爾柯克", tw: "福爾柯克" },
    { id: 8467, en: "St. Johnstone", hans: "圣约翰斯通", hk: "聖莊士東", tw: "聖約翰斯通" },
    { id: 8485, en: "Aberdeen", hans: "阿伯丁", hk: "鴨巴甸", tw: "亞伯丁" },
    { id: 9927, en: "Motherwell", hans: "马瑟韦尔", hk: "馬瑟韋爾", tw: "馬瑟韋爾" },
    { id: 8597, en: "Kilmarnock", hans: "基尔马诺克", hk: "基爾馬諾克", tw: "基爾馬諾克" },
    { id: 10251, en: "Hibernian", hans: "希伯尼安", hk: "喜伯年", tw: "希伯尼安" },
  ] },
  { key: "championship", en: "EFL Championship", hans: "英冠", hk: "英冠", tw: "英冠", teams: [
    { id: 8549, en: "Middlesbrough", hans: "米德尔斯堡", hk: "米杜士堡", tw: "米德爾斯堡" },
    { id: 10003, en: "Swansea City", short: "Swansea", hans: "斯旺西", hk: "史雲斯", tw: "斯旺西" },
    { id: 8654, en: "West Ham United", short: "West Ham", legacy: ["韦斯咸"], hans: "西汉姆", hk: "韋斯咸", tw: "西漢姆" },
    { id: 8602, en: "Wolverhampton Wanderers", short: "Wolves", hans: "狼队", hk: "狼隊", tw: "狼隊" },
    { id: 8659, en: "West Bromwich Albion", short: "West Brom", hans: "西布朗", hk: "西布朗", tw: "西布朗" },
    { id: 8466, en: "Southampton", hans: "南安普顿", hk: "修咸頓", tw: "南安普敦" },
    { id: 8658, en: "Birmingham City", short: "Birmingham", hans: "伯明翰", hk: "伯明翰", tw: "伯明翰" },
    { id: 10172, en: "Queens Park Rangers", short: "QPR", hans: "女王公园巡游者", hk: "昆士柏流浪", tw: "女王公園巡遊者" },
    { id: 10194, en: "Stoke City", short: "Stoke", hans: "斯托克城", hk: "史篤城", tw: "斯托克城" },
    { id: 8655, en: "Blackburn Rovers", short: "Blackburn", hans: "布莱克本", hk: "布力般流浪", tw: "布萊克本" },
    { id: 8462, en: "Portsmouth", hans: "朴茨茅斯", hk: "樸茨茅夫", tw: "樸茨茅斯" },
    { id: 8657, en: "Sheffield United", short: "Sheff Utd", hans: "谢菲尔德联", hk: "錫菲聯", tw: "謝菲爾德聯" },
    { id: 10004, en: "Millwall", hans: "米尔沃尔", hk: "米禾爾", tw: "米爾沃爾" },
    { id: 8427, en: "Bristol City", hans: "布里斯托尔城", hk: "布里斯托城", tw: "布里斯托城" },
    { id: 8430, en: "Lincoln City", short: "Lincoln", hans: "林肯城", hk: "林肯城", tw: "林肯城" },
    { id: 8344, en: "Cardiff City", short: "Cardiff", hans: "卡迪夫城", hk: "卡迪夫城", tw: "卡迪夫城" },
    { id: 9841, en: "Wrexham", hans: "雷克瑟姆", hk: "域斯咸", tw: "雷克瑟姆" },
    { id: 8559, en: "Bolton Wanderers", short: "Bolton", hans: "博尔顿", hk: "保頓", tw: "博爾頓" },
    { id: 8451, en: "Charlton Athletic", short: "Charlton", hans: "查尔顿", hk: "查爾頓", tw: "查爾頓" },
    { id: 9850, en: "Norwich City", short: "Norwich", hans: "诺维奇", hk: "諾域治", tw: "諾維奇" },
    { id: 9817, en: "Watford", hans: "沃特福德", hk: "屈福特", tw: "沃特福德" },
    { id: 8191, en: "Burnley", hans: "伯恩利", hk: "般尼", tw: "伯恩利" },
    { id: 10170, en: "Derby County", short: "Derby", hans: "德比郡", hk: "打比郡", tw: "德比郡" },
    { id: 8411, en: "Preston North End", short: "Preston", hans: "普雷斯顿", hk: "普雷斯頓", tw: "普雷斯頓" },
  ] },
  { key: "csl", en: "Chinese Super League", hans: "中超", hk: "中超", tw: "中超", teams: [
    { id: 4177, en: "Beijing Guoan", hans: "北京国安", hk: "北京國安", tw: "北京國安" },
    { id: 737052, en: "Chengdu Rongcheng FC", hans: "成都蓉城", hk: "成都蓉城", tw: "成都蓉城" },
    { id: 1477050, en: "Chongqing Tongliang Long", hans: "重庆铜梁龙", hk: "重慶銅梁龍", tw: "重慶銅梁龍" },
    { id: 1477043, en: "Dalian Yingbo", hans: "大连英博", hk: "大連英博", tw: "大連英博" },
    { id: 51442, en: "Henan FC", short: "Henan", hans: "河南", hk: "河南", tw: "河南" },
    { id: 737054, en: "Liaoning Tieren", hans: "辽宁铁人", hk: "遼寧鐵人", tw: "遼寧鐵人" },
    { id: 4183, en: "Qingdao Hainiu", hans: "青岛海牛", hk: "青島海牛", tw: "青島海牛" },
    { id: 1283248, en: "Qingdao West Coast", hans: "青岛西海岸", hk: "青島西海岸", tw: "青島西海岸" },
    { id: 8623, en: "Shandong Taishan", hans: "山东泰山", hk: "山東泰山", tw: "山東泰山" },
    { id: 198616, en: "Shanghai Port", hans: "上海海港", hk: "上海海港", tw: "上海海港" },
    { id: 6628, en: "Shanghai Shenhua", hans: "上海申花", hk: "上海申花", tw: "上海申花" },
    { id: 930027, en: "Shenzhen Peng City", hans: "深圳新鹏城", hk: "深圳新鵬城", tw: "深圳新鵬城" },
    { id: 4189, en: "Tianjin Jinmen Tiger", hans: "天津津门虎", hk: "天津津門虎", tw: "天津津門虎" },
    { id: 1029687, en: "Wuhan Three Towns", hans: "武汉三镇", hk: "武漢三鎮", tw: "武漢三鎮" },
    { id: 1477056, en: "Yunnan Yukun", hans: "云南玉昆", hk: "雲南玉昆", tw: "雲南玉昆" },
    { id: 51443, en: "Zhejiang Professional", short: "Zhejiang", hans: "浙江", hk: "浙江", tw: "浙江" },
  ] },
  { key: "j1", en: "J1 League", hans: "日职联", hk: "日職聯", tw: "日職聯", teams: [
    { id: 8270, en: "Avispa Fukuoka", hans: "福冈黄蜂", hk: "福岡黃蜂", tw: "福岡黃蜂" },
    { id: 4692, en: "Cerezo Osaka", hans: "大阪樱花", hk: "大阪櫻花", tw: "大阪櫻花" },
    { id: 4399, en: "FC Tokyo", hans: "FC东京", hk: "FC東京", tw: "FC東京" },
    { id: 164739, en: "Fagiano Okayama FC", hans: "冈山绿雉", hk: "岡山綠雉", tw: "岡山綠雉" },
    { id: 6582, en: "Gamba Osaka", hans: "大阪钢巴", hk: "大阪鋼巴", tw: "大阪鋼巴" },
    { id: 9756, en: "JEF United Chiba", short: "JEF United", hans: "千叶市原", hk: "千葉市原", tw: "千葉市原" },
    { id: 4397, en: "Kashima Antlers", hans: "鹿岛鹿角", hk: "鹿島鹿角", tw: "鹿島鹿角" },
    { id: 8699, en: "Kashiwa Reysol", hans: "柏太阳神", hk: "柏太陽神", tw: "柏太陽神" },
    { id: 6304, en: "Kawasaki Frontale", hans: "川崎前锋", hk: "川崎前鋒", tw: "川崎前鋒" },
    { id: 8542, en: "Kyoto Sanga FC", hans: "京都不死鸟", hk: "京都不死鳥", tw: "京都不死鳥" },
    { id: 194011, en: "Machida Zelvia", hans: "町田泽维亚", hk: "町田澤維亞", tw: "町田澤維亞" },
    { id: 162195, en: "Mito Hollyhock", hans: "水户蜀葵", hk: "水戶蜀葵", tw: "水戶蜀葵" },
    { id: 8006, en: "Nagoya Grampus", hans: "名古屋鲸八", hk: "名古屋鯨八", tw: "名古屋鯨八" },
    { id: 6224, en: "Sanfrecce Hiroshima", hans: "广岛三箭", hk: "廣島三箭", tw: "廣島三箭" },
    { id: 4426, en: "Shimizu S-Pulse", hans: "清水鼓动", hk: "清水鼓動", tw: "清水鼓動" },
    { id: 6223, en: "Tokyo Verdy", hans: "东京绿茵", hk: "東京綠茵", tw: "東京綠茵" },
    { id: 6244, en: "Urawa Red Diamonds", hans: "浦和红钻", hk: "浦和紅鑽", tw: "浦和紅鑽" },
    { id: 194016, en: "V-Varen Nagasaki", hans: "长崎成功丸", hk: "長崎成功丸", tw: "長崎成功丸" },
    { id: 4688, en: "Vissel Kobe", hans: "神户胜利船", hk: "神戶勝利船", tw: "神戶勝利船" },
    { id: 6581, en: "Yokohama F.Marinos", hans: "横滨水手", hk: "橫濱水手", tw: "橫濱水手" },
  ] },

]

/** 中文名／英文名 → 引擎对照（由 LEAGUES 生成；旧清单解析、新菜单过滤共用） */
export const ZH_TEAMS: Record<string, { names: string[]; id: number }> = {}
for (const lg of LEAGUES) {
  for (const t of lg.teams) {
    const names = [t.en.toLowerCase()]
    if (t.short != null && t.short.toLowerCase() !== t.en.toLowerCase()) names.push(t.short.toLowerCase())
    for (const a of t.aliases ?? []) if (!names.includes(a.toLowerCase())) names.push(a.toLowerCase())
    const entry = { names, id: t.id }
    for (const k of [t.hans, t.hk, t.tw, t.en, t.en.toLowerCase(), ...(t.aliases ?? []), ...(t.legacy ?? [])]) ZH_TEAMS[k] = entry
    for (const a of t.aliases ?? []) ZH_TEAMS[a.toLowerCase()] = entry
  }
}

/** 菜单语言：跟手机系统语言（简体／香港繁体／台湾繁体／其他一律英文） */
export function displayLocale(): "hans" | "hk" | "tw" | "en" {
  let loc = ""
  try { loc = Intl.DateTimeFormat().resolvedOptions().locale ?? "" } catch { loc = "" }
  const l = loc.toLowerCase()
  if (l.startsWith("zh")) {
    if (l.includes("hans") || l.includes("cn") || l.includes("sg")) return "hans"
    if (l.includes("tw")) return "tw"
    return "hk"
  }
  return "en"
}

/** 半场标签：1.0.14 起所有语言都用 HT，跟 FotMob 官方小组件（同主版 v1.1.86 一致；
 *  之前中文出「半场」／「半場」，loc 参数保留防调用处断链） */
export function halftimeLabel(_loc: "hans" | "hk" | "tw" | "en"): string {
  return "HT"
}

/** 某联赛入面未关注嘅球队（按编号＋英文名双重比对，唔同语言写法都认） */
export function leagueTeamOptions(leagueKey: string, followed: string[]): TeamDef[] {
  const lg = LEAGUES.find((x) => x.key === leagueKey) ?? LEAGUES[0]
  const f = parseTeamsText(followed.join("\n"))
  return lg.teams.filter((t) => {
    if (f.ids.has(t.id)) return false
    const all = [t.en.toLowerCase(), ...(t.short != null ? [t.short.toLowerCase()] : []), ...(t.aliases ?? []).map((a) => a.toLowerCase())]
    return !all.some((n) => f.names.has(n))
  })
}

const TEAM_BY_ID: Record<number, TeamDef> = {}
for (const lg of LEAGUES) for (const t of lg.teams) TEAM_BY_ID[t.id] = t

/** 页面标签用：将存起嘅球队写法（默认 10 间／添加时存嘅显示名／旧清单）转返当前语言显示名；认唔到就原文照显示（英文名／简称本身就系通用写法，唔好硬转，例如 PSG 唔变巴黎） */
export function displayStoredTeam(name: string, loc: "hans" | "hk" | "tw" | "en"): string {
  const t = name.trim()
  if (/^\d+$/.test(t)) {
    const def = TEAM_BY_ID[parseInt(t, 10)]
    return def ? def[loc] : t
  }
  const zh = ZH_TEAMS[t] ?? ZH_TEAMS[t.toLowerCase()]
  if (zh != null) {
    const def = TEAM_BY_ID[zh.id]
    if (def) return def[loc]
  }
  return t
}

export type ParsedTeams = {
  /** 有冇存到有效内容（冇即用默认 10 间） */
  active: boolean
  /** 去重后嘅原文行（照用户输入显示用） */
  raw: string[]
  ids: Set<number>
  names: Set<string>
  /** 未能识别嘅行（照英文名原文匹配，可能仍然命中 FotMob 全名） */
  unknown: string[]
}

/** 解析用户填写嘅球队文字：分隔符系换行／逗号／顿号／分号；数字当 FotMob 编号 */
export function parseTeamsText(text: string): ParsedTeams {
  const raw: string[] = []
  const seen = new Set<string>()
  for (const tok of text.split(/[\n,，、;；]+/)) {
    const t = tok.trim()
    if (!t) continue
    const key = t.toLowerCase()
    if (seen.has(key)) continue
    seen.add(key)
    raw.push(t)
  }
  const ids = new Set<number>()
  const names = new Set<string>()
  const unknown: string[] = []
  for (const t of raw) {
    if (/^\d+$/.test(t)) { ids.add(parseInt(t, 10)); continue }
    const zh = ZH_TEAMS[t] ?? ZH_TEAMS[t.toLowerCase()]
    if (zh) { zh.names.forEach((n) => names.add(n)); if (zh.id != null) ids.add(zh.id); continue }
    const n = norm(t)
    if (CLUB_NAMES.has(n) || CODE_MAP[n] != null) { names.add(n); continue }
    names.add(n)
    unknown.push(t)
  }
  return { active: raw.length > 0, raw, ids, names, unknown }
}

export type ActiveClubs = { ids: Set<number>; names: Set<string>; nt: NTSettings; derbyPairs: Set<string> }

/** 当前生效嘅球会集合：有自定义即取代默认 10 间（唔系叠加，删行即系剔走）；国家队规则（排名范围＋单选并集）喺 active.nt */
export function getActiveClubs(): ActiveClubs {
  const saved = Storage.get<string>(teamsKey)
  const derbyPairs = derbyPairsFor(getDerbySettings().picks)
  if (saved == null || saved.trim() === "") return { ids: CLUB_IDS, names: CLUB_NAMES, nt: getNTSettings(), derbyPairs }
  const p = parseTeamsText(saved)
  return { ids: p.ids, names: p.names, nt: getNTSettings(), derbyPairs }
}
const LEAGUE_LOGO = (id: number) => `https://images.fotmob.com/image_resources/logo/leaguelogo/${id}.png`
const UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"

function norm(name: string): string {
  const n = (name ?? "").trim().toLowerCase()
  return ALIASES[n] ?? n
}

function teamCode(name: string): string {
  const n = norm(name)
  if (CODE_MAP[n]) return CODE_MAP[n]
  const letters = n.replace(/[^a-z]/g, "")
  return letters.slice(0, 3).toUpperCase() || "???"
}


export const NT_CUTOFFS = [10, 20, 30, 40, 50]
export type NTSettings = { picks: Set<string> }
/** 旧默认国家队（v1.1.67 前用；v1.1.68 起默认零间，呢个函数净系做旧档默认 40 识别用） */
export function defaultNTKeys(): string[] {
  return NT_RANKING.slice(0, 40).map((nt) => nt.key)
}
/** 国家队设定（v1.1.68）：只存 picks 标签集，默认零间（恢复默认亦系零间）。
 *  迁移：旧档 {cutoff, picks} → picks = 排名 < cutoff ＋旧 picks；
 *  旧档（冇 v 标记）而 picks 啱啱等于默认前 40 → 当旧默认自动清零（用户未改过先会咁）；
 *  新档 {picks, v: 2} 照用（就算啱啱系前 40 都唔清，免得加完范围下次开页消失）。 */
export function getNTSettings(): NTSettings {
  try {
    const raw = Storage.get<{ cutoff?: unknown; picks?: unknown; v?: unknown }>(ntKey)
    if (raw == null || (typeof raw === "string" && raw === "")) return { picks: new Set() }
    const picks = new Set<string>()
    if (Array.isArray(raw?.picks)) for (const p of raw.picks) if (typeof p === "string" && NT_ALL.some((nt) => nt.key === p)) picks.add(p)
    if (typeof raw?.cutoff === "number" && NT_CUTOFFS.includes(raw.cutoff)) {
      for (let i = 0; i < raw.cutoff; i++) picks.add(NT_RANKING[i].key)
    }
    if (raw?.cutoff == null && !Array.isArray(raw?.picks)) return { picks: new Set() }
    if (raw?.v !== 2 && picks.size === 40 && defaultNTKeys().every((k) => picks.has(k))) return { picks: new Set() }
    return { picks }
  } catch {
    return { picks: new Set() }
  }
}
export function saveNTSettings(s: NTSettings): void {
  Storage.set(ntKey, { picks: [...s.picks], v: 2 })
}
export function resetNTSettings(): void {
  Storage.set(ntKey, "")
}
/** 批量删除国家队范围（1.0.17 起，主版 v1.1.94 同款移植）：由 picks 删走排名前 cutoff 支，
 *  返 { next, removed }；净删已经加咗嗰啲，范围外嘅标签唔郁。 */
export function removeNTRangeKeys(picks: Set<string>, cutoff: number): { next: Set<string>; removed: string[] } {
  const removed = NT_RANKING.slice(0, cutoff).map((nt) => nt.key).filter((k) => picks.has(k))
  const next = new Set([...picks].filter((k) => !removed.includes(k)))
  return { next, removed }
}
export type DerbySettings = { picks: Set<string> }
/** 打比设定：只存打比 key 标签集（批量添加嗰阵展开成逐个，见 index；默认零场）。
 *  匹配只认 FotMob 队编号对（主客顺序唔拘），唔做名匹配（VPS 场用 logo URL 编号，一样啱）。 */
export function getDerbySettings(): DerbySettings {
  try {
    const raw = Storage.get<{ picks?: unknown; v?: unknown }>(derbyKey)
    if (raw == null || (typeof raw === "string" && raw === "")) return { picks: new Set() }
    const picks = new Set<string>()
    if (Array.isArray(raw?.picks)) for (const p of raw.picks) if (typeof p === "string" && (DERBIES.some((d) => d.key === p) || /^dt:\d+-\d+$/.test(p))) picks.add(p)
    return { picks }
  } catch {
    return { picks: new Set() }
  }
}
export function saveDerbySettings(s: DerbySettings): void {
  Storage.set(derbyKey, { picks: [...s.picks], v: 2 })
}
export function resetDerbySettings(): void {
  Storage.set(derbyKey, "")
}
/** 打比对 key（主客顺序唔拘）：细编号在前 */
export function derbyPairKey(a: number, b: number): string {
  return a <= b ? `${a}-${b}` : `${b}-${a}`
}
export function derbyPairsFor(picks: Set<string>): Set<string> {
  const out = new Set<string>()
  for (const k of picks) {
    const m = /^dt:(\d+)-(\d+)$/.exec(k)
    if (m != null) {
      out.add(derbyPairKey(parseInt(m[1], 10), parseInt(m[2], 10)))
      continue
    }
    const d = DERBIES.find((x) => x.key === k)
    if (d) out.add(derbyPairKey(d.a, d.b))
  }
  return out
}
/** 默认球队打比（1.0.16 起，主版 v1.1.91–v1.1.93 同款移植）：唔系一个总开关，系逐对拣——
 *  默认 10 间球队两两配对，再剔走对入面已有关注球队嘅配对（例如已经选咗曼联，曼联嘅
 *  比赛本身已经喺小组件度，唔使再喺呢度拣），剩低两队都未关注嘅先出；每对一个 pick，
 *  key 系 "dt:A-B"（A<B，FotMob 编号对）；存喺打比 picks 入面，唔喺 DERBIES 入面。 */
export function defaultDerbyPairKeys(): string[] {
  const followed = getActiveClubs().ids
  const ids = [...CLUB_IDS].sort((a, b) => a - b)
  const out: string[] = []
  for (let i = 0; i < ids.length; i++)
    for (let j = i + 1; j < ids.length; j++) {
      if (followed.has(ids[i]) || followed.has(ids[j])) continue
      out.push(`dt:${derbyPairKey(ids[i], ids[j])}`)
    }
  return out
}
export function derbiesByCat(cat: string): typeof DERBIES {
  return DERBIES.filter((d) => d.cat === cat)
}
export function derbyTeamName(id: number, loc: string): string {
  const t = DERBY_TEAMS.find((x) => x.id === id)
  if (t == null) return String(id)
  if (loc === "en") return t.en
  if (loc === "tw") return t.tw
  if (loc === "hk") return t.hk
  return t.hans
}
export function derbyCatName(cat: string, loc: string): string {
  const c = DERBY_CATS.find((x) => x.key === cat)
  if (c == null) return cat
  if (loc === "en") return c.en
  if (loc === "tw") return c.tw
  if (loc === "hk") return c.hk
  return c.hans
}
/** 球会显示名（默认球队打比标签用）：联赛表有就用当前语言名，冇就用打比队表名 */
export function clubDisplayName(id: number, loc: string): string {
  const def = TEAM_BY_ID[id]
  if (def != null) {
    if (loc === "en") return def.en
    if (loc === "tw") return def.tw
    if (loc === "hk") return def.hk
    return def.hans
  }
  return derbyTeamName(id, loc)
}
export function derbyLabel(key: string, loc: string): string {
  // 默认球队打比（1.0.16 起）：标签净系 "A vs B"，唔写后缀（名打比后缀照旧）
  const m = /^dt:(\d+)-(\d+)$/.exec(key)
  if (m != null) {
    return `${clubDisplayName(parseInt(m[1], 10), loc)} vs ${clubDisplayName(parseInt(m[2], 10), loc)}`
  }
  const d = DERBIES.find((x) => x.key === key)
  if (d == null) return key
  const nick = loc === "en" ? d.en : loc === "tw" ? d.tw : loc === "hk" ? d.hk : d.hans
  return `${derbyTeamName(d.a, loc)} vs ${derbyTeamName(d.b, loc)}（${nick}）`
}

let _ntMap: Map<string, string> | null = null
function ntMap(): Map<string, string> {
  if (_ntMap) return _ntMap
  const m = new Map<string, string>()
  for (const nt of NT_ALL) {
    for (const n of [nt.key, nt.en, ...(nt.aliases ?? [])]) m.set(norm(n), nt.key)
  }
  _ntMap = m
  return m
}
export function ntKeyForName(name: string): string | null {
  return ntMap().get(norm(name)) ?? null
}
export function ntKeyForNames(names: Set<string>): string | null {
  for (const n of names) {
    const k = ntKeyForName(n)
    if (k) return k
  }
  return null
}
/** 标签集命中即入选（v1.1.67 起冇隐含范围；删标签即真系剔走） */
export function ntIncluded(key: string | null, nt: NTSettings): boolean {
  if (key == null) return false
  return nt.picks.has(key)
}
/** 国家队显示名（独立版四语；主版页面用 loc === "en" ? en : hans） */
export function displayNTName(nt: NTDef, loc: string): string {
  if (loc === "en") return nt.en
  if (loc === "tw") return nt.tw
  if (loc === "hk") return nt.hk
  return nt.hans
}

function statusOf(m: any): { status: string; minute: number | null; ht: boolean } {
  const s = m.status ?? {}
  if (s.cancelled) return { status: "CANC", minute: null, ht: false }
  if (s.finished) {
    const short: string = s.reason?.short ?? "FT"
    // v1.1.60 修正：点球完场 reason.short 实测系 "Pen"（之前净写 "Pen." 命中唔到，误归 FT）
    const map: Record<string, string> = { FT: "FT", AET: "AET", Pen: "PEN", "Pen.": "PEN" }
    return { status: map[short] ?? "FT", minute: null, ht: false }
  }
  if (s.ongoing || "liveTime" in s) {
    const lt = s.liveTime ?? {}
    const ht = lt.short === "HT" || /^half/i.test(lt.long ?? "")
    let minute: number | null = null
    if (!ht) {
      // v1.1.61：点球途中按 FotMob 显示法定时间（basePeriod，90 分钟场即 90'），唔再显示点球比分
      if (lt.short === "Pen") minute = lt.basePeriod ?? 90
      else {
        const mm = /^(\d+)/.exec(lt.long ?? "")
        if (mm) minute = parseInt(mm[1], 10)
      }
    }
    return { status: "LIVE", minute, ht }
  }
  return { status: "NS", minute: null, ht: false }
}

function parseMatch(lg: any, m: any, active: ActiveClubs, dayYMD: string): Match | null {
  if (BLOCKED_MATCH_IDS.has(m.id)) return null
  const h = m.home
  const a = m.away
  const hnames = new Set([norm(h.name), norm(h.longName ?? "")])
  const anames = new Set([norm(a.name), norm(a.longName ?? "")])
  const hit = (s: Set<string>, t: Set<string>) => { for (const x of s) if (t.has(x)) return true; return false }
  const isClub = active.ids.has(h.id) || active.ids.has(a.id) || hit(hnames, active.names) || hit(anames, active.names)
  const isNT = ntIncluded(ntKeyForNames(hnames), active.nt) || ntIncluded(ntKeyForNames(anames), active.nt)
  const isDerby = active.derbyPairs.has(derbyPairKey(h.id, a.id))
  if (!isClub && !isNT && !isDerby) return null
  let ts: number | null = m.timeTS ?? null
  if (ts == null) ts = Date.parse(m.status?.utcTime)
  if (!Number.isFinite(ts)) return null
  const ko = new Date(ts)
  if (localYMD(ko) !== dayYMD) return null // 净收指定本地日期嘅比赛（手机时区）
  const { status, minute, ht } = statusOf(m)
  let gh: number | null = h.score ?? null
  let ga: number | null = a.score ?? null
  if (status === "NS" || status === "CANC") { gh = null; ga = null }
  const hn = h.longName ?? h.name
  const an = a.longName ?? a.name
  return {
    id: m.id,
    league: lg.parentLeagueName ?? lg.name ?? "",
    leagueLogo: lg.primaryId ? LEAGUE_LOGO(lg.primaryId) : "",
    home: { name: hn, code: teamCode(hn), logo: LOGO(h.id) },
    away: { name: an, code: teamCode(an), logo: LOGO(a.id) },
    date: ko.toISOString(),
    status,
    elapsed: minute,
    ht,
    gh,
    ga,
    ph: h.penScore ?? null,
    pa: a.penScore ?? null,
  }
}

/** 抓 FotMob 单日数据：AbortController 6 秒超时（v1.1.23） */
async function fetchFotmobDay(ymd: string): Promise<any> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), 6000)
  try {
    const res = await fetch(`https://www.fotmob.com/api/data/matches?date=${ymd}`, {
      headers: { "User-Agent": UA },
      signal: ctrl.signal,
    })
    if (!res.ok) throw new Error(`FotMob HTTP ${res.status}`)
    return await res.json()
  } finally {
    clearTimeout(timer)
  }
}

/** 指定手机本地日期横跨嘅 UTC 日期（YYYYMMDD）：本地一日最多横跨两个 UTC 日期
 *  （UTC 负时区 → {当日, 次日}；UTC 正时区 → {前日, 当日}；零时区 → {当日}） */
function utcDatesForLocalDay(localDay: string): string[] {
  const [y, mo, d] = localDay.split("-").map(Number)
  const fmt = (dt: Date) => dt.toISOString().slice(0, 10).replace(/-/g, "")
  const a = fmt(new Date(y, mo - 1, d, 0, 0, 0))
  const b = fmt(new Date(y, mo - 1, d, 23, 59, 59))
  return a === b ? [a] : [a, b]
}

/** 电话直抓 FotMob：指定手机本地日期嘅全部关注比赛（NS/LIVE/FT，带实时比分）
 *  fetched 系 UTC 日期页缓存（相邻本地日会共用同一 UTC 页，唔重复抓） */
async function fetchLocalDayMatches(
  localDay: string,
  active: ActiveClubs,
  fetched: Map<string, any>,
): Promise<Match[]> {
  const ymds = utcDatesForLocalDay(localDay)
  const pages = await Promise.all(ymds.map((ymd) => {
    const hit = fetched.get(ymd)
    if (hit !== undefined) return Promise.resolve(hit)
    return fetchFotmobDay(ymd).then((p) => { fetched.set(ymd, p); return p })
  }))
  const seen = new Set<number>()
  const out: Match[] = []
  for (const data of pages) {
    for (const lg of data.leagues ?? []) {
      const lname = String(lg.name ?? "").toLowerCase()
      if (JUNK_LEAGUE.some((j) => lname.includes(j))) continue
      for (const m of lg.matches ?? []) {
        if (seen.has(m.id)) continue
        seen.add(m.id)
        const pm = parseMatch(lg, m, active, localDay)
        if (pm) out.push(pm)
      }
    }
  }
  return out
}

function rankStatus(s: string): number {
  if (s === "NS" || s === "CANC") return 2
  if (s === "LIVE") return 1
  return 0 // FT / AET / PEN 等完场摆最上（v1.1.27 用户定）
}

function sortMatches(all: Match[]): void {
  all.sort(
    (a, b) =>
      rankStatus(a.status) - rankStatus(b.status) ||
      new Date(a.date).getTime() - new Date(b.date).getTime(),
  )
}

/**
 * 独立版刷新：全程电话直抓 FotMob，唔经任何私人服务器。
 * 今日比赛全部保留（完场比分留到今日结束），再逐日向后抓未来场次补足到 8 场
 * （第一阶段逐日向后 14 日，唔够再并行抓 15–28 日、每批 7 日；某日抓失败就跳过
 *  嗰日继续，唔拖死成个刷新）。
 * 今日内部排序：完场 → 进行中 → 未开波（v1.1.27 起）；未来场次按开球排序。
 * FotMob 今日抓失败 → 整体失败：保留 fetchedAt（上次成功时间），只记低尝试时间同错误，
 * 下次运行会即刻再试。
 */
export async function refreshFootball(): Promise<{ ok: boolean; error?: string }> {
  const now = Date.now()
  // 当前生效嘅关注球会（自定义有存即取代默认；国家队规则独立，parseMatch 内处理）
  const active = getActiveClubs()
  const fetched = new Map<string, any>()
  const todayStr = localYMD(new Date())

  let today: Match[]
  try {
    today = await fetchLocalDayMatches(todayStr, active, fetched)
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    const prev = Storage.get<FootballData>(footballKey)
    if (prev != null) {
      Storage.set(footballKey, { ...prev, lastAttemptAt: now, lastError: msg })
    } else {
      Storage.set(footballKey, { date: "", fetchedAt: 0, matches: [], lastAttemptAt: now, lastError: msg })
    }
    console.error("football refresh failed", msg)
    return { ok: false, error: msg }
  }
  sortMatches(today)

  const todayIds = new Set(today.map((m) => m.id))
  const need = Math.max(0, 8 - today.length)
  const upcoming: Match[] = []
  const [y, mo, d] = todayStr.split("-").map(Number)
  // v1.1.65：未来窗口由 7 日扩到 14 日；某日抓失败就跳过嗰日继续（唔再成个停），保证第八场系关注球队跟住落嚟最近嘅比赛
  for (let add = 1; add <= 14 && upcoming.length < need; add++) {
    const dt = new Date(y, mo - 1, d + add)
    const dayStr = localYMD(dt)
    let dayMatches: Match[] = []
    try {
      dayMatches = await fetchLocalDayMatches(dayStr, active, fetched)
    } catch {
      continue // 未来某日抓失败就跳过嗰日（已有今日数据，唔算整体失败）
    }
    const future = dayMatches
      .filter((m) => !todayIds.has(m.id) && new Date(m.date).getTime() > now)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    for (const m of future) {
      if (upcoming.length >= need) break
      upcoming.push(m)
    }
  }
  // 第二阶段（1.0.16 起，主版 v1.1.90 同款移植）：14 日内补唔满（例如国际比赛日空窗期，
  // 11 月 9–19 日零球会比赛，第 8 场要去到第 15 日），再并行抓第 15–28 日、每批 7 日，凑够即停
  for (let start = 15; start <= 28 && upcoming.length < need; start += 7) {
    const adds: number[] = []
    for (let add = start; add < start + 7 && add <= 28; add++) adds.push(add)
    const pages = await Promise.all(
      adds.map((add) => {
        const dt = new Date(y, mo - 1, d + add)
        return fetchLocalDayMatches(localYMD(dt), active, fetched).catch(() => [] as Match[])
      }),
    )
    for (const dayMatches of pages) {
      if (upcoming.length >= need) break
      const future = dayMatches
        .filter((m) => !todayIds.has(m.id) && new Date(m.date).getTime() > now)
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      for (const m of future) {
        if (upcoming.length >= need) break
        upcoming.push(m)
      }
    }
  }

  const matches: Match[] = [...today, ...upcoming]
  // 之前八场（1.0.13，主版 v1.1.85 同款移植，时区跟手机本地日）：
  // 分界 = 大号现时显示首 8 场入面最早开球嗰场；逐日向后抓手机本地日，
  // 只收早过呢个时间嘅已完场、最近 8 场；最多向后找 90 日，唔够就返揾到嘅场数；
  // 某日抓失败就跳过嗰日继续。过去抓失败／揾唔到就沿用旧缓存嘅之前场次，唔清零。
  let prevMatches: Match[] = []
  try {
    const displayed8 = matches.slice(0, 8)
    const beforeMs = displayed8.length > 0
      ? Math.min(...displayed8.map((m) => new Date(m.date).getTime()))
      : now
    const excludeIds = new Set(matches.map((m) => m.id))
    const out: Match[] = []
    for (let back = 0; back <= 90 && out.length < 8; back++) {
      const dt = new Date(y, mo - 1, d - back)
      const dayStr = localYMD(dt)
      let dayMatches: Match[] = []
      try {
        dayMatches = await fetchLocalDayMatches(dayStr, active, fetched)
      } catch {
        continue
      }
      for (const m of dayMatches) {
        if (excludeIds.has(m.id)) continue
        if (!DONE.has(m.status)) continue
        if (new Date(m.date).getTime() >= beforeMs) continue
        out.push(m)
      }
    }
    out.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    prevMatches = out.slice(-8)
  } catch (e) {
    console.error("football direct past failed", e)
    prevMatches = []
  }
  if (prevMatches.length === 0) {
    const prevCache = Storage.get<FootballData>(footballKey)
    if (prevCache?.prevMatches != null && prevCache.prevMatches.length > 0) prevMatches = prevCache.prevMatches
  }
  const data: FootballData = {
    date: todayStr,
    fetchedAt: now,
    lastAttemptAt: now,
    matches,
    prevMatches,
  }
  Storage.set(footballKey, data)
  return { ok: true }
}
