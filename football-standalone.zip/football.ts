import { FootballData, Match, footballKey, localYMD, teamsKey } from "./const"

// ============ FotMob 过滤（同 VPS update.py 一致，电话端直抓用） ============

const CLUB_IDS = new Set([10260, 8650, 9825, 8455, 8586, 8456, 8633, 8634, 9823, 9847])
// 用户 2026-10-27 要求删除：法国杯同名 Arsenal 假名场（Sporting BM vs Arsenal，GLP）
const BLOCKED_MATCH_IDS = new Set([6503684])
const CLUB_NAMES = new Set([
  "manchester united", "man utd", "manchester utd", "liverpool", "arsenal",
  "chelsea", "tottenham", "tottenham hotspur", "manchester city", "man city",
  "real madrid", "barcelona", "barca", "bayern", "bayern munich",
  "bayern münchen", "fc bayern", "psg", "paris saint germain",
  "paris saint-germain", "paris sg",
])
// FIFA 前 40（2026年9月排名）
const TOP40_NT = new Set([
  "spain", "argentina", "france", "england", "brazil", "morocco",
  "portugal", "belgium", "netherlands", "mexico", "colombia", "germany",
  "croatia", "switzerland", "italy", "usa", "united states", "japan",
  "senegal", "norway", "uruguay", "denmark", "iran", "austria", "egypt",
  "ecuador", "nigeria", "turkey", "australia", "algeria", "canada",
  "ivory coast", "south korea", "ukraine", "paraguay", "russia", "poland",
  "sweden", "wales", "hungary", "serbia",
])
const ALIASES: Record<string, string> = {
  "korea republic": "south korea",
  "ir iran": "iran",
  "côte d'ivoire": "ivory coast",
  "cote d'ivoire": "ivory coast",
  "turkiye": "turkey",
}
const JUNK_LEAGUE = [
  "kvinner", "damer", "women", "woman", "ladies", "female",
  "girls", "u21", "u20", "u19", "u18", "u17", "u16", "u15",
  "youth", "junior",
]
const CODE_MAP: Record<string, string> = {
  "manchester united": "MUN", "man united": "MUN", "man utd": "MUN",
  "liverpool": "LIV", "arsenal": "ARS", "chelsea": "CHE",
  "tottenham": "TOT", "tottenham hotspur": "TOT",
  "manchester city": "MCI", "man city": "MCI",
  "real madrid": "RMA", "barcelona": "BAR",
  "bayern münchen": "BAY", "bayern munich": "BAY", "fc bayern": "BAY",
  "paris saint-germain": "PSG", "paris saint germain": "PSG",
  "paris sg": "PSG", "psg": "PSG",
  "spain": "ESP", "argentina": "ARG", "france": "FRA", "england": "ENG",
  "brazil": "BRA", "morocco": "MAR", "portugal": "POR", "belgium": "BEL",
  "netherlands": "NED", "mexico": "MEX", "colombia": "COL", "germany": "GER",
  "croatia": "CRO", "switzerland": "SUI", "italy": "ITA",
  "usa": "USA", "united states": "USA",
  "japan": "JPN", "senegal": "SEN", "norway": "NOR", "uruguay": "URU",
  "denmark": "DEN", "iran": "IRN", "ir iran": "IRN",
  "austria": "AUT", "egypt": "EGY", "ecuador": "ECU", "nigeria": "NGA",
  "turkey": "TUR", "türkiye": "TUR", "turkiye": "TUR",
  "australia": "AUS", "algeria": "ALG", "canada": "CAN",
  "ivory coast": "CIV", "côte d'ivoire": "CIV", "cote d'ivoire": "CIV",
  "south korea": "KOR", "korea republic": "KOR",
  "ukraine": "UKR", "paraguay": "PAR", "russia": "RUS", "poland": "POL",
  "sweden": "SWE", "wales": "WAL", "hungary": "HUN", "serbia": "SRB",
}
const LOGO = (id: number) => `https://images.fotmob.com/image_resources/logo/teamlogo/${id}.png`

// ============ 自定义关注球队（v1.1.47：页面顶部填写，取代默认 10 间） ============

/** 中文名 → FotMob 对照：names 系全部可匹配嘅英文写法（短名＋全名），id 只写已经核实过嘅
 *  （VPS JSON／往期实测：曼联 10260、利物浦 8650、阿仙奴 9825、车路士 8455、热刺 8586、
 *  曼城 8456、拜仁 9823、PSG 9847；皇马／巴塞净用名匹配，唔估 id，免得错配） */
const ZH_TEAMS: Record<string, { names: string[]; id?: number }> = {
  "曼联": { names: ["manchester united", "man utd", "manchester utd", "man united"], id: 10260 },
  "曼聯": { names: ["manchester united", "man utd", "manchester utd", "man united"], id: 10260 },
  "利物浦": { names: ["liverpool"], id: 8650 },
  "阿仙奴": { names: ["arsenal"], id: 9825 },
  "阿森纳": { names: ["arsenal"], id: 9825 },
  "车路士": { names: ["chelsea"], id: 8455 },
  "切尔西": { names: ["chelsea"], id: 8455 },
  "热刺": { names: ["tottenham", "tottenham hotspur"], id: 8586 },
  "熱刺": { names: ["tottenham", "tottenham hotspur"], id: 8586 },
  "曼城": { names: ["manchester city", "man city"], id: 8456 },
  "皇马": { names: ["real madrid"] },
  "皇家马德里": { names: ["real madrid"] },
  "巴塞": { names: ["barcelona", "barca"] },
  "巴萨": { names: ["barcelona", "barca"] },
  "拜仁": { names: ["bayern", "bayern munich", "bayern münchen", "fc bayern"], id: 9823 },
  "巴黎": { names: ["paris saint-germain", "paris saint germain", "paris sg", "psg"], id: 9847 },
  "psg": { names: ["paris saint-germain", "paris saint germain", "paris sg", "psg"], id: 9847 },
  "纽卡素": { names: ["newcastle united"], id: 10261 },
  "阿士东维拉": { names: ["aston villa"], id: 10252 },
  "白礼顿": { names: ["brighton & hove albion"], id: 10204 },
  "韦斯咸": { names: ["west ham united"], id: 8654 },
  "爱华顿": { names: ["everton"], id: 8668 },
  "诺定咸森林": { names: ["nottingham forest"], id: 10203 },
  "富咸": { names: ["fulham"], id: 9879 },
  "马体会": { names: ["atlético madrid", "atletico madrid"], id: 9906 },
  "维拉利尔": { names: ["villarreal"], id: 10205 },
  "西维尔": { names: ["sevilla"], id: 8302 },
  "华伦西亚": { names: ["valencia"], id: 10267 },
  "国际米兰": { names: ["inter"], id: 8636 },
  "AC米兰": { names: ["milan"], id: 8564 },
  "祖云达斯": { names: ["juventus"], id: 9885 },
  "拿玻里": { names: ["napoli"], id: 9875 },
  "罗马": { names: ["roma"], id: 8686 },
  "多蒙特": { names: ["borussia dortmund"], id: 9789 },
  "利华古逊": { names: ["bayer leverkusen"], id: 8178 },
  "莱比锡": { names: ["rb leipzig"], id: 178475 },
  "阿积士": { names: ["ajax"], id: 8593 },
  "波图": { names: ["fc porto", "porto"], id: 9773 },
  "宾菲加": { names: ["benfica"], id: 9772 },
  "些路迪": { names: ["celtic"], id: 9925 },
  "格拉斯哥流浪": { names: ["rangers"], id: 8548 },
  "士砵亭": { names: ["sporting cp"], id: 9768 },
  "飞燕诺": { names: ["feyenoord"], id: 10235 },
}

/** 下拉菜单球队清单（显示名；默认 10 间行先，其余按联赛分组；新加 26 间嘅 id 全部经 FotMob 比赛数据核实） */
export const DROPDOWN_TEAMS = [
  "曼联", "利物浦", "阿仙奴", "车路士", "热刺", "曼城", "皇马", "巴塞", "拜仁", "PSG",
  "纽卡素", "阿士东维拉", "白礼顿", "韦斯咸", "爱华顿", "诺定咸森林", "富咸",
  "马体会", "维拉利尔", "西维尔", "华伦西亚",
  "国际米兰", "AC米兰", "祖云达斯", "拿玻里", "罗马",
  "多蒙特", "利华古逊", "莱比锡",
  "阿积士", "波图", "宾菲加", "些路迪", "格拉斯哥流浪", "士砵亭", "飞燕诺",
]

/** 下拉菜单可选球队：剔走已经关注嘅（按编号＋英文名双重比对，简繁／别名写法都认） */
export function dropdownOptions(followed: string[]): string[] {
  const f = parseTeamsText(followed.join("\n"))
  return DROPDOWN_TEAMS.filter((zh) => {
    const e = ZH_TEAMS[zh] ?? ZH_TEAMS[zh.toLowerCase()]
    if (e == null) return false
    if (e.id != null && f.ids.has(e.id)) return false
    return !e.names.some((n) => f.names.has(n))
  })
}

export type ParsedTeams = {
  /** 有冇存到有效内容（冇即用默认 10 间） */
  active: boolean
  /** 去重后嘅原文行（照用户输入显示用） */
  raw: string[]
  ids: Set<number>
  names: Set<string>
  /** 未能识别嘅行（照英文名原文匹配，可能仍然命中 FotMob 全名） */
  unknown: string[]
}

/** 解析用户填写嘅球队文字：分隔符系换行／逗号／顿号／分号；数字当 FotMob 编号 */
export function parseTeamsText(text: string): ParsedTeams {
  const raw: string[] = []
  const seen = new Set<string>()
  for (const tok of text.split(/[\n,，、;；]+/)) {
    const t = tok.trim()
    if (!t) continue
    const key = t.toLowerCase()
    if (seen.has(key)) continue
    seen.add(key)
    raw.push(t)
  }
  const ids = new Set<number>()
  const names = new Set<string>()
  const unknown: string[] = []
  for (const t of raw) {
    if (/^\d+$/.test(t)) { ids.add(parseInt(t, 10)); continue }
    const zh = ZH_TEAMS[t] ?? ZH_TEAMS[t.toLowerCase()]
    if (zh) { zh.names.forEach((n) => names.add(n)); if (zh.id != null) ids.add(zh.id); continue }
    const n = norm(t)
    if (CLUB_NAMES.has(n) || CODE_MAP[n] != null) { names.add(n); continue }
    names.add(n)
    unknown.push(t)
  }
  return { active: raw.length > 0, raw, ids, names, unknown }
}

export type ActiveClubs = { ids: Set<number>; names: Set<string> }

/** 当前生效嘅球会集合：有自定义即取代默认 10 间（唔系叠加，删行即系剔走）；国家队规则唔喺呢度，另计 */
export function getActiveClubs(): ActiveClubs {
  const saved = Storage.get<string>(teamsKey)
  if (saved == null || saved.trim() === "") return { ids: CLUB_IDS, names: CLUB_NAMES }
  const p = parseTeamsText(saved)
  return { ids: p.ids, names: p.names }
}
const LEAGUE_LOGO = (id: number) => `https://images.fotmob.com/image_resources/logo/leaguelogo/${id}.png`
const UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"

function norm(name: string): string {
  const n = (name ?? "").trim().toLowerCase()
  return ALIASES[n] ?? n
}

function teamCode(name: string): string {
  const n = norm(name)
  if (CODE_MAP[n]) return CODE_MAP[n]
  const letters = n.replace(/[^a-z]/g, "")
  return letters.slice(0, 3).toUpperCase() || "???"
}

function statusOf(m: any): { status: string; minute: number | null } {
  const s = m.status ?? {}
  if (s.cancelled) return { status: "CANC", minute: null }
  if (s.finished) {
    const short: string = s.reason?.short ?? "FT"
    const map: Record<string, string> = { FT: "FT", AET: "AET", "Pen.": "PEN" }
    return { status: map[short] ?? "FT", minute: null }
  }
  if (s.ongoing || "liveTime" in s) {
    let minute: number | null = null
    const mm = /^(\d+)/.exec(s.liveTime?.long ?? "")
    if (mm) minute = parseInt(mm[1], 10)
    return { status: "LIVE", minute }
  }
  return { status: "NS", minute: null }
}

function parseMatch(lg: any, m: any, active: ActiveClubs, dayYMD: string): Match | null {
  if (BLOCKED_MATCH_IDS.has(m.id)) return null
  const h = m.home
  const a = m.away
  const hnames = new Set([norm(h.name), norm(h.longName ?? "")])
  const anames = new Set([norm(a.name), norm(a.longName ?? "")])
  const hit = (s: Set<string>, t: Set<string>) => { for (const x of s) if (t.has(x)) return true; return false }
  const isClub = active.ids.has(h.id) || active.ids.has(a.id) || hit(hnames, active.names) || hit(anames, active.names)
  const isNT = hit(hnames, TOP40_NT) || hit(anames, TOP40_NT)
  if (!isClub && !isNT) return null
  let ts: number | null = m.timeTS ?? null
  if (ts == null) ts = Date.parse(m.status?.utcTime)
  if (!Number.isFinite(ts)) return null
  const ko = new Date(ts)
  if (localYMD(ko) !== dayYMD) return null // 净收指定本地日期嘅比赛（手机时区）
  const { status, minute } = statusOf(m)
  let gh: number | null = h.score ?? null
  let ga: number | null = a.score ?? null
  if (status === "NS" || status === "CANC") { gh = null; ga = null }
  const hn = h.longName ?? h.name
  const an = a.longName ?? a.name
  return {
    id: m.id,
    league: lg.parentLeagueName ?? lg.name ?? "",
    leagueLogo: lg.primaryId ? LEAGUE_LOGO(lg.primaryId) : "",
    home: { name: hn, code: teamCode(hn), logo: LOGO(h.id) },
    away: { name: an, code: teamCode(an), logo: LOGO(a.id) },
    date: ko.toISOString(),
    status,
    elapsed: minute,
    gh,
    ga,
  }
}

/** 抓 FotMob 单日数据：AbortController 6 秒超时（v1.1.23） */
async function fetchFotmobDay(ymd: string): Promise<any> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), 6000)
  try {
    const res = await fetch(`https://www.fotmob.com/api/data/matches?date=${ymd}`, {
      headers: { "User-Agent": UA },
      signal: ctrl.signal,
    })
    if (!res.ok) throw new Error(`FotMob HTTP ${res.status}`)
    return await res.json()
  } finally {
    clearTimeout(timer)
  }
}

/** 指定手机本地日期横跨嘅 UTC 日期（YYYYMMDD）：本地一日最多横跨两个 UTC 日期
 *  （UTC 负时区 → {当日, 次日}；UTC 正时区 → {前日, 当日}；零时区 → {当日}） */
function utcDatesForLocalDay(localDay: string): string[] {
  const [y, mo, d] = localDay.split("-").map(Number)
  const fmt = (dt: Date) => dt.toISOString().slice(0, 10).replace(/-/g, "")
  const a = fmt(new Date(y, mo - 1, d, 0, 0, 0))
  const b = fmt(new Date(y, mo - 1, d, 23, 59, 59))
  return a === b ? [a] : [a, b]
}

/** 电话直抓 FotMob：指定手机本地日期嘅全部关注比赛（NS/LIVE/FT，带实时比分）
 *  fetched 系 UTC 日期页缓存（相邻本地日会共用同一 UTC 页，唔重复抓） */
async function fetchLocalDayMatches(
  localDay: string,
  active: ActiveClubs,
  fetched: Map<string, any>,
): Promise<Match[]> {
  const ymds = utcDatesForLocalDay(localDay)
  const pages = await Promise.all(ymds.map((ymd) => {
    const hit = fetched.get(ymd)
    if (hit !== undefined) return Promise.resolve(hit)
    return fetchFotmobDay(ymd).then((p) => { fetched.set(ymd, p); return p })
  }))
  const seen = new Set<number>()
  const out: Match[] = []
  for (const data of pages) {
    for (const lg of data.leagues ?? []) {
      const lname = String(lg.name ?? "").toLowerCase()
      if (JUNK_LEAGUE.some((j) => lname.includes(j))) continue
      for (const m of lg.matches ?? []) {
        if (seen.has(m.id)) continue
        seen.add(m.id)
        const pm = parseMatch(lg, m, active, localDay)
        if (pm) out.push(pm)
      }
    }
  }
  return out
}

function rankStatus(s: string): number {
  if (s === "NS" || s === "CANC") return 2
  if (s === "LIVE") return 1
  return 0 // FT / AET / PEN 等完场摆最上（v1.1.27 用户定）
}

function sortMatches(all: Match[]): void {
  all.sort(
    (a, b) =>
      rankStatus(a.status) - rankStatus(b.status) ||
      new Date(a.date).getTime() - new Date(b.date).getTime(),
  )
}

/**
 * 独立版刷新：全程电话直抓 FotMob，唔经任何私人服务器。
 * 今日比赛全部保留（完场比分留到今日结束），再逐日向后抓未来场次补足到 8 场
 * （最多向后睇 7 日；某日抓失败就停，唔拖死成个刷新）。
 * 今日内部排序：完场 → 进行中 → 未开波（v1.1.27 起）；未来场次按开球排序。
 * FotMob 今日抓失败 → 整体失败：保留 fetchedAt（上次成功时间），只记低尝试时间同错误，
 * 下次运行会即刻再试。
 */
export async function refreshFootball(): Promise<{ ok: boolean; error?: string }> {
  const now = Date.now()
  // 当前生效嘅关注球会（自定义有存即取代默认；国家队规则独立，parseMatch 内处理）
  const active = getActiveClubs()
  const fetched = new Map<string, any>()
  const todayStr = localYMD(new Date())

  let today: Match[]
  try {
    today = await fetchLocalDayMatches(todayStr, active, fetched)
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    const prev = Storage.get<FootballData>(footballKey)
    if (prev != null) {
      Storage.set(footballKey, { ...prev, lastAttemptAt: now, lastError: msg })
    } else {
      Storage.set(footballKey, { date: "", fetchedAt: 0, matches: [], lastAttemptAt: now, lastError: msg })
    }
    console.error("football refresh failed", msg)
    return { ok: false, error: msg }
  }
  sortMatches(today)

  const todayIds = new Set(today.map((m) => m.id))
  const need = Math.max(0, 8 - today.length)
  const upcoming: Match[] = []
  const [y, mo, d] = todayStr.split("-").map(Number)
  for (let add = 1; add <= 7 && upcoming.length < need; add++) {
    const dt = new Date(y, mo - 1, d + add)
    const dayStr = localYMD(dt)
    let dayMatches: Match[] = []
    try {
      dayMatches = await fetchLocalDayMatches(dayStr, active, fetched)
    } catch {
      break // 未来某日抓失败就停（已有今日数据，唔算整体失败）
    }
    const future = dayMatches
      .filter((m) => !todayIds.has(m.id) && new Date(m.date).getTime() > now)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    for (const m of future) {
      if (upcoming.length >= need) break
      upcoming.push(m)
    }
  }

  const data: FootballData = {
    date: todayStr,
    fetchedAt: now,
    lastAttemptAt: now,
    matches: [...today, ...upcoming],
  }
  Storage.set(footballKey, data)
  return { ok: true }
}
