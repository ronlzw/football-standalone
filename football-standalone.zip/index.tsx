import {
  Button,
  Divider,
  FlowLayout,
  HStack,
  Image,
  Link,
  Navigation,
  NavigationStack,
  Picker,
  Script,
  ScrollView,
  Spacer,
  Text,
  Toggle,
  VStack,
  Widget,
  useEffect,
  useState,
} from "scripting"
import {
  FootballData,
  DONE,
  LIVE,
  Match,
  OFF,
  clockZh,
  footballKey,
  transparentKey,
  transparentLightInverseKey,
  transparentDarkInverseKey,
  fotmobUrl,
  isToday,
  koParts,
  phoneTimeZone,
  teamsKey,
} from "./const"
import { DERBY_CATS, DERBIES, defaultNTKeys, derbiesByCat, derbyCatName, derbyLabel, displayLocale, displayNTName, displayStoredTeam, getDerbySettings, getNTSettings, halftimeLabel, LEAGUES, leagueTeamOptions, NT_ALL, NT_RANKING, parseTeamsText, refreshFootball, resetDerbySettings, resetNTSettings, saveDerbySettings, saveNTSettings } from "./football"

/** 页面文案：四语书面语（简体／香港繁体／台湾繁体／英文），跟手机系统语言；球队名一律经 displayStoredTeam 转当前语言显示名；顶部 Matchday 大标题已删（用户 2026-10-28：顶距 80 都仲裁，唔保留都无所谓；顶距改 120 等第一行内容啱啱好喺导航栏下面）；2026-10-30 用户话页面顶部留白好大，顶距由 120 改 16（只改独立版，主版未郁） */
type Loc = "hans" | "hk" | "tw" | "en"
type PageStrings = {
  followed: string; hint: string; leagueTitle: string; teamTitle: string
  add: string; restore: string; allAdded: string
  alreadyHave: (d: string) => string; added: (d: string) => string; restored: string; removed: (n: string) => string
  liveN: (n: number) => string; todayN: (n: number) => string; futureN: (n: number) => string
  noFixtures: string; loadFailed: string; updated: string; refreshFailed: string; refreshing: string; refresh: string
  liveWord: string; doneWord: string; postponedWord: string; todayWord: string; joiner: string
  ntTitle: string; ntHint: string; ntRangeTitle: string; ntRange: (c: number) => string; ntPickTitle: string; ntAllPicked: string; ntCleared: string; ntRangeAllAdded: (c: number) => string
  ntDesc: (p: number) => string
  footerCustom: (t: string, nt: string) => string; footerDefault: (d: string, nt: string) => string
  transparentTitle: string; transparentHint: string
  lightInverseTitle: string; darkInverseTitle: string; inverseHint: string
}
/** 打比菜单文案（四语；德比／打比按当地叫法：简中德比、香港打比、台湾德比、英文 Derby） */
const DERBY_STR: Record<Loc, { title: string; catTitle: string; pickTitle: string; all: string; catAll: (c: string) => string; allAdded: string; cleared: string }> = {
  hans: { title: "德比", catTitle: "选择分类", pickTitle: "选择德比", all: "全部德比", catAll: (c) => `全部${c}德比`, allAdded: "德比已经加完了", cleared: "德比已清空" },
  hk: { title: "打比", catTitle: "選擇分類", pickTitle: "選擇打比", all: "全部打比", catAll: (c) => `全部${c}打比`, allAdded: "打比已經加晒", cleared: "打比已清空" },
  tw: { title: "德比", catTitle: "選擇分類", pickTitle: "選擇德比", all: "全部德比", catAll: (c) => `全部${c}德比`, allAdded: "德比已經全部加入", cleared: "德比已清空" },
  en: { title: "Derby", catTitle: "Select category", pickTitle: "Select derby", all: "All derbies", catAll: (c) => `All ${c} derbies`, allAdded: "All derbies have been added", cleared: "Derbies cleared" },
}
const STR: Record<Loc, PageStrings> = {
  hans: {
    followed: "关注球队",
    hint: "点击 × 删除球队、国家队或德比，下面先选择德比、联赛、国家队或国家队前10/20/30/40/50，再选择分类／球队添加；选择全部／范围时直接添加。",
    leagueTitle: "选择联赛", teamTitle: "选择球队",
    add: "添加", restore: "恢复默认", allAdded: "这个联赛的球队已经加完了",
    alreadyHave: (d) => `已有 ${d}`, added: (d) => `已添加 ${d}`,
    restored: "已恢复默认 10 支球队", removed: (n) => `已删除 ${n}`,
    liveN: (n) => `进行中 ${n} 场`, todayN: (n) => `今日 ${n} 场`, futureN: (n) => `未来 ${n} 场`,
    noFixtures: "暂无相关赛程", loadFailed: "未能获取赛程，请点击下方刷新重试",
    updated: "更新：", refreshFailed: "刷新失败：", refreshing: "正在刷新…", refresh: "↻ 刷新",
    transparentTitle: "透明壁纸模式", transparentHint: "开启后，透明壁纸下灰字转为主要颜色，显示更清晰；正常背景请保持关闭。",
    lightInverseTitle: "浅色用白字", darkInverseTitle: "深色用黑字", inverseHint: "默认是主题色（浅色黑字、深色白字）；打开对应开关则反转。仅在透明模式下生效。",
    liveWord: "进行中", doneWord: "完场", postponedWord: "延期", todayWord: "今天", joiner: "、",
    ntTitle: "国家队", ntHint: "排名范围照常，单选额外加。", ntRangeTitle: "排名范围", ntRange: (c) => `国家队前${c}`, ntPickTitle: "选择国家队", ntAllPicked: "国家队已经加完了", ntCleared: "国家队已清空", ntRangeAllAdded: (c) => `国家队前${c}已经加完了`,
    ntDesc: (p) => `国家队 ${p} 支`,
    footerCustom: (t, nt) => nt ? `关注球队：${t}。${nt}。显示未来最近 8 场，开球时间为手机当地时间。` : `关注球队：${t}。显示未来最近 8 场，开球时间为手机当地时间。`,
    footerDefault: (d, nt) => nt ? `收录：${d}，${nt}的比赛。显示未来最近 8 场，开球时间为手机当地时间。` : `收录：${d}。显示未来最近 8 场，开球时间为手机当地时间。`,
  },
  hk: {
    followed: "關注球隊",
    hint: "點擊 × 刪除球隊、國家隊或打比，下面先選擇打比、聯賽、國家隊或國家隊前10/20/30/40/50，再選擇分類／球隊新增；選擇全部／範圍時直接新增。",
    leagueTitle: "選擇聯賽", teamTitle: "選擇球隊",
    add: "新增", restore: "恢復預設", allAdded: "這個聯賽的球隊已全部加入",
    alreadyHave: (d) => `已有 ${d}`, added: (d) => `已新增 ${d}`,
    restored: "已恢復預設 10 支球隊", removed: (n) => `已刪除 ${n}`,
    liveN: (n) => `進行中 ${n} 場`, todayN: (n) => `今日 ${n} 場`, futureN: (n) => `未來 ${n} 場`,
    noFixtures: "暫無相關賽程", loadFailed: "未能取得賽程，請點擊下方重新整理重試",
    updated: "更新：", refreshFailed: "刷新失敗：", refreshing: "正在刷新…", refresh: "↻ 刷新",
    transparentTitle: "透明壁紙模式", transparentHint: "開咗之後，透壁紙嗰陣灰字轉主色，睇得清啲；正常背景唔使開。",
    lightInverseTitle: "淺色用白字", darkInverseTitle: "深色用黑字", inverseHint: "預設係主題色（淺色黑字、深色白字）；開咗對應開關就反轉。淨係透明模式先生效。",
    liveWord: "進行中", doneWord: "完場", postponedWord: "延期", todayWord: "今天", joiner: "、",
    ntTitle: "國家隊", ntHint: "排名範圍照常，單選額外加入。", ntRangeTitle: "排名範圍", ntRange: (c) => `國家隊前${c}`, ntPickTitle: "選擇國家隊", ntAllPicked: "國家隊已全部加入", ntCleared: "國家隊已清空", ntRangeAllAdded: (c) => `國家隊前${c}已經全部加入`,
    ntDesc: (p) => `國家隊 ${p} 支`,
    footerCustom: (t, nt) => nt ? `關注球隊：${t}。${nt}。顯示未來最近 8 場，開球時間為手機當地時間。` : `關注球隊：${t}。顯示未來最近 8 場，開球時間為手機當地時間。`,
    footerDefault: (d, nt) => nt ? `收錄：${d}，${nt}的比賽。顯示未來最近 8 場，開球時間為手機當地時間。` : `收錄：${d}。顯示未來最近 8 場，開球時間為手機當地時間。`,
  },
  tw: {
    followed: "關注球隊",
    hint: "點擊 × 刪除球隊、國家隊或德比，下面先選擇德比、聯賽、國家隊或國家隊前10/20/30/40/50，再選擇分類／球隊新增；選擇全部／範圍時直接新增。",
    leagueTitle: "選擇聯賽", teamTitle: "選擇球隊",
    add: "新增", restore: "恢復預設", allAdded: "這個聯賽的球隊已全部加入",
    alreadyHave: (d) => `已有 ${d}`, added: (d) => `已新增 ${d}`,
    restored: "已恢復預設 10 支球隊", removed: (n) => `已刪除 ${n}`,
    liveN: (n) => `進行中 ${n} 場`, todayN: (n) => `今日 ${n} 場`, futureN: (n) => `未來 ${n} 場`,
    noFixtures: "暫無相關賽程", loadFailed: "未能取得賽程，請點擊下方重新整理重試",
    updated: "更新：", refreshFailed: "重新整理失敗：", refreshing: "正在重新整理…", refresh: "↻ 重新整理",
    transparentTitle: "透明桌布模式", transparentHint: "開啟後，透明桌布下灰字轉為主要顏色，顯示更清晰；正常背景請保持關閉。",
    lightInverseTitle: "淺色用白字", darkInverseTitle: "深色用黑字", inverseHint: "預設為主題色（淺色黑字、深色白字）；開啟對應開關則反轉。僅在透明模式下生效。",
    liveWord: "進行中", doneWord: "完場", postponedWord: "延期", todayWord: "今天", joiner: "、",
    ntTitle: "國家隊", ntHint: "排名範圍照常，單選額外加入。", ntRangeTitle: "排名範圍", ntRange: (c) => `國家隊前${c}`, ntPickTitle: "選擇國家隊", ntAllPicked: "國家隊已全部加入", ntCleared: "國家隊已清空", ntRangeAllAdded: (c) => `國家隊前${c}已經全部加入`,
    ntDesc: (p) => `國家隊 ${p} 支`,
    footerCustom: (t, nt) => nt ? `關注球隊：${t}。${nt}。顯示未來最近 8 場，開球時間為手機當地時間。` : `關注球隊：${t}。顯示未來最近 8 場，開球時間為手機當地時間。`,
    footerDefault: (d, nt) => nt ? `收錄：${d}，${nt}的比賽。顯示未來最近 8 場，開球時間為手機當地時間。` : `收錄：${d}。顯示未來最近 8 場，開球時間為手機當地時間。`,
  },
  en: {
    followed: "Followed teams",
    hint: "Tap × to remove a team, national team or derby. Pick a derby, league, national teams, or a top-10/20/30/40/50 range, then a category/team to add; all/range add directly.",
    leagueTitle: "Select league", teamTitle: "Select team",
    add: "Add", restore: "Restore defaults", allAdded: "All teams in this league have been added",
    alreadyHave: (d) => `${d} is already added`, added: (d) => `${d} added`,
    restored: "Restored the default 10 teams", removed: (n) => `Removed ${n}`,
    liveN: (n) => `${n} live`, todayN: (n) => `${n} today`, futureN: (n) => `${n} upcoming`,
    noFixtures: "No fixtures yet", loadFailed: "Couldn't load fixtures. Tap Refresh below to try again",
    updated: "Updated: ", refreshFailed: "Refresh failed: ", refreshing: "Refreshing…", refresh: "↻ Refresh",
    transparentTitle: "Transparent wallpaper mode", transparentHint: "When on, gray text uses the primary color on transparent wallpapers for better readability; keep off for normal backgrounds.",
    lightInverseTitle: "Light: white text", darkInverseTitle: "Dark: black text", inverseHint: "Default is the theme color (black in light, white in dark); turning a switch on inverts it. Only applies in transparent mode.",
    liveWord: "Live", doneWord: "Full-Time", postponedWord: "Postponed", todayWord: "Today", joiner: ", ",
    ntTitle: "National teams", ntHint: "Ranking range stays on; single picks are added on top.", ntRangeTitle: "Ranking range", ntRange: (c) => `Top ${c} national teams`, ntPickTitle: "Pick a national team", ntAllPicked: "All national teams have been added", ntCleared: "National teams cleared", ntRangeAllAdded: (c) => `Top ${c} national teams are already added`,
    ntDesc: (p) => `National teams (${p})`,
    footerCustom: (t, nt) => nt ? `Following: ${t}. ${nt}. Shows the next 8 upcoming matches. Kick-off times are in your phone's local time.` : `Following: ${t}. Shows the next 8 upcoming matches. Kick-off times are in your phone's local time.`,
    footerDefault: (d, nt) => nt ? `Includes: ${d}, plus ${nt} matches. Shows the next 8 upcoming matches. Kick-off times are in your phone's local time.` : `Includes: ${d}. Shows the next 8 upcoming matches. Kick-off times are in your phone's local time.`,
  },
}

/** 页面用星期／时间：中文沿用 koParts（港台星期用週），英文用 Intl 短星期＋12 小时制；小组件本身唔用呢度，唔影响 widget 显示 */
function pageWeekday(iso: string, loc: Loc): string {
  const ko = koParts(iso)
  if (loc === "en") {
    try { return new Intl.DateTimeFormat("en", { weekday: "short", timeZone: phoneTimeZone() }).format(new Date(iso)) } catch { return ko.weekday }
  }
  if (loc === "hk" || loc === "tw") return ko.weekday.replace("周", "週")
  return ko.weekday
}
function pageTime12(iso: string, loc: Loc): string {
  const ko = koParts(iso)
  if (loc !== "en") return ko.time12
  try {
    return new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit", hour12: true, timeZone: phoneTimeZone() }).format(new Date(iso))
  } catch { return ko.time12 }
}
function pageClock(ts: number, loc: Loc): string {
  if (loc !== "en") return clockZh(ts)
  try {
    return new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit", hour12: true, timeZone: phoneTimeZone() }).format(new Date(ts))
  } catch { return clockZh(ts) }
}

function CenterText({ m }: { m: Match }) {
  const loc = displayLocale()
  const S = STR[loc]
  if (LIVE.has(m.status))
    return (
      <VStack spacing={2} alignment="trailing">
        <Text font="headline" fontWeight="bold">
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" fontWeight="bold" foregroundStyle="systemRed">
          {m.ht ? halftimeLabel(loc) : (m.elapsed != null ? `${S.liveWord} ${m.elapsed}'` : S.liveWord)}
        </Text>
      </VStack>
    )
  if (DONE.has(m.status))
    return (
      <VStack spacing={2} alignment="trailing">
        <Text font="headline" fontWeight="bold">
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" foregroundStyle="secondaryLabel">
          {S.doneWord}
        </Text>
      </VStack>
    )
  if (OFF.has(m.status))
    return (
      <Text font="subheadline" foregroundStyle="secondaryLabel">
        {S.postponedWord}
      </Text>
    )
  return (
    <VStack spacing={2} alignment="trailing">
      <Text font="subheadline" foregroundStyle="secondaryLabel">
        {isToday(m.date) ? S.todayWord : pageWeekday(m.date, loc)}
      </Text>
      <Text font="subheadline">{pageTime12(m.date, loc)}</Text>
    </VStack>
  )
}

function MatchRow({ m }: { m: Match }) {
  return (
    <Link url={fotmobUrl(m)}>
      <HStack alignment="center" spacing={8}>
        <Image imageUrl={m.home.logo} resizable={true} frame={{ width: 26, height: 26 }} />
        <VStack spacing={2} alignment="leading">
          <Text font="subheadline" fontWeight="bold">
            {m.home.code ?? ""} vs {m.away.code ?? ""}
          </Text>
          <Text font="caption" foregroundStyle="tertiaryLabel">
            {m.league}
          </Text>
        </VStack>
        <Spacer />
        <CenterText m={m} />
        <Image imageUrl={m.away.logo} resizable={true} frame={{ width: 26, height: 26 }} />
      </HStack>
    </Link>
  )
}

/** 默认 10 间（标签预填用；存空即系呢个清单；显示时经 displayStoredTeam 转当前语言显示名） */
const DEFAULT_TEAMS = ["曼联", "利物浦", "阿仙奴", "车路士", "热刺", "曼城", "皇马", "巴塞", "拜仁", "PSG"]

function View() {
  const [data, setData] = useState<FootballData | null>(
    Storage.get<FootballData>(footballKey) ?? null
  )
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const savedTeams = Storage.get<string>(teamsKey)
  const [teams, setTeams] = useState<string[]>(
    savedTeams != null && savedTeams.trim() !== "" ? parseTeamsText(savedTeams).raw : DEFAULT_TEAMS
  )
  const [customActive, setCustomActive] = useState(
    savedTeams != null && savedTeams.trim() !== ""
  )
  const [leaguePick, setLeaguePick] = useState(LEAGUES[0].key)
  const [teamIdPick, setTeamIdPick] = useState<number | undefined>(undefined)
  const [teamsMsg, setTeamsMsg] = useState<string | null>(null)
  const _nt = getNTSettings()
  const [ntPicks, setNtPicks] = useState<string[]>([..._nt.picks])
  const [ntPickValue, setNtPickValue] = useState<string | undefined>(undefined)
  const [ntMsg, setNtMsg] = useState<string | null>(null)
  const _derby = getDerbySettings()
  const [derbyPicks, setDerbyPicks] = useState<string[]>([..._derby.picks])
  const [derbyCatPickValue, setDerbyCatPickValue] = useState<string | undefined>(undefined)
  const [derbyPickValue, setDerbyPickValue] = useState<string | undefined>(undefined)
  const [derbyMsg, setDerbyMsg] = useState<string | null>(null)
  // 透明壁纸模式（默认关；开时小组件藏分割线、灰字转主色）
  const [transparent, setTransparent] = useState<boolean>(Storage.get<boolean>(transparentKey) ?? false)
  const [lightInverse, setLightInverse] = useState<boolean>(Storage.get<boolean>(transparentLightInverseKey) ?? false)
  const [darkInverse, setDarkInverse] = useState<boolean>(Storage.get<boolean>(transparentDarkInverseKey) ?? false)

  const refresh = async () => {
    setLoading(true)
    setError(null)
    const r = await refreshFootball()
    if (!r.ok) setError(r.error ?? "未知错误")
    setData(Storage.get<FootballData>(footballKey) ?? null)
    Widget.reloadAll()
    setLoading(false)
  }

  /** 即刻保存清单：空即恢复默认（清 Storage），其余存原文行 */
  const persistTeams = (list: string[]) => {
    if (list.length === 0) {
      Storage.set(teamsKey, "")
      setCustomActive(false)
    } else {
      Storage.set(teamsKey, list.join("\n"))
      setCustomActive(true)
    }
  }

  /** 两级菜单当前状态：语言跟手机设定；联赛→该联赛未关注球队；选中球队跟住可选清单走 */
  const loc = displayLocale()
  const S = STR[loc]
  const league = LEAGUES.find((l) => l.key === leaguePick) ?? LEAGUES[0]
  const teamOptions = leagueTeamOptions(league.key, teams)
  const teamPick = teamIdPick === -2 ? -2 : teamOptions.find((t) => t.id === teamIdPick)?.id ?? -2

  /** 添加：先拣联赛再拣球队；存当前语言嘅显示名；即刻保存＋刷新 */
  const addTeam = async () => {
    if (teamPick === -2) {
      // 全部联赛：展开成该联赛未关注球队（同国家队范围展开一样）
      if (teamOptions.length === 0) return
      const names = teamOptions.map((t) => t[loc])
      const next = [...teams, ...names]
      setTeams(next)
      persistTeams(next)
      setTeamsMsg(S.added(`${league[loc]} (${names.length})`))
      await refresh()
      return
    }
    const t = teamOptions.find((x) => x.id === teamPick)
    if (t == null) return
    const disp = t[loc]
    if (teams.some((x) => x.toLowerCase() === disp.toLowerCase())) {
      setTeamsMsg(S.alreadyHave(disp))
      return
    }
    const next = [...teams, disp]
    setTeams(next)
    persistTeams(next)
    setTeamsMsg(S.added(disp))
    await refresh()
  }

  /** 删除标签：即刻保存＋刷新；删到空即恢复默认（唔留一个空清单状态） */
  const removeTeam = async (name: string) => {
    const next = teams.filter((x) => x !== name)
    if (next.length === 0) {
      Storage.set(teamsKey, "")
      setTeams(DEFAULT_TEAMS)
      setCustomActive(false)
      setTeamsMsg(S.restored)
    } else {
      setTeams(next)
      persistTeams(next)
      setTeamsMsg(S.removed(displayStoredTeam(name, loc)))
    }
    await refresh()
  }

  const resetTeams = async () => {
    Storage.set(teamsKey, "")
    setTeams(DEFAULT_TEAMS)
    setCustomActive(false)
    setTeamsMsg(S.restored)
    resetNTSettings()
    setNtPicks([])
    setNtMsg(S.ntCleared)
    resetDerbySettings()
    setDerbyPicks([])
    setDerbyMsg(DERBY_STR[loc].cleared)
    await refresh()
  }

  const ntDisp = (key: string) => {
    const nt = NT_ALL.find((x) => x.key === key)
    return nt == null ? key : displayNTName(nt, loc)
  }
  // 国家队第二栏：列晒全部 221 间（按 FIFA 排名顺序，1–211 标名次；冇排名嘅 10 间排最尾、唔标名次，唔过滤已加）
  const NT_RANGES = [10, 20, 30, 40, 50]
  const ntOptions: { value: string; label: string }[] = NT_ALL.map((nt, i) => ({
    value: `nt:${nt.key}`,
    label: nt.rank != null ? `${nt.rank} ${displayNTName(nt, loc)}` : displayNTName(nt, loc),
  }))
  const ntPickerOptions: { value: string; label: string }[] = [
    { value: "nt:all", label: loc === "en" ? "All national teams" : loc === "hans" ? "全部国家队" : "全部國家隊" },
    ...ntOptions,
  ]
  const ntPick = ntPickerOptions.find((o) => o.value === ntPickValue)?.value ?? ntPickerOptions[0]?.value ?? ""
  const addNT = async () => {
    if (ntPick === "nt:all") {
      const added = NT_ALL.map((nt) => nt.key).filter((k) => !ntPicks.includes(k))
      if (added.length === 0) {
        setNtMsg(S.ntAllPicked)
        return
      }
      const next = [...ntPicks, ...added]
      setNtPicks(next)
      saveNTSettings({ picks: new Set(next) })
      setNtMsg(S.added(`${S.ntTitle} (${added.length})`))
      await refresh()
      return
    }
    if (ntPick === "") return
    const key = ntPick.slice(3)
    if (ntPicks.includes(key)) {
      setNtMsg(S.alreadyHave(ntDisp(key)))
      return
    }
    const next = [...ntPicks, key]
    setNtPicks(next)
    saveNTSettings({ picks: new Set(next) })
    setNtMsg(S.added(ntDisp(key)))
    await refresh()
  }
  // 选范围：无第二栏，直接添加并展开成逐间标签
  const addRange = async () => {
    const c = parseInt(leaguePick.slice(6), 10)
    const added = NT_RANKING.slice(0, c).map((nt) => nt.key).filter((k) => !ntPicks.includes(k))
    if (added.length === 0) {
      setNtMsg(S.ntRangeAllAdded(c))
      return
    }
    const next = [...ntPicks, ...added]
    setNtPicks(next)
    saveNTSettings({ picks: new Set(next) })
    setNtMsg(S.added(`${S.ntRange(c)} (${added.length})`))
    await refresh()
  }
  const removeNT = async (key: string) => {
    const next = ntPicks.filter((x) => x !== key)
    setNtPicks(next)
    saveNTSettings({ picks: new Set(next) })
    setNtMsg(S.removed(ntDisp(key)))
    await refresh()
  }
  const addDerby = async () => {
    // 第二栏全部 → 全部打比；第二栏分类＋第三栏全部 → 成组；第三栏具体 → 单场（批量一律展开成逐个标签，同国家队范围一样）
    if (derbyCatPick === "derby:all") {
      const added = DERBIES.map((d) => d.key).filter((k) => !derbyPicks.includes(k))
      if (added.length === 0) {
        setDerbyMsg(DERBY_STR[loc].allAdded)
        return
      }
      const next = [...derbyPicks, ...added]
      setDerbyPicks(next)
      saveDerbySettings({ picks: new Set(next) })
      setDerbyMsg(S.added(`${DERBY_STR[loc].all} (${added.length})`))
      await refresh()
      return
    }
    const cat = derbyCatPick.slice("derby:cat:".length)
    if (derbyPick.startsWith("derby:catall:")) {
      const added = derbiesByCat(cat).map((d) => d.key).filter((k) => !derbyPicks.includes(k))
      if (added.length === 0) {
        setDerbyMsg(DERBY_STR[loc].allAdded)
        return
      }
      const next = [...derbyPicks, ...added]
      setDerbyPicks(next)
      saveDerbySettings({ picks: new Set(next) })
      setDerbyMsg(S.added(`${DERBY_STR[loc].catAll(derbyCatName(cat, loc))} (${added.length})`))
      await refresh()
      return
    }
    const key = derbyPick.slice("derby:".length)
    if (derbyPicks.includes(key)) {
      setDerbyMsg(S.alreadyHave(derbyLabel(key, loc)))
      return
    }
    const next = [...derbyPicks, key]
    setDerbyPicks(next)
    saveDerbySettings({ picks: new Set(next) })
    setDerbyMsg(S.added(derbyLabel(key, loc)))
    await refresh()
  }
  const removeDerby = async (key: string) => {
    const next = derbyPicks.filter((x) => x !== key)
    setDerbyPicks(next)
    saveDerbySettings({ picks: new Set(next) })
    setDerbyMsg(S.removed(derbyLabel(key, loc)))
    await refresh()
  }
  const isNTMenu = leaguePick === "nt"
  const isRangeMenu = leaguePick.startsWith("range:")
  const isDerbyMenu = leaguePick === "derby"
  // 打比第二栏：全部打比（默认）＋ 10 个分类；第三栏：全部该分类（默认）＋ 具体打比
  const derbyCatOptions: { value: string; label: string }[] = [
    { value: "derby:all", label: DERBY_STR[loc].all },
    ...DERBY_CATS.map((c) => ({ value: `derby:cat:${c.key}`, label: derbyCatName(c.key, loc) })),
  ]
  const derbyCatPick = derbyCatOptions.find((o) => o.value === derbyCatPickValue)?.value ?? derbyCatOptions[0]?.value ?? "derby:all"
  const derbyCatKey = derbyCatPick.startsWith("derby:cat:") ? derbyCatPick.slice("derby:cat:".length) : null
  const derbyOptions: { value: string; label: string }[] = derbyCatKey == null ? [] : [
    { value: `derby:catall:${derbyCatKey}`, label: DERBY_STR[loc].catAll(derbyCatName(derbyCatKey, loc)) },
    ...derbiesByCat(derbyCatKey).map((d) => ({ value: `derby:${d.key}`, label: derbyLabel(d.key, loc) })),
  ]
  const derbyPick = derbyOptions.find((o) => o.value === derbyPickValue)?.value ?? derbyOptions[0]?.value ?? ""
  const menuHasOptions = isRangeMenu ? true : isDerbyMenu ? true : isNTMenu ? ntOptions.length > 0 : teamOptions.length > 0

  useEffect(() => {
    refresh()
  }, [])

  return (
    <NavigationStack>
      <ScrollView>
      <VStack padding={{ top: 16, horizontal: 16, bottom: 16 }} spacing={12}>
        <VStack spacing={8} alignment="leading">
          <Text font="headline">{S.followed}</Text>
          <Text font="caption" foregroundStyle="secondaryLabel">
            {S.hint}
          </Text>
          <FlowLayout spacing={8}>
            {teams.map((t) => (
              <HStack key={t} spacing={4} padding={8} background="systemGray5">
                <Text font="subheadline" fontWeight="semibold">
                  {displayStoredTeam(t, loc)}
                </Text>
                <Button title="×" action={() => removeTeam(t)} />
              </HStack>
            ))}
            {ntPicks.map((key) => (
              <HStack key={`nt-${key}`} spacing={4} padding={8} background="systemGray5">
                <Text font="subheadline" fontWeight="semibold">
                  {ntDisp(key)}
                </Text>
                <Button title="×" action={() => removeNT(key)} />
              </HStack>
            ))}
            {derbyPicks.map((key) => (
              <HStack key={`derby-${key}`} spacing={4} padding={8} background="systemGray5">
                <Text font="subheadline" fontWeight="semibold">
                  {derbyLabel(key, loc)}
                </Text>
                <Button title="×" action={() => removeDerby(key)} />
              </HStack>
            ))}
          </FlowLayout>
          {menuHasOptions ? (
            <HStack spacing={12} padding={{ vertical: 20 }}>
              <Picker
                title={S.leagueTitle}
                value={leaguePick}
                onChanged={setLeaguePick}
                pickerStyle="menu"
              >
                <Text key="derby" tag="derby" lineLimit={1}>
                  {DERBY_STR[loc].title}
                </Text>
                {LEAGUES.map((l) => (
                  <Text key={l.key} tag={l.key} lineLimit={1}>
                    {l[loc]}
                  </Text>
                ))}
                <Text key="nt" tag="nt" lineLimit={1}>
                  {S.ntTitle}
                </Text>
                {NT_RANGES.map((c) => (
                  <Text key={`range:${c}`} tag={`range:${c}`} lineLimit={1}>
                    {S.ntRange(c)}
                  </Text>
                ))}
              </Picker>
              {isRangeMenu ? null : isDerbyMenu ? (
                <Picker
                  title={DERBY_STR[loc].catTitle}
                  value={derbyCatPick}
                  onChanged={setDerbyCatPickValue}
                  pickerStyle="menu"
                >
                  {derbyCatOptions.map((o) => (
                    <Text key={o.value} tag={o.value} lineLimit={1}>
                      {o.label}
                    </Text>
                  ))}
                </Picker>
              ) : isNTMenu ? (
                <Picker
                  title={S.ntPickTitle}
                  value={ntPick}
                  onChanged={setNtPickValue}
                  pickerStyle="menu"
                >
                  {ntPickerOptions.map((o) => (
                    <Text key={o.value} tag={o.value} lineLimit={1}>
                      {o.label}
                    </Text>
                  ))}
                </Picker>
              ) : (
                <Picker
                  title={S.teamTitle}
                  value={teamPick}
                  onChanged={setTeamIdPick}
                  pickerStyle="menu"
                >
                  <Text key="league-all" tag={-2} lineLimit={1}>
                    {loc === "en" ? `All ${league[loc]} teams` : `全部${league[loc]}`}
                  </Text>
                  {teamOptions.map((t) => (
                    <Text key={t.id} tag={t.id} lineLimit={1}>
                      {t[loc]}
                    </Text>
                  ))}
                </Picker>
              )}
              {isDerbyMenu && derbyCatKey != null ? (
                <Picker
                  title={DERBY_STR[loc].pickTitle}
                  value={derbyPick}
                  onChanged={setDerbyPickValue}
                  pickerStyle="menu"
                >
                  {derbyOptions.map((o) => (
                    <Text key={o.value} tag={o.value} lineLimit={1}>
                      {o.label}
                    </Text>
                  ))}
                </Picker>
              ) : null}
              <Button title={S.add} action={isRangeMenu ? addRange : isDerbyMenu ? addDerby : isNTMenu ? addNT : addTeam} />
            </HStack>
          ) : (
            <HStack spacing={12} padding={{ vertical: 20 }}>
              <Picker
                title={S.leagueTitle}
                value={leaguePick}
                onChanged={setLeaguePick}
                pickerStyle="menu"
              >
                <Text key="derby" tag="derby" lineLimit={1}>
                  {DERBY_STR[loc].title}
                </Text>
                {LEAGUES.map((l) => (
                  <Text key={l.key} tag={l.key} lineLimit={1}>
                    {l[loc]}
                  </Text>
                ))}
                <Text key="nt" tag="nt" lineLimit={1}>
                  {S.ntTitle}
                </Text>
                {NT_RANGES.map((c) => (
                  <Text key={`range:${c}`} tag={`range:${c}`} lineLimit={1}>
                    {S.ntRange(c)}
                  </Text>
                ))}
              </Picker>
              <Text font="caption" foregroundStyle="secondaryLabel">
                {isNTMenu ? S.ntAllPicked : S.allAdded}
              </Text>
            </HStack>
          )}
          <Button title={S.restore} action={resetTeams} />
          {teamsMsg != null && (
            <Text font="caption" foregroundStyle="secondaryLabel">
              {teamsMsg}
            </Text>
          )}
          {ntMsg != null && (
            <Text font="caption" foregroundStyle="secondaryLabel">
              {ntMsg}
            </Text>
          )}
          {derbyMsg != null && (
            <Text font="caption" foregroundStyle="secondaryLabel">
              {derbyMsg}
            </Text>
          )}
        </VStack>
        <VStack spacing={8} alignment="leading">
          <Toggle
            title={S.transparentTitle}
            value={transparent}
            onChanged={(v) => {
              setTransparent(v)
              Storage.set(transparentKey, v)
              Widget.reloadAll()
            }}
          />
          <Text font="caption" foregroundStyle="secondaryLabel">
            {S.transparentHint}
          </Text>
          {transparent && (
            <VStack spacing={8} alignment="leading">
              <Toggle
                title={S.lightInverseTitle}
                value={lightInverse}
                onChanged={(v) => {
                  setLightInverse(v)
                  Storage.set(transparentLightInverseKey, v)
                  Widget.reloadAll()
                }}
              />
              <Toggle
                title={S.darkInverseTitle}
                value={darkInverse}
                onChanged={(v) => {
                  setDarkInverse(v)
                  Storage.set(transparentDarkInverseKey, v)
                  Widget.reloadAll()
                }}
              />
              <Text font="caption" foregroundStyle="secondaryLabel">
                {S.inverseHint}
              </Text>
            </VStack>
          )}
        </VStack>
        <Divider />
        {data != null && data.matches.length > 0 && (() => {
          const live = data.matches.filter((m) => LIVE.has(m.status)).length
          const todayN = data.matches.filter((m) => isToday(m.date)).length
          const label =
            live > 0 ? S.liveN(live)
            : todayN > 0 ? S.todayN(todayN)
            : S.futureN(data.matches.length)
          return <Text font="headline">{label}</Text>
        })()}
        {data != null && data.matches.length > 0 ? (
          <VStack spacing={12}>
            {data.matches.map((m) => (
              <MatchRow key={m.id} m={m} />
            ))}
          </VStack>
        ) : (
          <Text foregroundStyle="secondaryLabel">
            {error != null ? S.loadFailed : S.noFixtures}
          </Text>
        )}
        {data != null && data.fetchedAt > 0 && (
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {S.updated}{pageClock(data.fetchedAt, loc)}
          </Text>
        )}
        {error != null && (
          <Text font="footnote" foregroundStyle="systemRed">
            {S.refreshFailed}{error}
          </Text>
        )}
        <Spacer />
        <Button title={loading ? S.refreshing : S.refresh} action={refresh} />
        <Divider />
        <Text font="caption" foregroundStyle="tertiaryLabel">
          {customActive
            ? S.footerCustom(teams.map((t) => displayStoredTeam(t, loc)).join(S.joiner), ntPicks.length > 0 ? S.ntDesc(ntPicks.length) : "")
            : S.footerDefault(DEFAULT_TEAMS.map((t) => displayStoredTeam(t, loc)).join(S.joiner), ntPicks.length > 0 ? S.ntDesc(ntPicks.length) : "")}
        </Text>
      </VStack>
      </ScrollView>
    </NavigationStack>
  )
}

async function run() {
  await Navigation.present({
    element: <View />,
  })
  Script.exit()
}

run()
