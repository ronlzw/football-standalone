import {
  Button,
  Divider,
  FlowLayout,
  HStack,
  Image,
  Link,
  Navigation,
  NavigationStack,
  Picker,
  Script,
  Spacer,
  Text,
  VStack,
  Widget,
  useEffect,
  useState,
} from "scripting"
import {
  FootballData,
  DONE,
  LIVE,
  Match,
  OFF,
  clockZh,
  footballKey,
  fotmobUrl,
  isToday,
  koParts,
  phoneTimeZone,
  teamsKey,
} from "./const"
import { displayLocale, displayStoredTeam, halftimeLabel, LEAGUES, leagueTeamOptions, parseTeamsText, refreshFootball } from "./football"

/** 页面文案：四语书面语（简体／香港繁体／台湾繁体／英文），跟手机系统语言；球队名一律经 displayStoredTeam 转当前语言显示名；标题维持 Matchday（用户 2026-10-28 明言：净改脚本名，唔改标题） */
type Loc = "hans" | "hk" | "tw" | "en"
type PageStrings = {
  title: string; followed: string; hint: string; leagueTitle: string; teamTitle: string
  add: string; restore: string; allAdded: string
  alreadyHave: (d: string) => string; added: (d: string) => string; restored: string; removed: (n: string) => string
  liveN: (n: number) => string; todayN: (n: number) => string; futureN: (n: number) => string
  noFixtures: string; loadFailed: string; updated: string; refreshFailed: string; refreshing: string; refresh: string
  liveWord: string; doneWord: string; postponedWord: string; todayWord: string; joiner: string
  footerCustom: (t: string) => string; footerDefault: (d: string) => string
}
const STR: Record<Loc, PageStrings> = {
  hans: {
    title: "Matchday", followed: "关注球队",
    hint: "点击 × 删除球队，下面先选择联赛再选择球队添加。",
    leagueTitle: "选择联赛", teamTitle: "选择球队",
    add: "添加", restore: "恢复默认", allAdded: "这个联赛的球队已经加完了",
    alreadyHave: (d) => `已有 ${d}`, added: (d) => `已添加 ${d}`,
    restored: "已恢复默认 10 支球队", removed: (n) => `已删除 ${n}`,
    liveN: (n) => `进行中 ${n} 场`, todayN: (n) => `今日 ${n} 场`, futureN: (n) => `未来 ${n} 场`,
    noFixtures: "暂无相关赛程", loadFailed: "未能获取赛程，请点击下方刷新重试",
    updated: "更新：", refreshFailed: "刷新失败：", refreshing: "正在刷新…", refresh: "↻ 刷新",
    liveWord: "进行中", doneWord: "完场", postponedWord: "延期", todayWord: "今天", joiner: "、",
    footerCustom: (t) => `关注球队：${t}。国家队（FIFA 前 40）保持不变。显示未来最近 8 场，开球时间为手机当地时间。`,
    footerDefault: (d) => `收录：${d}，以及至少一方 FIFA 前 40 的国家队比赛。显示未来最近 8 场，开球时间为手机当地时间。`,
  },
  hk: {
    title: "Matchday", followed: "關注球隊",
    hint: "點擊 × 刪除球隊，下面先選擇聯賽再選擇球隊新增。",
    leagueTitle: "選擇聯賽", teamTitle: "選擇球隊",
    add: "新增", restore: "恢復預設", allAdded: "這個聯賽的球隊已全部加入",
    alreadyHave: (d) => `已有 ${d}`, added: (d) => `已新增 ${d}`,
    restored: "已恢復預設 10 支球隊", removed: (n) => `已刪除 ${n}`,
    liveN: (n) => `進行中 ${n} 場`, todayN: (n) => `今日 ${n} 場`, futureN: (n) => `未來 ${n} 場`,
    noFixtures: "暫無相關賽程", loadFailed: "未能取得賽程，請點擊下方重新整理重試",
    updated: "更新：", refreshFailed: "刷新失敗：", refreshing: "正在刷新…", refresh: "↻ 刷新",
    liveWord: "進行中", doneWord: "完場", postponedWord: "延期", todayWord: "今天", joiner: "、",
    footerCustom: (t) => `關注球隊：${t}。國家隊（FIFA 前 40）維持不變。顯示未來最近 8 場，開球時間為手機當地時間。`,
    footerDefault: (d) => `收錄：${d}，以及至少一方 FIFA 前 40 的國家隊比賽。顯示未來最近 8 場，開球時間為手機當地時間。`,
  },
  tw: {
    title: "Matchday", followed: "關注球隊",
    hint: "點擊 × 刪除球隊，下面先選擇聯賽再選擇球隊新增。",
    leagueTitle: "選擇聯賽", teamTitle: "選擇球隊",
    add: "新增", restore: "恢復預設", allAdded: "這個聯賽的球隊已全部加入",
    alreadyHave: (d) => `已有 ${d}`, added: (d) => `已新增 ${d}`,
    restored: "已恢復預設 10 支球隊", removed: (n) => `已刪除 ${n}`,
    liveN: (n) => `進行中 ${n} 場`, todayN: (n) => `今日 ${n} 場`, futureN: (n) => `未來 ${n} 場`,
    noFixtures: "暫無相關賽程", loadFailed: "未能取得賽程，請點擊下方重新整理重試",
    updated: "更新：", refreshFailed: "重新整理失敗：", refreshing: "正在重新整理…", refresh: "↻ 重新整理",
    liveWord: "進行中", doneWord: "完場", postponedWord: "延期", todayWord: "今天", joiner: "、",
    footerCustom: (t) => `關注球隊：${t}。國家隊（FIFA 前 40）維持不變。顯示未來最近 8 場，開球時間為手機當地時間。`,
    footerDefault: (d) => `收錄：${d}，以及至少一方 FIFA 前 40 的國家隊比賽。顯示未來最近 8 場，開球時間為手機當地時間。`,
  },
  en: {
    title: "Matchday", followed: "Followed teams",
    hint: "Tap × to remove a team. Pick a league, then a team below to add.",
    leagueTitle: "Select league", teamTitle: "Select team",
    add: "Add", restore: "Restore defaults", allAdded: "All teams in this league have been added",
    alreadyHave: (d) => `${d} is already added`, added: (d) => `${d} added`,
    restored: "Restored the default 10 teams", removed: (n) => `Removed ${n}`,
    liveN: (n) => `${n} live`, todayN: (n) => `${n} today`, futureN: (n) => `${n} upcoming`,
    noFixtures: "No fixtures yet", loadFailed: "Couldn't load fixtures. Tap Refresh below to try again",
    updated: "Updated: ", refreshFailed: "Refresh failed: ", refreshing: "Refreshing…", refresh: "↻ Refresh",
    liveWord: "Live", doneWord: "Full-Time", postponedWord: "Postponed", todayWord: "Today", joiner: ", ",
    footerCustom: (t) => `Following: ${t}. National teams (FIFA top 40) stay included. Shows the next 8 upcoming matches. Kick-off times are in your phone's local time.`,
    footerDefault: (d) => `Includes: ${d}, plus national-team matches where at least one side is FIFA top 40. Shows the next 8 upcoming matches. Kick-off times are in your phone's local time.`,
  },
}

/** 页面用星期／时间：中文沿用 koParts（港台星期用週），英文用 Intl 短星期＋12 小时制；小组件本身唔用呢度，唔影响 widget 显示 */
function pageWeekday(iso: string, loc: Loc): string {
  const ko = koParts(iso)
  if (loc === "en") {
    try { return new Intl.DateTimeFormat("en", { weekday: "short", timeZone: phoneTimeZone() }).format(new Date(iso)) } catch { return ko.weekday }
  }
  if (loc === "hk" || loc === "tw") return ko.weekday.replace("周", "週")
  return ko.weekday
}
function pageTime12(iso: string, loc: Loc): string {
  const ko = koParts(iso)
  if (loc !== "en") return ko.time12
  try {
    return new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit", hour12: true, timeZone: phoneTimeZone() }).format(new Date(iso))
  } catch { return ko.time12 }
}
function pageClock(ts: number, loc: Loc): string {
  if (loc !== "en") return clockZh(ts)
  try {
    return new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit", hour12: true, timeZone: phoneTimeZone() }).format(new Date(ts))
  } catch { return clockZh(ts) }
}

function CenterText({ m }: { m: Match }) {
  const loc = displayLocale()
  const S = STR[loc]
  if (LIVE.has(m.status))
    return (
      <VStack spacing={2} alignment="trailing">
        <Text font="headline" fontWeight="bold">
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" fontWeight="bold" foregroundStyle="systemRed">
          {m.ht ? halftimeLabel(loc) : (m.elapsed != null ? `${S.liveWord} ${m.elapsed}'` : S.liveWord)}
        </Text>
      </VStack>
    )
  if (DONE.has(m.status))
    return (
      <VStack spacing={2} alignment="trailing">
        <Text font="headline" fontWeight="bold">
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" foregroundStyle="secondaryLabel">
          {S.doneWord}
        </Text>
      </VStack>
    )
  if (OFF.has(m.status))
    return (
      <Text font="subheadline" foregroundStyle="secondaryLabel">
        {S.postponedWord}
      </Text>
    )
  return (
    <VStack spacing={2} alignment="trailing">
      <Text font="subheadline" foregroundStyle="secondaryLabel">
        {isToday(m.date) ? S.todayWord : pageWeekday(m.date, loc)}
      </Text>
      <Text font="subheadline">{pageTime12(m.date, loc)}</Text>
    </VStack>
  )
}

function MatchRow({ m }: { m: Match }) {
  return (
    <Link url={fotmobUrl(m)}>
      <HStack alignment="center" spacing={8}>
        <Image imageUrl={m.home.logo} resizable={true} frame={{ width: 26, height: 26 }} />
        <VStack spacing={2} alignment="leading">
          <Text font="subheadline" fontWeight="bold">
            {m.home.code ?? ""} vs {m.away.code ?? ""}
          </Text>
          <Text font="caption" foregroundStyle="tertiaryLabel">
            {m.league}
          </Text>
        </VStack>
        <Spacer />
        <CenterText m={m} />
        <Image imageUrl={m.away.logo} resizable={true} frame={{ width: 26, height: 26 }} />
      </HStack>
    </Link>
  )
}

/** 默认 10 间（标签预填用；存空即系呢个清单；显示时经 displayStoredTeam 转当前语言显示名） */
const DEFAULT_TEAMS = ["曼联", "利物浦", "阿仙奴", "车路士", "热刺", "曼城", "皇马", "巴塞", "拜仁", "PSG"]

function View() {
  const [data, setData] = useState<FootballData | null>(
    Storage.get<FootballData>(footballKey) ?? null
  )
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const savedTeams = Storage.get<string>(teamsKey)
  const [teams, setTeams] = useState<string[]>(
    savedTeams != null && savedTeams.trim() !== "" ? parseTeamsText(savedTeams).raw : DEFAULT_TEAMS
  )
  const [customActive, setCustomActive] = useState(
    savedTeams != null && savedTeams.trim() !== ""
  )
  const [leaguePick, setLeaguePick] = useState(LEAGUES[0].key)
  const [teamIdPick, setTeamIdPick] = useState<number | undefined>(undefined)
  const [teamsMsg, setTeamsMsg] = useState<string | null>(null)

  const refresh = async () => {
    setLoading(true)
    setError(null)
    const r = await refreshFootball()
    if (!r.ok) setError(r.error ?? "未知错误")
    setData(Storage.get<FootballData>(footballKey) ?? null)
    Widget.reloadAll()
    setLoading(false)
  }

  /** 即刻保存清单：空即恢复默认（清 Storage），其余存原文行 */
  const persistTeams = (list: string[]) => {
    if (list.length === 0) {
      Storage.set(teamsKey, "")
      setCustomActive(false)
    } else {
      Storage.set(teamsKey, list.join("\n"))
      setCustomActive(true)
    }
  }

  /** 两级菜单当前状态：语言跟手机设定；联赛→该联赛未关注球队；选中球队跟住可选清单走 */
  const loc = displayLocale()
  const S = STR[loc]
  const league = LEAGUES.find((l) => l.key === leaguePick) ?? LEAGUES[0]
  const teamOptions = leagueTeamOptions(league.key, teams)
  const teamPick = teamOptions.find((t) => t.id === teamIdPick)?.id ?? teamOptions[0]?.id ?? -1

  /** 添加：先拣联赛再拣球队；存当前语言嘅显示名；即刻保存＋刷新 */
  const addTeam = async () => {
    const t = teamOptions.find((x) => x.id === teamPick)
    if (t == null) return
    const disp = t[loc]
    if (teams.some((x) => x.toLowerCase() === disp.toLowerCase())) {
      setTeamsMsg(S.alreadyHave(disp))
      return
    }
    const next = [...teams, disp]
    setTeams(next)
    persistTeams(next)
    setTeamsMsg(S.added(disp))
    await refresh()
  }

  /** 删除标签：即刻保存＋刷新；删到空即恢复默认（唔留一个空清单状态） */
  const removeTeam = async (name: string) => {
    const next = teams.filter((x) => x !== name)
    if (next.length === 0) {
      Storage.set(teamsKey, "")
      setTeams(DEFAULT_TEAMS)
      setCustomActive(false)
      setTeamsMsg(S.restored)
    } else {
      setTeams(next)
      persistTeams(next)
      setTeamsMsg(S.removed(displayStoredTeam(name, loc)))
    }
    await refresh()
  }

  const resetTeams = async () => {
    Storage.set(teamsKey, "")
    setTeams(DEFAULT_TEAMS)
    setCustomActive(false)
    setTeamsMsg(S.restored)
    await refresh()
  }

  useEffect(() => {
    refresh()
  }, [])

  return (
    <NavigationStack>
      <VStack padding={{ top: 80, horizontal: 16, bottom: 16 }} spacing={12}>
        <Text font="largeTitle" fontWeight="bold">
          {S.title}
        </Text>
        <VStack spacing={8} alignment="leading">
          <Text font="headline">{S.followed}</Text>
          <Text font="caption" foregroundStyle="secondaryLabel">
            {S.hint}
          </Text>
          <FlowLayout spacing={8}>
            {teams.map((t) => (
              <HStack key={t} spacing={4} padding={8} background="systemGray5">
                <Text font="subheadline" fontWeight="semibold">
                  {displayStoredTeam(t, loc)}
                </Text>
                <Button title="×" action={() => removeTeam(t)} />
              </HStack>
            ))}
          </FlowLayout>
          <Picker
            title={S.leagueTitle}
            value={leaguePick}
            onChanged={setLeaguePick}
            pickerStyle="menu"
          >
            {LEAGUES.map((l) => (
              <Text key={l.key} tag={l.key}>
                {l[loc]}
              </Text>
            ))}
          </Picker>
          {teamOptions.length > 0 ? (
            <HStack spacing={8}>
              <Picker
                title={S.teamTitle}
                value={teamPick}
                onChanged={setTeamIdPick}
                pickerStyle="menu"
              >
                {teamOptions.map((t) => (
                  <Text key={t.id} tag={t.id}>
                    {t[loc]}
                  </Text>
                ))}
              </Picker>
              <Button title={S.add} action={addTeam} />
            </HStack>
          ) : (
            <Text font="caption" foregroundStyle="secondaryLabel">
              {S.allAdded}
            </Text>
          )}
          <Button title={S.restore} action={resetTeams} />
          {teamsMsg != null && (
            <Text font="caption" foregroundStyle="secondaryLabel">
              {teamsMsg}
            </Text>
          )}
        </VStack>
        <Divider />
        {data != null && data.matches.length > 0 && (() => {
          const live = data.matches.filter((m) => LIVE.has(m.status)).length
          const todayN = data.matches.filter((m) => isToday(m.date)).length
          const label =
            live > 0 ? S.liveN(live)
            : todayN > 0 ? S.todayN(todayN)
            : S.futureN(data.matches.length)
          return <Text font="headline">{label}</Text>
        })()}
        {data != null && data.matches.length > 0 ? (
          <VStack spacing={12}>
            {data.matches.map((m) => (
              <MatchRow key={m.id} m={m} />
            ))}
          </VStack>
        ) : (
          <Text foregroundStyle="secondaryLabel">
            {error != null ? S.loadFailed : S.noFixtures}
          </Text>
        )}
        {data != null && data.fetchedAt > 0 && (
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {S.updated}{pageClock(data.fetchedAt, loc)}
          </Text>
        )}
        {error != null && (
          <Text font="footnote" foregroundStyle="systemRed">
            {S.refreshFailed}{error}
          </Text>
        )}
        <Spacer />
        <Button title={loading ? S.refreshing : S.refresh} action={refresh} />
        <Divider />
        <Text font="caption" foregroundStyle="tertiaryLabel">
          {customActive
            ? S.footerCustom(teams.map((t) => displayStoredTeam(t, loc)).join(S.joiner))
            : S.footerDefault(DEFAULT_TEAMS.map((t) => displayStoredTeam(t, loc)).join(S.joiner))}
        </Text>
      </VStack>
    </NavigationStack>
  )
}

async function run() {
  await Navigation.present({
    element: <View />,
  })
  Script.exit()
}

run()
