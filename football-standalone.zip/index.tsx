import {
  Button,
  Divider,
  FlowLayout,
  HStack,
  Image,
  Link,
  Navigation,
  NavigationStack,
  Picker,
  Script,
  Spacer,
  Text,
  VStack,
  Widget,
  useEffect,
  useState,
} from "scripting"
import {
  FootballData,
  DONE,
  LIVE,
  Match,
  OFF,
  clockZh,
  footballKey,
  fotmobUrl,
  isToday,
  koParts,
  teamsKey,
} from "./const"
import { displayLocale, LEAGUES, leagueTeamOptions, parseTeamsText, refreshFootball } from "./football"

function CenterText({ m }: { m: Match }) {
  const ko = koParts(m.date)
  if (LIVE.has(m.status))
    return (
      <VStack spacing={2} alignment="trailing">
        <Text font="headline" fontWeight="bold">
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" fontWeight="bold" foregroundStyle="systemRed">
          进行中{m.elapsed != null ? ` ${m.elapsed}'` : ""}
        </Text>
      </VStack>
    )
  if (DONE.has(m.status))
    return (
      <VStack spacing={2} alignment="trailing">
        <Text font="headline" fontWeight="bold">
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" foregroundStyle="secondaryLabel">
          完场
        </Text>
      </VStack>
    )
  if (OFF.has(m.status))
    return (
      <Text font="subheadline" foregroundStyle="secondaryLabel">
        延期
      </Text>
    )
  return (
    <VStack spacing={2} alignment="trailing">
      <Text font="subheadline" foregroundStyle="secondaryLabel">
        {isToday(m.date) ? "今天" : ko.weekday}
      </Text>
      <Text font="subheadline">{ko.time12}</Text>
    </VStack>
  )
}

function MatchRow({ m }: { m: Match }) {
  return (
    <Link url={fotmobUrl(m)}>
      <HStack alignment="center" spacing={8}>
        <Image imageUrl={m.home.logo} resizable={true} frame={{ width: 26, height: 26 }} />
        <VStack spacing={2} alignment="leading">
          <Text font="subheadline" fontWeight="bold">
            {m.home.code ?? ""} vs {m.away.code ?? ""}
          </Text>
          <Text font="caption" foregroundStyle="tertiaryLabel">
            {m.league}
          </Text>
        </VStack>
        <Spacer />
        <CenterText m={m} />
        <Image imageUrl={m.away.logo} resizable={true} frame={{ width: 26, height: 26 }} />
      </HStack>
    </Link>
  )
}

/** 默认 10 间（标签预填用；存空即系呢个清单） */
const DEFAULT_TEAMS = ["曼联", "利物浦", "阿仙奴", "车路士", "热刺", "曼城", "皇马", "巴塞", "拜仁", "PSG"]

function View() {
  const [data, setData] = useState<FootballData | null>(
    Storage.get<FootballData>(footballKey) ?? null
  )
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const savedTeams = Storage.get<string>(teamsKey)
  const [teams, setTeams] = useState<string[]>(
    savedTeams != null && savedTeams.trim() !== "" ? parseTeamsText(savedTeams).raw : DEFAULT_TEAMS
  )
  const [customActive, setCustomActive] = useState(
    savedTeams != null && savedTeams.trim() !== ""
  )
  const [leaguePick, setLeaguePick] = useState(LEAGUES[0].key)
  const [teamIdPick, setTeamIdPick] = useState<number | undefined>(undefined)
  const [teamsMsg, setTeamsMsg] = useState<string | null>(null)

  const refresh = async () => {
    setLoading(true)
    setError(null)
    const r = await refreshFootball()
    if (!r.ok) setError(r.error ?? "未知错误")
    setData(Storage.get<FootballData>(footballKey) ?? null)
    Widget.reloadAll()
    setLoading(false)
  }

  /** 即刻保存清单：空即恢复默认（清 Storage），其余存原文行 */
  const persistTeams = (list: string[]) => {
    if (list.length === 0) {
      Storage.set(teamsKey, "")
      setCustomActive(false)
    } else {
      Storage.set(teamsKey, list.join("\n"))
      setCustomActive(true)
    }
  }

  /** 两级菜单当前状态：语言跟手机设定；联赛→该联赛未关注球队；选中球队跟住可选清单走 */
  const loc = displayLocale()
  const league = LEAGUES.find((l) => l.key === leaguePick) ?? LEAGUES[0]
  const teamOptions = leagueTeamOptions(league.key, teams)
  const teamPick = teamOptions.find((t) => t.id === teamIdPick)?.id ?? teamOptions[0]?.id ?? -1

  /** 添加：先拣联赛再拣球队；存当前语言嘅显示名；即刻保存＋刷新 */
  const addTeam = async () => {
    const t = teamOptions.find((x) => x.id === teamPick)
    if (t == null) return
    const disp = t[loc]
    if (teams.some((x) => x.toLowerCase() === disp.toLowerCase())) {
      setTeamsMsg(`已经有 ${disp} 啦`)
      return
    }
    const next = [...teams, disp]
    setTeams(next)
    persistTeams(next)
    setTeamsMsg(`已添加 ${disp}`)
    await refresh()
  }

  /** 删除标签：即刻保存＋刷新；删到空即恢复默认（唔留一个空清单状态） */
  const removeTeam = async (name: string) => {
    const next = teams.filter((x) => x !== name)
    if (next.length === 0) {
      Storage.set(teamsKey, "")
      setTeams(DEFAULT_TEAMS)
      setCustomActive(false)
      setTeamsMsg("已恢复默认 10 间球队")
    } else {
      setTeams(next)
      persistTeams(next)
      setTeamsMsg(`已删除 ${name}`)
    }
    await refresh()
  }

  const resetTeams = async () => {
    Storage.set(teamsKey, "")
    setTeams(DEFAULT_TEAMS)
    setCustomActive(false)
    setTeamsMsg("已恢复默认 10 间球队")
    await refresh()
  }

  useEffect(() => {
    refresh()
  }, [])

  return (
    <NavigationStack>
      <VStack padding spacing={12}>
        <Text font="largeTitle" fontWeight="bold">
          Matchday
        </Text>
        <VStack spacing={8} alignment="leading">
          <Text font="headline">关注球队</Text>
          <Text font="caption" foregroundStyle="secondaryLabel">
            点 × 删除球队，下面先拣联赛再拣球队添加。
          </Text>
          <FlowLayout spacing={8}>
            {teams.map((t) => (
              <HStack key={t} spacing={4} padding={8} background="systemGray5">
                <Text font="subheadline" fontWeight="semibold">
                  {t}
                </Text>
                <Button title="×" action={() => removeTeam(t)} />
              </HStack>
            ))}
          </FlowLayout>
          <Picker
            title="选择联赛"
            value={leaguePick}
            onChanged={setLeaguePick}
            pickerStyle="menu"
          >
            {LEAGUES.map((l) => (
              <Text key={l.key} tag={l.key}>
                {l[loc]}
              </Text>
            ))}
          </Picker>
          {teamOptions.length > 0 ? (
            <HStack spacing={8}>
              <Picker
                title="选择球队"
                value={teamPick}
                onChanged={setTeamIdPick}
                pickerStyle="menu"
              >
                {teamOptions.map((t) => (
                  <Text key={t.id} tag={t.id}>
                    {t[loc]}
                  </Text>
                ))}
              </Picker>
              <Button title="添加" action={addTeam} />
            </HStack>
          ) : (
            <Text font="caption" foregroundStyle="secondaryLabel">
              呢个联赛嘅球队已经加晒
            </Text>
          )}
          <Button title="恢复默认" action={resetTeams} />
          {teamsMsg != null && (
            <Text font="caption" foregroundStyle="secondaryLabel">
              {teamsMsg}
            </Text>
          )}
        </VStack>
        <Divider />
        {data != null && data.matches.length > 0 && (() => {
          const live = data.matches.filter((m) => LIVE.has(m.status)).length
          const todayN = data.matches.filter((m) => isToday(m.date)).length
          const label =
            live > 0 ? `进行中 ${live} 场`
            : todayN > 0 ? `今日 ${todayN} 场`
            : `未来 ${data.matches.length} 场`
          return <Text font="headline">{label}</Text>
        })()}
        {data != null && data.matches.length > 0 ? (
          <VStack spacing={12}>
            {data.matches.map((m) => (
              <MatchRow key={m.id} m={m} />
            ))}
          </VStack>
        ) : (
          <Text foregroundStyle="secondaryLabel">
            {error != null ? "攞唔到赛程，点下面刷新试下" : "暂无相关赛程"}
          </Text>
        )}
        {data != null && data.fetchedAt > 0 && (
          <Text font="footnote" foregroundStyle="secondaryLabel">
            更新：{clockZh(data.fetchedAt)}
          </Text>
        )}
        {error != null && (
          <Text font="footnote" foregroundStyle="systemRed">
            刷新失败：{error}
          </Text>
        )}
        <Spacer />
        <Button title={loading ? "刷新紧…" : "↻ 刷新"} action={refresh} />
        <Divider />
        <Text font="caption" foregroundStyle="tertiaryLabel">
          {customActive
            ? `关注球队：${teams.join("、")}。国家队（FIFA 前 40）维持不变。显示未来最近 8 场，开球时间系手机当地时间。`
            : "收录：曼联、利物浦、阿仙奴、车路士、热刺、曼城、皇马、巴塞、拜仁、PSG，以及至少一方 FIFA 前 40 嘅国家队比赛。显示未来最近 8 场，开球时间系手机当地时间。"}
        </Text>
      </VStack>
    </NavigationStack>
  )
}

async function run() {
  await Navigation.present({
    element: <View />,
  })
  Script.exit()
}

run()
