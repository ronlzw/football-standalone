import {
  Button,
  Divider,
  FlowLayout,
  HStack,
  Image,
  Link,
  Navigation,
  NavigationStack,
  Script,
  Spacer,
  Text,
  TextField,
  VStack,
  Widget,
  useEffect,
  useState,
} from "scripting"
import {
  FootballData,
  DONE,
  LIVE,
  Match,
  OFF,
  clockZh,
  footballKey,
  fotmobUrl,
  isToday,
  koParts,
  teamsKey,
} from "./const"
import { parseTeamsText, refreshFootball } from "./football"

function CenterText({ m }: { m: Match }) {
  const ko = koParts(m.date)
  if (LIVE.has(m.status))
    return (
      <VStack spacing={2} alignment="trailing">
        <Text font="headline" fontWeight="bold">
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" fontWeight="bold" foregroundStyle="systemRed">
          进行中{m.elapsed != null ? ` ${m.elapsed}'` : ""}
        </Text>
      </VStack>
    )
  if (DONE.has(m.status))
    return (
      <VStack spacing={2} alignment="trailing">
        <Text font="headline" fontWeight="bold">
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" foregroundStyle="secondaryLabel">
          完场
        </Text>
      </VStack>
    )
  if (OFF.has(m.status))
    return (
      <Text font="subheadline" foregroundStyle="secondaryLabel">
        延期
      </Text>
    )
  return (
    <VStack spacing={2} alignment="trailing">
      <Text font="subheadline" foregroundStyle="secondaryLabel">
        {isToday(m.date) ? "今天" : ko.weekday}
      </Text>
      <Text font="subheadline">{ko.time12}</Text>
    </VStack>
  )
}

function MatchRow({ m }: { m: Match }) {
  return (
    <Link url={fotmobUrl(m)}>
      <HStack alignment="center" spacing={8}>
        <Image imageUrl={m.home.logo} resizable={true} frame={{ width: 26, height: 26 }} />
        <VStack spacing={2} alignment="leading">
          <Text font="subheadline" fontWeight="bold">
            {m.home.code ?? ""} vs {m.away.code ?? ""}
          </Text>
          <Text font="caption" foregroundStyle="tertiaryLabel">
            {m.league}
          </Text>
        </VStack>
        <Spacer />
        <CenterText m={m} />
        <Image imageUrl={m.away.logo} resizable={true} frame={{ width: 26, height: 26 }} />
      </HStack>
    </Link>
  )
}

/** 默认 10 间（标签预填用；存空即系呢个清单） */
const DEFAULT_TEAMS = ["曼联", "利物浦", "阿仙奴", "车路士", "热刺", "曼城", "皇马", "巴塞", "拜仁", "PSG"]

function View() {
  const [data, setData] = useState<FootballData | null>(
    Storage.get<FootballData>(footballKey) ?? null
  )
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const savedTeams = Storage.get<string>(teamsKey)
  const [teams, setTeams] = useState<string[]>(
    savedTeams != null && savedTeams.trim() !== "" ? parseTeamsText(savedTeams).raw : DEFAULT_TEAMS
  )
  const [customActive, setCustomActive] = useState(
    savedTeams != null && savedTeams.trim() !== ""
  )
  const [newTeam, setNewTeam] = useState("")
  const [teamsMsg, setTeamsMsg] = useState<string | null>(null)

  const refresh = async () => {
    setLoading(true)
    setError(null)
    const r = await refreshFootball()
    if (!r.ok) setError(r.error ?? "未知错误")
    setData(Storage.get<FootballData>(footballKey) ?? null)
    Widget.reloadAll()
    setLoading(false)
  }

  /** 即刻保存清单：空即恢复默认（清 Storage），其余存原文行 */
  const persistTeams = (list: string[]) => {
    if (list.length === 0) {
      Storage.set(teamsKey, "")
      setCustomActive(false)
    } else {
      Storage.set(teamsKey, list.join("\n"))
      setCustomActive(true)
    }
  }

  /** 添加：单行输入，一次可以打一间（打分隔符一次加几间都得）；即刻保存＋刷新 */
  const addTeam = async () => {
    const input = newTeam.trim()
    if (!input) return
    const p = parseTeamsText(input)
    const fresh = p.raw.filter((t) => !teams.some((x) => x.toLowerCase() === t.toLowerCase()))
    if (fresh.length === 0) {
      setTeamsMsg(`已经有 ${p.raw.join("、")} 啦`)
      return
    }
    const next = [...teams, ...fresh]
    setTeams(next)
    setNewTeam("")
    persistTeams(next)
    const warn = p.unknown.length > 0
      ? `（未能识别：${p.unknown.join("、")}，会按英文名原文匹配）`
      : ""
    setTeamsMsg(`已添加 ${fresh.join("、")}${warn}`)
    await refresh()
  }

  /** 删除标签：即刻保存＋刷新；删到空即恢复默认（唔留一个空清单状态） */
  const removeTeam = async (name: string) => {
    const next = teams.filter((x) => x !== name)
    if (next.length === 0) {
      Storage.set(teamsKey, "")
      setTeams(DEFAULT_TEAMS)
      setCustomActive(false)
      setTeamsMsg("已恢复默认 10 间球队")
    } else {
      setTeams(next)
      persistTeams(next)
      setTeamsMsg(`已删除 ${name}`)
    }
    await refresh()
  }

  const resetTeams = async () => {
    Storage.set(teamsKey, "")
    setTeams(DEFAULT_TEAMS)
    setCustomActive(false)
    setTeamsMsg("已恢复默认 10 间球队")
    await refresh()
  }

  useEffect(() => {
    refresh()
  }, [])

  return (
    <NavigationStack>
      <VStack padding spacing={12}>
        <Text font="largeTitle" fontWeight="bold">
          Matchday
        </Text>
        <VStack spacing={8} alignment="leading">
          <Text font="headline">关注球队</Text>
          <Text font="caption" foregroundStyle="secondaryLabel">
            点 × 删除球队，下面输入框添加新球队。
          </Text>
          <FlowLayout spacing={8}>
            {teams.map((t) => (
              <HStack key={t} spacing={4} padding={8} background="systemGray5">
                <Text font="subheadline" fontWeight="semibold">
                  {t}
                </Text>
                <Button title="×" action={() => removeTeam(t)} />
              </HStack>
            ))}
          </FlowLayout>
          <HStack spacing={8}>
            <TextField
              title="添加球队"
              prompt="例如：纽卡素"
              value={newTeam}
              onChanged={setNewTeam}
            />
            <Button title="添加" action={addTeam} />
          </HStack>
          <Button title="恢复默认" action={resetTeams} />
          {teamsMsg != null && (
            <Text font="caption" foregroundStyle="secondaryLabel">
              {teamsMsg}
            </Text>
          )}
        </VStack>
        <Divider />
        {data != null && data.matches.length > 0 && (() => {
          const live = data.matches.filter((m) => LIVE.has(m.status)).length
          const todayN = data.matches.filter((m) => isToday(m.date)).length
          const label =
            live > 0 ? `进行中 ${live} 场`
            : todayN > 0 ? `今日 ${todayN} 场`
            : `未来 ${data.matches.length} 场`
          return <Text font="headline">{label}</Text>
        })()}
        {data != null && data.matches.length > 0 ? (
          <VStack spacing={12}>
            {data.matches.map((m) => (
              <MatchRow key={m.id} m={m} />
            ))}
          </VStack>
        ) : (
          <Text foregroundStyle="secondaryLabel">
            {error != null ? "攞唔到赛程，点下面刷新试下" : "暂无相关赛程"}
          </Text>
        )}
        {data != null && data.fetchedAt > 0 && (
          <Text font="footnote" foregroundStyle="secondaryLabel">
            更新：{clockZh(data.fetchedAt)}
          </Text>
        )}
        {error != null && (
          <Text font="footnote" foregroundStyle="systemRed">
            刷新失败：{error}
          </Text>
        )}
        <Spacer />
        <Button title={loading ? "刷新紧…" : "↻ 刷新"} action={refresh} />
        <Divider />
        <Text font="caption" foregroundStyle="tertiaryLabel">
          {customActive
            ? `关注球队：${teams.join("、")}。国家队（FIFA 前 40）维持不变。显示未来最近 8 场，开球时间系手机当地时间。`
            : "收录：曼联、利物浦、阿仙奴、车路士、热刺、曼城、皇马、巴塞、拜仁、PSG，以及至少一方 FIFA 前 40 嘅国家队比赛。显示未来最近 8 场，开球时间系手机当地时间。"}
        </Text>
      </VStack>
    </NavigationStack>
  )
}

async function run() {
  await Navigation.present({
    element: <View />,
  })
  Script.exit()
}

run()
