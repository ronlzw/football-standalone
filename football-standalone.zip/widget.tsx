import { Button, HStack, Image, Link, Spacer, Text, VStack, Widget, ZStack } from "scripting"
import type { DynamicImageSource, DynamicShapeStyle } from "scripting"
import { RefreshFootballStandaloneIntent, TogglePrevFootballStandaloneIntent, ToggleTvFootballStandaloneIntent } from "./app_intents"
import { widgetLocale, halftimeLabel, refreshBroadcastIfStale, refreshFootball, refreshFootballFast } from "./football"
import {
  BroadcastTable,
  FootballData,
  DONE,
  LIVE,
  Match,
  OFF,
  WIDGET_WORDS,
  broadcastRemoteKey,
  flowTvRows,
  footballKey,
  isRefreshingFresh,
  localYMD,
  parseBroadcastTable,
  pickTvMatches,
  broadcastForMatch,
  prevViewKey,
  refreshingAtKey,
  transparentKey,
  transparentLightInverseKey,
  transparentDarkInverseKey,
  tvChannelsFor,
  tvCapsuleShowsGroup,
  tvViewKey,
  fotmobUrl,
  isToday,
  refreshTier,
  widgetClock,
  widgetDateTitle,
  widgetKo,
} from "./const"

// v1.1.30 FotMob 风格配色（浅色 / 深色；颜色一律打 DynamicShapeStyle 类型，唔好 widen 成 string 致 TS2322）
const CARD_BG: DynamicShapeStyle = { light: "#FFFFFF", dark: "#1C1C1E" }
const GRID_BG: DynamicShapeStyle = { light: "#F8F8F8", dark: "#1E1E1F" }
// 分割线已删（用户 2026-10-30 晚：非透明都唔要分割线；行高／列宽公式保留 1pt 预留，版式唔变）
// v1.1.46：标题日期色——FotMob 实测：浅色 #333333、深色纯白；同 GRAY_COLOR（#8E8E93）唔同，日期唔再用灰
const DATE_COLOR: DynamicShapeStyle = { light: "#333333", dark: "#FFFFFF" }
const LABEL_COLOR: DynamicShapeStyle = { light: "#000000", dark: "#FFFFFF" }
const TIME_COLOR: DynamicShapeStyle = { light: "#717171", dark: "#9F9F9F" }
const GRAY_COLOR: DynamicShapeStyle = { light: "#8E8E93", dark: "#8E8E93" }
// v1.1.60：进行中分钟绿色（FotMob 样式；浅色深绿、深色亮绿）
const LIVE_GREEN: DynamicShapeStyle = { light: "#009E4D", dark: "#32D158" }

// 透明壁纸模式：设置页开关，默认关；开时灰字转主色（浅／深色可各自选主题色或反色），非透明完全不变；分割线已删（任何模式都无）
let transparentMode = false
let transparentLightInverse = false
let transparentDarkInverse = false
let transparentTextColor: DynamicShapeStyle = LABEL_COLOR
// 用户 2026-10-31 定：透明＋反色时，全部配色成个换去另一边默认主题（浅色用白字＝深色主题配色，深色用黑字＝浅色主题配色）；非透明／主题时用本身外观配色
// v1.1.61：FotMob 官方完场钟仔（由 FotMob IPA WidgetExtension Assets.car 抽出嘅 ic_fulltime，托管喺 VPS）
const CLOCK_ICON = "https://yt.adi-ronnie.top/api/fotmob-clock.png"
const CLOCK_ICON_WHITE = "https://yt.adi-ronnie.top/api/fotmob-clock-white.png"
const CLOCK_ICON_BLACK = "https://yt.adi-ronnie.top/api/fotmob-clock-black.png"
// 钟仔图标跟透明字色走：主题＝原灰图，反色＝白／黑图；DynamicImageSource 俾系统渲染时按浅深色拣，唔用 useColorScheme
let clockIcon: DynamicImageSource<string> = { light: CLOCK_ICON, dark: CLOCK_ICON }
// v1.1.63：标题图标改用 FotMob 官方 App 图标（由 FotMob IPA 内附文件 AppIcon60x60@2x.png 经 CgBI 还原，托管喺 VPS）
// v1.1.64 修正：标题图标改用 FotMob 小组件右上角嗰个黑圆白 F logo（v1.1.63 误用咗绿底 App 图标；F 字形取自 IPA App 图标，黑圆系重绘，托管喺 VPS）
// v1.1.71：标题图标分浅深色——浅色黑圆白 F、深色白圆黑 F；用 DynamicImageSource 俾系统渲染时拣，唔用 useColorScheme()（widget 进程外观唔同步）
const TITLE_ICON: DynamicImageSource<string> = {
  light: "https://yt.adi-ronnie.top/api/fotmob-flogo-black.png",
  dark: "https://yt.adi-ronnie.top/api/fotmob-flogo-white.png",
}
// 透明＋反色时，全部配色成个换去另一边默认主题；DynamicShapeStyle／DynamicImageSource 俾系统渲染时按浅深色拣
let liveGreen: DynamicShapeStyle = LIVE_GREEN
let dateColor: DynamicShapeStyle = DATE_COLOR
let titleIcon: DynamicImageSource<string> = TITLE_ICON
// 1.0.13：之前八场视图开关（run() 由 Storage 读入；true 即显示 prevMatches）
let showPrev = false
// 1.0.21：电视视图开关（run() 由 Storage 读入；true 即显示电视视图，同之前八场互斥）
let showTv = false
// 1.0.21：电视视图胶囊底色——浅色淡黑半透明、深色淡白半透明（照士碌架胶囊 rgba(255,255,255,0.10)，跟足球浅深色走）
const TV_CAPSULE_BG: DynamicShapeStyle = { light: "rgba(0,0,0,0.06)", dark: "rgba(255,255,255,0.10)" }
// 1.0.21：远程直播表缓存（run() 由 Storage 读入并校验；攞唔到／校验失败即 null，配对唔到场次）
let broadcastTable: BroadcastTable | null = null

/** 预览人数（v1.1.25，用户规格）：桌面实例参数填 preview:N（如 preview:7）先会用现有比赛
 *  循环复制凑够 N 场检查布局；无参数／格式唔啱／N<=0 一律用真实数据，代码里唔留常量 */
function previewCount(): number {
  try {
    const param = Widget.parameter
    if (typeof param !== "string") return 0
    const m = param.match(/preview:(\d+)/)
    if (m == null) return 0
    const n = parseInt(m[1], 10)
    return Number.isFinite(n) && n > 0 ? n : 0
  } catch {
    return 0
  }
}

function previewExpand(list: Match[]): Match[] {
  const n = previewCount()
  if (n <= 0 || list.length === 0) return list
  return Array.from({ length: n }, (_, i) => list[i % list.length])
}

/** 左右两边：队徽 + 三字缩写 */
function TeamCol({ team, size, abbrFont = "headline" }: { team: Match["home"]; size: number; abbrFont?: "headline" | "subheadline" }) {
  return (
    <VStack spacing={4} alignment="center">
      <Image imageUrl={team.logo} resizable={true} frame={{ width: size, height: size }} />
      <Text font={abbrFont} fontWeight="bold" lineLimit={1}>
        {team.code ?? ""}
      </Text>
    </VStack>
  )
}

/** 中间：进行中（比分+分钟）/ 完场（比分）/ 日期 + 开球时间；
 *  1.0.14：半场出绿字 HT（跟 FotMob，所有语言一致），唔再出「进行中」 */
function CenterCol({ m }: { m: Match }) {
  const loc = widgetLocale()
  const W = WIDGET_WORDS[loc]
  const ko = widgetKo(m.date, loc)
  if (LIVE.has(m.status)) {
    return (
      <VStack spacing={2} alignment="center" frame={{ width: 68 }}>
        <Text font="headline" fontWeight="bold" lineLimit={1}>
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" fontWeight="medium" foregroundStyle={m.ht ? liveGreen : (transparentMode ? transparentTextColor : TIME_COLOR)} lineLimit={1}>
          {m.ht ? "HT" : m.elapsed != null ? `${m.elapsed}'` : W.live}
        </Text>
      </VStack>
    )
  }
  if (DONE.has(m.status)) {
    return (
      <VStack spacing={2} alignment="center" frame={{ width: 68 }}>
        <Text font="headline" fontWeight="bold" lineLimit={1}>
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" foregroundStyle={transparentMode ? transparentTextColor : "secondaryLabel"} lineLimit={1}>
          {W.done}
        </Text>
      </VStack>
    )
  }
  if (OFF.has(m.status)) {
    return (
      <Text font="subheadline" foregroundStyle={transparentMode ? transparentTextColor : "secondaryLabel"} lineLimit={1}>
        {W.off}
      </Text>
    )
  }
  return (
    <VStack spacing={2} alignment="center" frame={{ width: 68 }}>
      <Text font="caption" fontWeight={transparentMode ? "medium" : undefined} foregroundStyle={transparentMode ? transparentTextColor : "secondaryLabel"} lineLimit={1}>
        {isToday(m.date) ? W.today : ko.weekday}
      </Text>
      <Text font="caption" fontWeight={transparentMode ? "semibold" : "medium"} foregroundStyle={transparentMode ? transparentTextColor : TIME_COLOR} lineLimit={1}>
        {ko.time12}
      </Text>
    </VStack>
  )
}

/** 1 场：照 FotMob 单场 widget — 冇灰卡，中间联赛 logo＋「日期 时间」 */
function HeroCenter({ m }: { m: Match }) {
  const loc = widgetLocale()
  const W = WIDGET_WORDS[loc]
  const ko = widgetKo(m.date, loc)
  const icon = Widget.family === "systemLarge" ? 30 : 24
  if (LIVE.has(m.status)) {
    return (
      <VStack spacing={2} alignment="center">
        <Text font="title3" fontWeight="bold" lineLimit={1}>
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" fontWeight="medium" foregroundStyle={m.ht ? liveGreen : (transparentMode ? transparentTextColor : TIME_COLOR)} lineLimit={1}>
          {m.ht ? "HT" : m.elapsed != null ? `${m.elapsed}'` : W.live}
        </Text>
      </VStack>
    )
  }
  if (DONE.has(m.status)) {
    return (
      <VStack spacing={2} alignment="center">
        <Text font="title3" fontWeight="bold" lineLimit={1}>
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" foregroundStyle={transparentMode ? transparentTextColor : "secondaryLabel"} lineLimit={1}>
          {W.done}
        </Text>
      </VStack>
    )
  }
  if (OFF.has(m.status)) {
    return (
      <Text font="subheadline" foregroundStyle={transparentMode ? transparentTextColor : "secondaryLabel"} lineLimit={1}>
        {W.off}
      </Text>
    )
  }
  return (
    <VStack spacing={6} alignment="center">
      {m.leagueLogo ? (
        <Image imageUrl={m.leagueLogo} resizable={true} frame={{ width: icon, height: icon }} />
      ) : (
        <Image systemName="trophy.fill" font="body" foregroundStyle={transparentMode ? transparentTextColor : "secondaryLabel"} />
      )}
      <VStack spacing={2} alignment="center">
        <Text font="caption" fontWeight={transparentMode ? "medium" : undefined} foregroundStyle={transparentMode ? transparentTextColor : "secondaryLabel"} lineLimit={1}>
          {isToday(m.date) ? W.today : ko.weekday}
        </Text>
        <Text font="caption" fontWeight={transparentMode ? "semibold" : "medium"} foregroundStyle={transparentMode ? transparentTextColor : TIME_COLOR} lineLimit={1}>
          {ko.time12}
        </Text>
      </VStack>
    </VStack>
  )
}

/** 1 场：大版式，尺寸按 widget family 自适应 */
function HeroMatch({ m }: { m: Match }) {
  const small = Widget.family === "systemSmall"
  const medium = Widget.family === "systemMedium"
  const logo = small ? 36 : medium ? 40 : 62
  const padV = small ? 8 : medium ? 12 : 20
  return (
    <Link url={fotmobUrl(m)}>
      <HStack alignment="center" spacing={8} padding={{ horizontal: 24, vertical: padV }}>
        <TeamCol team={m.home} size={logo} />
        <VStack alignment="center" frame={{ maxWidth: "infinity" }}>
          <HeroCenter m={m} />
        </VStack>
        <TeamCol team={m.away} size={logo} />
      </HStack>
    </Link>
  )
}

/** 2–4 场：单列，行之间分隔线（large 先用，medium 太矮摆唔落）
 *  v1.1.25 高度修复（用户规格）：旧版每行约 74pt，4 场连标题/更新/padding 溢出约 28pt，
 *  标题俾挤出顶部。而家行高按可用高度计：（总高 − 上下 padding 24 − 标题 28 − 更新 14
 *  − 两个 spacing 12 − 分隔线总高度）÷ 场数，夹喺 56–78pt；displaySize.height 读唔到就用 382。
 *  行高取代旧上下 padding 8；卡内上下 Spacer 令夹到上限嘅行（2–3 场）垂直置中、卡撑满。
 *  4 场时队徽 30 + 缩写 subheadline；2–3 场维持 32 + headline。 */
function ListCard({ matches }: { matches: Match[] }) {
  const n = matches.length
  const dh = Widget.displaySize != null ? Widget.displaySize.height : 0
  const H = typeof dh === "number" && dh > 0 ? dh : 382
  const DIVIDER_H = 1
  const rowH = Math.max(56, Math.min(78, (H - 24 - 28 - 14 - 12 - DIVIDER_H * (n - 1)) / n))
  const four = n === 4
  const crest = four ? 30 : 32
  const abbrFont = four ? "subheadline" : "headline"
  return (
    <VStack spacing={0} frame={{ maxHeight: "infinity" }}>
      <Spacer />
      {matches.map((m, i) => (
        <VStack key={`${m.id}-${i}`} spacing={0}>
          <Link url={fotmobUrl(m)}>
            <HStack alignment="center" spacing={8} padding={{ horizontal: 24 }} frame={{ height: rowH }}>
              <TeamCol team={m.home} size={crest} abbrFont={abbrFont} />
              <Spacer />
              <CenterCol m={m} />
              <Spacer />
              <TeamCol team={m.away} size={crest} abbrFont={abbrFont} />
            </HStack>
          </Link>
        </VStack>
      ))}
      <Spacer />
    </VStack>
  )
}

/** 网格格仔中央（v1.1.61 FotMob 样式：比分夹住中间状态——进行中分钟／半场绿色、点球途中按 FotMob 显示法定时间（90'）、无分钟回退开波时间；完场用 FotMob 官方钟仔图标夹中间；点球完场下行加 (ph - pa)；未开波唔变。字号比例跟 FotMob：比分大号 headline／中号 caption，中间字大号 subheadline／中号 caption2；
 *  1.0.14：半场所有语言都用绿字 HT，跟 FotMob，同主版 v1.1.86 一致；
 *  1.0.15：未开赛时间跟主版 v1.1.88／v1.1.89——大号统一 12.5pt 数字字号（最长串都唔使缩放，xx:xx 同 x:xx 同字号），
 *  中号 caption（12pt）唔变；型别直接用 "caption" | number，唔用 string | number（主版 1.1.88 编辑器报错教训）；时间格式维持上午／下午） */
function GridCenter({ m, medium }: { m: Match; medium: boolean }) {
  const loc = widgetLocale()
  const W = WIDGET_WORDS[loc]
  const scoreFont = medium ? "caption" : "headline"
  const midFont = medium ? "caption2" : "caption"  // v1.1.62：中间时间再细一级（大号 subheadline 15→caption 12；中号 caption2 11 已系最细，唔变）
  // 1.0.8 对齐：比分＋中间固定槽宽（比分 12/8、进行中中间 24/22；完场钟仔 16/14＋间距 8，块宽恒等），live／完场比分纵向对齐；比分 minScaleFactor 0.5 容双位数；无分钟回退时间唔固定宽（防截断）
  const scoreW = medium ? 8 : 12
  const midW = medium ? 22 : 24
  if (LIVE.has(m.status)) {
    const ko = widgetKo(m.date, loc)
    const mid = m.ht ? halftimeLabel(loc) : m.elapsed != null ? `${m.elapsed}'` : ko.time12
    const midColor = m.ht || m.elapsed != null ? liveGreen : (transparentMode ? transparentTextColor : TIME_COLOR)
    return (
      <HStack spacing={4} alignment="center">
        <Text font={scoreFont} fontWeight="bold" foregroundStyle={transparentMode ? transparentTextColor : LABEL_COLOR} lineLimit={1} minScaleFactor={0.5} frame={{ width: scoreW }}>
          {m.gh}
        </Text>
        <Text font={midFont} fontWeight="bold" foregroundStyle={midColor} lineLimit={1} minScaleFactor={0.7} frame={m.ht || m.elapsed != null ? { width: midW } : undefined}>
          {mid}
        </Text>
        <Text font={scoreFont} fontWeight="bold" foregroundStyle={transparentMode ? transparentTextColor : LABEL_COLOR} lineLimit={1} minScaleFactor={0.5} frame={{ width: scoreW }}>
          {m.ga}
        </Text>
      </HStack>
    )
  }
  if (DONE.has(m.status)) {
    // v1.1.63：完场比分同钟仔间距由 4 拉远到 8
    const clockRow = (
      <HStack spacing={8} alignment="center">
        <Text font={scoreFont} fontWeight="bold" foregroundStyle={transparentMode ? transparentTextColor : LABEL_COLOR} lineLimit={1} minScaleFactor={0.5} frame={{ width: scoreW }}>
          {m.gh}
        </Text>
        <Image imageUrl={clockIcon} resizable={true} frame={{ width: medium ? 14 : 16, height: medium ? 14 : 16 }} />
        <Text font={scoreFont} fontWeight="bold" foregroundStyle={transparentMode ? transparentTextColor : LABEL_COLOR} lineLimit={1} minScaleFactor={0.5} frame={{ width: scoreW }}>
          {m.ga}
        </Text>
      </HStack>
    )
    if (m.status === "PEN") {
      return (
        <VStack spacing={2} alignment="center">
          {clockRow}
          {m.ph != null && m.pa != null && (
            <Text font="caption2" foregroundStyle={transparentMode ? transparentTextColor : LABEL_COLOR} lineLimit={1}>
              ({m.ph} - {m.pa})
            </Text>
          )}
        </VStack>
      )
    }
    return clockRow
  }
  if (OFF.has(m.status)) {
    return (
      <Text font="subheadline" foregroundStyle={transparentMode ? transparentTextColor : "secondaryLabel"} lineLimit={1}>
        {W.off}
      </Text>
    )
  }
  const ko = widgetKo(m.date, loc)
  // 1.0.15：未开赛时间统一字号，大号 12.5pt、中号 caption（12pt），原先今日 caption2（11pt）／星期几 caption（12pt）
  const upcomingFont: "caption" | number = medium ? "caption" : 12.5
  if (isToday(m.date)) {
    return (
      <Text
        font={upcomingFont}
        fontWeight="semibold"
        foregroundStyle={transparentMode ? transparentTextColor : TIME_COLOR}
        lineLimit={1}
        minScaleFactor={0.75}
        multilineTextAlignment="center"
      >
        {ko.time12}
      </Text>
    )
  }
  return (
    <VStack spacing={2} alignment="center">
      <Text font={upcomingFont} fontWeight={transparentMode ? "medium" : undefined} foregroundStyle={transparentMode ? transparentTextColor : "secondaryLabel"} lineLimit={1}>
        {ko.weekday}
      </Text>
      <Text
        font={upcomingFont}
        fontWeight="semibold"
        foregroundStyle={transparentMode ? transparentTextColor : TIME_COLOR}
        lineLimit={1}
        minScaleFactor={0.75}
        multilineTextAlignment="center"
      >
        {ko.time12}
      </Text>
    </VStack>
  )
}

/** 5–8 场（large）／2–4 场（medium）：两列网格，无分隔线
 *  v1.1.36：列宽 colW 由 displaySize 减 GRID_PAD 计出（固定值，唔用 maxWidth）；
 *  v1.1.42：每格改 ZStack 三层——时间文字置中，左队徽中心在列宽 22%、右队徽在 82%
 *  （offset = colW × −0.28／+0.32；队徽大 24／中 20）；奇数场最后一行右列用空 VStack 占位；
 *  v1.1.43：时间改固定 80pt 槽置中（GridCenter 原样，两边 Spacer 夹住），队徽 offset 改
 *  ±(48 + logo/2)（40 槽半 + 8 间距 + 队徽半），左右到时间嘅距离恒等，唔再用列宽百分比；
 *  v1.1.44：时间槽改 64pt，队徽大 26／中 22，offset = ±(32 + 6 + logo/2)（大 ±51、中 ±49），
 *  槽到队徽间隙恒为 6pt。注意：64 槽唔用两边 Spacer 夹住——(64−53)/2 = 5.5pt 细过 Spacer
 *  约 8pt 下限，会令“上午 10:00”缩到 0.91；改用 64 阔 VStack 置中包住 GridCenter（无 Spacer），
 *  CENTER_SLOT 只做 offset 公式嘅参考值，文字全大细、唔缩放、唔截断 */
function GridCell({ m, colW, rowH }: { m: Match; colW: number; rowH: number }) {
  const medium = Widget.family === "systemMedium"
  const logo = medium ? 22 : 26
  const CENTER_SLOT = 64
  const off = CENTER_SLOT / 2 + 6 + logo / 2
  return (
    <Link url={fotmobUrl(m)}>
      <ZStack alignment="center" frame={{ width: colW, height: rowH }}>
        <VStack frame={{ width: CENTER_SLOT }} alignment="center">
          <GridCenter m={m} medium={medium} />
        </VStack>
        <Image imageUrl={m.home.logo} resizable={true} frame={{ width: logo, height: logo }} offset={{ x: -off, y: 0 }} />
        <Image imageUrl={m.away.logo} resizable={true} frame={{ width: logo, height: logo }} offset={{ x: off, y: 0 }} />
      </ZStack>
    </Link>
  )
}

/** 电视视图单场行（1.0.21，主版 v1.1.97–1.1.100 同款）：队徽 16pt＋三字缩写＋中间比分／分钟（LIVE 绿字）或开球时间；
 *  行高＝内容本身：比赛行约 16pt＋间距 2＋胶囊行约 21pt（2 行胶囊 46pt）／无台约 33pt，唔再撑固定 rowH；
 *  两队改由左右 Spacer 将成组推去中间，唔再贴左右边；小尺寸可用阔得 154pt、一行放唔晒两队＋开球时间，
 *  小尺寸改做两行（两队一行、开球时间一行，全部居中），比赛行高变 16＋2＋15＝33pt。
 *  开球标签跟小组件语言（widgetKo：听日「明天」／后日「后天」，四语；主版 koParts 简体同款）。
 *  胶囊名 12pt、分类 10pt；大号最多 2 行胶囊，中／小号最多 1 行。 */
function TvMatchLine({ m }: { m: Match }) {
  const loc = widgetLocale()
  const W = WIDGET_WORDS[loc]
  const ko = widgetKo(m.date, loc)
  const live = LIVE.has(m.status)
  const center = live
    ? m.ht
      ? `${m.gh} - ${m.ga}  HT`
      : m.elapsed != null
        ? `${m.gh} - ${m.ga}  ${m.elapsed}'`
        : `${m.gh} - ${m.ga}`
    : isToday(m.date)
      ? `${W.today} ${ko.time12}`
      : `${ko.weekday} ${ko.time12}`
  // 小尺寸得 154pt 可用阔，一行放唔晒两队＋开球时间（约 180pt）——
  // 小尺寸改做两行：第一行两队居中、第二行开球时间居中；中／大尺寸维持一行居中组。
  if (Widget.family === "systemSmall") {
    return (
      <VStack spacing={2} alignment="center" frame={{ maxWidth: "infinity" }}>
        <HStack alignment="center" spacing={0}>
          <Spacer />
          <Image imageUrl={m.home.logo} resizable={true} frame={{ width: 16, height: 16 }} />
          <Text font="caption" fontWeight="bold" foregroundStyle={transparentMode ? transparentTextColor : LABEL_COLOR} lineLimit={1} padding={{ leading: 6, trailing: 8 }}>
            {m.home.code ?? ""}
          </Text>
          <Text font="caption" fontWeight="bold" foregroundStyle={transparentMode ? transparentTextColor : GRAY_COLOR} lineLimit={1}>
            -
          </Text>
          <Text font="caption" fontWeight="bold" foregroundStyle={transparentMode ? transparentTextColor : LABEL_COLOR} lineLimit={1} padding={{ leading: 8, trailing: 6 }}>
            {m.away.code ?? ""}
          </Text>
          <Image imageUrl={m.away.logo} resizable={true} frame={{ width: 16, height: 16 }} />
          <Spacer />
        </HStack>
        <Text font="caption" fontWeight={live ? "bold" : "medium"} foregroundStyle={live ? liveGreen : transparentMode ? transparentTextColor : TIME_COLOR} lineLimit={1}>
          {center}
        </Text>
      </VStack>
    )
  }
  return (
    <HStack alignment="center" spacing={0} frame={{ maxWidth: "infinity" }}>
      <Spacer />
      <Image imageUrl={m.home.logo} resizable={true} frame={{ width: 16, height: 16 }} />
      <Text font="caption" fontWeight="bold" foregroundStyle={transparentMode ? transparentTextColor : LABEL_COLOR} lineLimit={1} padding={{ leading: 6, trailing: 12 }}>
        {m.home.code ?? ""}
      </Text>
      <Text font="caption" fontWeight={live ? "bold" : "medium"} foregroundStyle={live ? liveGreen : transparentMode ? transparentTextColor : TIME_COLOR} lineLimit={1}>
        {center}
      </Text>
      <Text font="caption" fontWeight="bold" foregroundStyle={transparentMode ? transparentTextColor : LABEL_COLOR} lineLimit={1} padding={{ leading: 12, trailing: 6 }}>
        {m.away.code ?? ""}
      </Text>
      <Image imageUrl={m.away.logo} resizable={true} frame={{ width: 16, height: 16 }} />
      <Spacer />
    </HStack>
  )
}

/** 电视视图单场：比赛行＋胶囊行（1.0.21，胶囊渲染照抄士碌架 1.0.52／1.0.53：
 *  每台一粒胶囊，分类同行写喺名右边，10pt、前面唔加「- 」；每行左边唔要 tv 图标，
 *  胶囊由行头开始、第一行唔再减 17；全部台都显示类别（1.0.23 删走 DAZN 例外，tvCapsuleShowsGroup 永远 true）。
 *  净系显示有 Gary 映射嘅台；成场都冇映射台就写「暂无直播资料」，唔留空。 */
function TvRow({ m, maxW, maxCapsuleRows }: { m: Match; maxW: number; maxCapsuleRows: number }) {
  const W = WIDGET_WORDS[widgetLocale()]
  const channels = tvChannelsFor(broadcastForMatch(m, broadcastTable))
  const rows = flowTvRows(channels, maxW, 6, 0).slice(0, maxCapsuleRows)
  return (
    <VStack spacing={2} alignment="leading" frame={{ maxWidth: "infinity" }}>
      <TvMatchLine m={m} />
      {channels.length > 0 ? (
        <VStack spacing={4} alignment="leading" frame={{ maxWidth: "infinity" }}>
          {rows.map((row, ri) => (
            <HStack key={ri} alignment="center" spacing={6} frame={{ maxWidth: "infinity" }}>
              {row.map((ch) => (
                <HStack
                  key={ch.name}
                  alignment="center"
                  spacing={5}
                  padding={{ leading: 8, trailing: 8, top: 3, bottom: 3 }}
                  background={TV_CAPSULE_BG}
                  clipShape={{ type: "rect", cornerRadius: 8 }}
                >
                  <Text font={12} foregroundStyle={transparentMode ? transparentTextColor : LABEL_COLOR} lineLimit={1}>
                    {ch.name}
                  </Text>
                  {tvCapsuleShowsGroup(ch.name) && (
                    <Text font={10} foregroundStyle={transparentMode ? transparentTextColor : GRAY_COLOR} lineLimit={1}>
                      {ch.group}
                    </Text>
                  )}
                </HStack>
              ))}
              <Spacer />
            </HStack>
          ))}
        </VStack>
      ) : (
        <HStack alignment="center" spacing={4} frame={{ maxWidth: "infinity" }}>
          <Image systemName="tv.slash" font={11} foregroundStyle={transparentMode ? transparentTextColor : GRAY_COLOR} />
          <Text font={11} foregroundStyle={transparentMode ? transparentTextColor : GRAY_COLOR} lineLimit={1}>
            {W.tvNoData}
          </Text>
        </HStack>
      )}
    </VStack>
  )
}

/** 电视视图（1.0.21）：大号 4 场、中号 2 场（高度预算只够 2 场连胶囊）、小号 1 场；
 *  无场（缓存无 live、无未开波 NS）就置中写明，唔留空。 */
function TvView({ matches }: { matches: Match[] }) {
  const W = WIDGET_WORDS[widgetLocale()]
  const dw = Widget.displaySize != null && typeof Widget.displaySize.width === "number" && Widget.displaySize.width > 0
    ? Widget.displaySize.width
    : Widget.family === "systemSmall" ? 170 : Widget.family === "systemMedium" ? 342 : 366
  const maxW = dw - 16
  const maxCapsuleRows = Widget.family === "systemLarge" ? 2 : 1
  if (matches.length === 0) {
    return (
      <VStack alignment="center" frame={{ maxHeight: "infinity" }}>
        <HStack alignment="center" spacing={4}>
          <Image systemName="tv.slash" font={11} foregroundStyle={transparentMode ? transparentTextColor : GRAY_COLOR} />
          <Text font={11} foregroundStyle={transparentMode ? transparentTextColor : GRAY_COLOR} lineLimit={1}>
            {W.tvNoData}
          </Text>
        </HStack>
      </VStack>
    )
  }
  return (
    <VStack spacing={6} alignment="leading" frame={{ maxWidth: "infinity" }}>
      {matches.map((m) => (
        <TvRow key={m.id} m={m} maxW={maxW} maxCapsuleRows={maxCapsuleRows} />
      ))}
    </VStack>
  )
}

/* GridCard 列宽：同 WidgetView 外层水平内边距 8 一致 */
const GRID_PAD = 8

function GridCard({ matches, rowH }: { matches: Match[]; rowH: number }) {
  const pairs: Match[][] = []
  for (let i = 0; i < matches.length; i += 2) pairs.push(matches.slice(i, i + 2))
  const dw = Widget.displaySize != null && typeof Widget.displaySize.width === "number" && Widget.displaySize.width > 0
    ? Widget.displaySize.width
    : Widget.family === "systemMedium" ? 342 : 366
  const gridW = dw - GRID_PAD * 2
  // v1.1.46：列宽预留改 0.5→1（竖分割线而家系 1pt，FotMob 实测 3px）；算出嚟 colW 大／中都系 174／162，同之前一样
  const colW = Math.floor((gridW - 1) / 2)
  return (
    <VStack spacing={0}>
      {pairs.map((p, i) => (
        <VStack key={i} spacing={0}>
          <HStack spacing={0} alignment="center">
            <VStack spacing={0} frame={{ width: colW }}>
              <GridCell m={p[0]} colW={colW} rowH={rowH} />
            </VStack>
            {p[1] != null ? (
              <HStack spacing={0} alignment="center">
                <VStack spacing={0} frame={{ width: colW }}>
                  <GridCell m={p[1]} colW={colW} rowH={rowH} />
                </VStack>
              </HStack>
            ) : (
              <VStack frame={{ width: colW }} />
            )}
          </HStack>
        </VStack>
      ))}
    </VStack>
  )
}

function WidgetView({ data }: { data: FootballData | null }) {
  // 手动刷新进行中（intent 啱啱写咗时间戳）：底部时间显示 "…"，30 秒过期自动恢复
  const refreshingFresh = isRefreshingFresh(Storage.get<number>(refreshingAtKey) ?? null)
  // 1.0.13：之前视图用 prevMatches；大号取全部 8 场，中／小号取尾段（最近 4／1 场），
  // 即系紧贴现时显示之前嗰批；现时视图维持原样取首段。
  const base = showPrev ? (data?.prevMatches ?? []) : (data?.matches ?? [])
  const all = previewExpand(base)
  const wloc = widgetLocale()
  const W = WIDGET_WORDS[wloc]
  const max = Widget.family === "systemSmall" ? 1 : Widget.family === "systemMedium" ? 4 : 8
  const shown = showPrev ? all.slice(-max) : all.slice(0, max)
  const n = shown.length

  const hero = n === 1 ? shown[0] : null
  // v1.1.45：标题联赛——显示中比赛全部同一联赛就用该联赛名＋logo，否则 Matchday
  const firstLeague = shown.length > 0 ? shown[0].league : null
  const uniformLeague = shown.length > 0 && shown.every((m) => m.league === firstLeague)
  const titleLeague = uniformLeague ? firstLeague : null
  const titleLogo = uniformLeague ? shown.find((m) => m.leagueLogo != null)?.leagueLogo ?? null : null
  // v1.1.25：large 2–4 场（ListCard）专用——去卡外侧两个 Spacer、卡撑满，标题/更新行唔俾挤出
  const isList = Widget.family === "systemLarge" && n > 1 && n <= 4
  // v1.1.30：small 沿用现有布局（标题 title3、无日期、F 标 28），其余尺寸用 title2、日期、F 标 24
  const small = Widget.family === "systemSmall"
  const medium = Widget.family === "systemMedium"  // v1.1.58：中尺寸专用预算开关
  // v1.1.37：网格高度按实际尺寸计——dh 读唔到时按大 382／中 158 fallback；
  // gridH = dh − 16（顶部内边距）− 12（底部内边距）− 30（标题）− 24（底部刷新行）− 12（两处 spacing）− 12（上下留白）
  // v1.1.43 修正：spec 原写 −4 会令上下 Spacer 得 −8pt（内容超出 widget 8pt、页脚被裁）；
  // 改 −12 令 Spacer 归零、刚好贴合，网格到底部刷新行距离由 16pt 缩到 12pt（净返两处 6pt 间距）
  // v1.1.44：顶部内边距 12→16，内边距项同步 24→28（网格整体下移 4pt、网格高度缩 4pt，
  // 底部刷新行位置不变）；spec 原文 horizontal: 14 唔跟——外层水平而家系 8（同 GRID_PAD 配对），
  // 照写 14 会令行宽超出容器 12pt；spec 嘅 −4 同样唔跟（会再次溢出 8pt），继续用 −12
  // v1.1.45：底部刷新行 16→24，公式同步减多 8（dh−106）；spec 原写 dh−98（16＋12＋30＋24＋12＋4）
  // 只计两处 spacing，实际有四处 6pt 间距，差 8pt 会再次溢出页脚，所以留白项继续用 −12
  const dh = Widget.displaySize != null && typeof Widget.displaySize.height === "number" && Widget.displaySize.height > 0
    ? Widget.displaySize.height
    : Widget.family === "systemMedium" ? 158 : 382
  // v1.1.58：中尺寸解压扁——中号两行格实际约 30pt（caption2 行高＋2＋caption 行高），旧行高 25 会溢出挤压；
  // v1.1.59：用户定维持 4 场、尽量利用上下空隙——中号预算再压：顶距 4＋底距 4＋标题 30＋底部行 18＋四处间距 16＝72，gridH＝dh−72＝86，行高 (86−1)/2＝42；大／小号预算唔变
  const gridH = medium ? dh - 72 : dh - 16 - 12 - 30 - 24 - 12 - 12
  const rows = Math.max(1, Math.ceil(n / 2))
  // v1.1.46：行高预留改做 (rows - 1) × 1pt（横分割线而家系 1pt）；算出嚟大 68／大 9 系 54／中 25，同之前一模一样
  const rowH = Math.floor((gridH - (rows - 1)) / rows)
  // 1.0.21：电视视图——大号 4 场、中号 2 场、小号 1 场。场数上限由高度预算定（主版 v1.1.97 同款）：
  // 中号内容高 dh−72＝86pt（dh 158），每行（比赛行 16＋间距 2＋胶囊行 21）约 39pt，4 行塞唔落，2 行先啱；
  // 大号内容高 dh−106＝276pt，够放 4 行连 2 行胶囊；小号内容高约 86pt，1 行有余。
  // 行高内容本身（TvRow／TvView 唔再撑固定 rowH、唔再放上下 Spacer）；电视视图外层上下内边距 8／8。
  const tvMax = small ? 1 : medium ? 2 : 4
  const tvMatches = showTv ? pickTvMatches(data?.matches ?? [], tvMax) : []

  return (
    <VStack spacing={medium ? 4 : 6} padding={{ top: showTv ? (medium ? 4 : 8) : (medium ? 4 : 16), bottom: showTv ? (medium ? 4 : 8) : (medium ? 4 : 12), horizontal: 8 }} frame={Widget.displaySize} widgetBackground={CARD_BG}>
      <HStack alignment="center" spacing={8} frame={{ height: 30 }} padding={{ horizontal: 6 }}>
          {/* 标题点开 FotMob App（用户 2026-10-28 定）：裸 Link 用 fotmob:// scheme 直开 App 首页（AASA 冇登记根路径 /，https 首页链接只会开网页；App Info.plist 有 fotmob scheme）；冇装 FotMob App 嘅机点标题会冇反应；唔好包 Button（Button 包 Link 会令桌面成格变蓝，D/E/F 实测）。旧 shortcutIndex=0 快捷指令入口随之取消，刷新继续行底部行。
              标题行右侧只留日期（F 标 2026-10-28 起删，用户定）。左侧：显示中比赛全部同一联赛就用该联赛 logo＋名，否则 FotMob 图标＋Matchday（v1.1.63 起，取代系统 soccerball）。 */}
          <Link url="fotmob://">
            <HStack alignment="center" spacing={8}>
              {titleLeague != null ? (
                titleLogo != null ? (
                  <Image imageUrl={titleLogo} resizable={true} frame={{ width: 26, height: 26 }} />
                ) : (
                  <Image systemName="trophy.fill" font="title3" />
                )
              ) : (
                <Image imageUrl={titleIcon} resizable={true} frame={{ width: 26, height: 26 }} />
              )}
              <Text font={small ? "title3" : "title2"} fontWeight="bold" foregroundStyle={transparentMode ? transparentTextColor : LABEL_COLOR} lineLimit={1} minScaleFactor={0.8}>
                {titleLeague ?? "Matchday"}
              </Text>
            </HStack>
          </Link>
          <Spacer />
          {!small && data?.date ? (
            // 1.0.13：右上角日期变切换掣（Button 只包日期文字，同左边标题 Link 由 Spacer 隔开，唔会互相食点击区）；
            // 之前视图时改显示本地化「之前八场」做状态提示，点一下即返现时视图。
            <Button buttonStyle="plain" intent={TogglePrevFootballStandaloneIntent()}>
              <Text font="subheadline" foregroundStyle={dateColor} lineLimit={1}>
                {showPrev ? W.prevLabel : widgetDateTitle(data.date, wloc)}
              </Text>
            </Button>
          ) : null}
        </HStack>

      {!isList ? <Spacer /> : null}

      {showTv ? (
        <TvView matches={tvMatches} />
      ) : hero != null ? (
        <HeroMatch m={hero} />
      ) : n > 1 ? (
        <VStack
          spacing={0}
          frame={isList ? { maxHeight: "infinity" } : { height: gridH }}
          widgetBackground={
            isList
              ? {
                  style: GRID_BG,
                  shape: { type: "rect", cornerRadius: 16 },
                }
              : {
                  // v1.1.46：网格容器底色恢复 GRID_BG（v1.1.41 改过 CARD_BG 令卡隐形，而家跟 FotMob 灰卡＋分割线一齐恢复）
                  style: GRID_BG,
                  shape: { type: "rect", cornerRadius: 16 },
                }
          }
        >
          {isList ? (
            <ListCard matches={shown} />
          ) : (
            <GridCard matches={shown} rowH={rowH} />
          )}
        </VStack>
      ) : (
        <Text font="subheadline" foregroundStyle={transparentMode ? transparentTextColor : GRAY_COLOR}>
          {data?.lastError != null ? W.loadFail : showPrev ? W.prevNoMatch : W.noMatch}
        </Text>
      )}

      {!isList ? <Spacer /> : null}

      {/* 1.0.21：底部行拆做 TV 掣＋刷新掣——左 TV 图标 Button（点一下切电视视图，绿＝开紧），
          右刷新（箭头＋时间）置中；两掣由 Spacer 隔开，唔会互相食点击区；右边留返 26pt 空位，令刷新内容保持置中 */}
      <HStack alignment="center" spacing={4} frame={{ height: medium ? 18 : 24 }}>
        <Button buttonStyle="plain" intent={ToggleTvFootballStandaloneIntent()}>
          <Image systemName="tv" font="caption" foregroundStyle={showTv ? liveGreen : transparentMode ? transparentTextColor : GRAY_COLOR} frame={{ width: 26 }} />
        </Button>
        <Spacer />
        <Button buttonStyle="plain" intent={RefreshFootballStandaloneIntent()}>
          <HStack alignment="center" spacing={4}>
            <Image systemName="arrow.clockwise" font="caption" foregroundStyle={transparentMode ? transparentTextColor : GRAY_COLOR} />
            <Text font="caption" foregroundStyle={transparentMode ? transparentTextColor : GRAY_COLOR}>
              {refreshingFresh ? "…" : data != null && data.fetchedAt > 0 ? widgetClock(data.fetchedAt, wloc) : "--"}
            </Text>
          </HStack>
        </Button>
        <Spacer />
        <VStack frame={{ width: 26 }} />
      </HStack>
    </VStack>
  )
}

/** 自动刷新：刷新节奏按缓存中今日比赛状态分档（v1.1.23，档位表见 const.ts refreshTier）：
 *  进行中 2 分钟过期/3 分钟重画；就开波 5/5；一般 15/15（旧现状）；无波/全完场 60/60。
 *  过期先即场抓（总等待上限 10 秒），失败/超时就用缓存顶住，唔会白屏；
 *  live／pre-match 档过期用快刷新（净抓今日）；idle／normal 档、缓存唔系今日或无缓存用全刷新；
 *  手动刷新进行中（intent 时间戳新鲜）就跳过，等 intent 嗰次，唔重复抓。
 *  成个 run 包入 try/catch，异常都 present。reloadPolicy 只系请求，iOS 有每日预算可能会拉长。
 *  点标题栏 ↻ 图标经 RefreshFootballStandaloneIntent 即时刷新（v1.1.32 起，唔再成卡刷新）。 */
async function run() {
  showPrev = Storage.get<boolean>(prevViewKey) ?? false
  showTv = Storage.get<boolean>(tvViewKey) ?? false
  // 1.0.21：电视视图同之前八场互斥——旧状态两边都开就以电视为准（intent 写入时已互斥，呢度系保险）
  if (showTv) showPrev = false
  broadcastTable = parseBroadcastTable(Storage.get<unknown>(broadcastRemoteKey) ?? null)
  transparentMode = Storage.get<boolean>(transparentKey) ?? false
  transparentLightInverse = Storage.get<boolean>(transparentLightInverseKey) ?? false
  transparentDarkInverse = Storage.get<boolean>(transparentDarkInverseKey) ?? false
  transparentTextColor = { light: transparentLightInverse ? "#FFFFFF" : "#000000", dark: transparentDarkInverse ? "#000000" : "#FFFFFF" }
  clockIcon = { light: transparentMode && transparentLightInverse ? CLOCK_ICON_WHITE : CLOCK_ICON, dark: transparentMode && transparentDarkInverse ? CLOCK_ICON_BLACK : CLOCK_ICON }
  liveGreen = { light: transparentMode && transparentLightInverse ? LIVE_GREEN.dark : LIVE_GREEN.light, dark: transparentMode && transparentDarkInverse ? LIVE_GREEN.light : LIVE_GREEN.dark }
  dateColor = { light: transparentMode && transparentLightInverse ? DATE_COLOR.dark : DATE_COLOR.light, dark: transparentMode && transparentDarkInverse ? DATE_COLOR.light : DATE_COLOR.dark }
  titleIcon = { light: transparentMode && transparentLightInverse ? TITLE_ICON.dark : TITLE_ICON.light, dark: transparentMode && transparentDarkInverse ? TITLE_ICON.light : TITLE_ICON.dark }
  let presented = false
  const doPresent = (d: FootballData | null, reloadMin: number) => {
    presented = true
    Widget.present(
      <WidgetView data={d} />,
      { policy: "after", date: new Date(Date.now() + reloadMin * 60 * 1000) }
    )
  }
  try {
    const cached = Storage.get<FootballData>(footballKey) ?? null
    let data = cached
    const tier = refreshTier(cached)
    const ageMs =
      cached != null && cached.fetchedAt > 0 ? Date.now() - cached.fetchedAt : null
    const stale = cached == null || ageMs == null || ageMs >= tier.staleMs
    // 手动刷新进行中（intent 啱啱写咗时间戳 + reloadAll）：唔好自己再抓，免得同 intent 嗰次撞埋一齐
    const manualRefreshing = isRefreshingFresh(Storage.get<number>(refreshingAtKey) ?? null)
    // 快刷新条件：过期＋缓存系今日＋live／pre-match 档；其余（无缓存、缓存唔系今日、idle／normal 档）一律全刷新
    const useFast = stale && !manualRefreshing && cached != null && cached.date === localYMD(new Date()) &&
      (tier.name === "live" || tier.name === "pre-match")
    console.log(
      `[football] run @ ${new Date().toISOString()} 档位=${tier.name}（过期线 ${(tier.staleMs / 60000).toFixed(0)} 分钟）` +
        ` fetchedAt=${cached != null && cached.fetchedAt > 0 ? new Date(cached.fetchedAt).toISOString() : "无"}` +
        ` 缓存年龄=${ageMs != null ? `${(ageMs / 60000).toFixed(1)} 分钟` : "无"} 要刷新=${stale}` +
        ` 模式=${manualRefreshing ? "手动进行中（跳过）" : useFast ? "快刷新" : "全刷新"}`
    )
    if (stale && !manualRefreshing) {
      try {
        const r = await Promise.race([
          useFast ? refreshFootballFast() : refreshFootball(),
          new Promise<{ ok: boolean }>((resolve) =>
            setTimeout(() => resolve({ ok: false }), 10000),
          ),
        ])
        if (r.ok) data = Storage.get<FootballData>(footballKey) ?? cached
        console.log(`[football] 刷新${r.ok ? "成功" : "未成功（失败/超时，用缓存）"}`)
      } catch (e) {
        console.error("football auto refresh failed", e)
      }
    } else if (!manualRefreshing) {
      // 1.0.21：足球数据未过期——照样按 6 小时节奏更新直播表（fire-and-forget，唔等佢）
      void refreshBroadcastIfStale()
    }
    // 1.0.21：直播表可能啱啱经 refreshFootball／refreshFootballFast 顺手更新咗（fire-and-forget）：重读一次，present 用最新
    broadcastTable = parseBroadcastTable(Storage.get<unknown>(broadcastRemoteKey) ?? null)
    // 用刷新后嘅数据重新判档，先决定今轮 reload 间隔（例如啱啱开波变 LIVE → 3 分钟）
    const finalTier = refreshTier(data)
    console.log(
      `[football] present 档位=${finalTier.name}，请求 ${finalTier.reloadMin} 分钟后重画`
    )
    doPresent(data, finalTier.reloadMin)
  } catch (e) {
    console.error("football run error", e)
    if (!presented) {
      try {
        doPresent(Storage.get<FootballData>(footballKey) ?? null, 15)
      } catch (e2) {
        console.error("football fallback present failed", e2)
      }
    }
  }
}

run()
