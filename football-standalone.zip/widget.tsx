import { Button, HStack, Image, Link, Rectangle, Spacer, Text, VStack, Widget, ZStack } from "scripting"
import type { DynamicShapeStyle } from "scripting"
import { RefreshFootballStandaloneIntent } from "./app_intents"
import { displayLocale, halftimeLabel, refreshFootball } from "./football"
import {
  FootballData,
  DONE,
  LIVE,
  Match,
  OFF,
  clockZh,
  dateTitle,
  footballKey,
  fotmobUrl,
  isToday,
  koParts,
  refreshTier,
} from "./const"

// v1.1.30 FotMob 风格配色（浅色 / 深色；颜色一律打 DynamicShapeStyle 类型，唔好 widen 成 string 致 TS2322）
const CARD_BG: DynamicShapeStyle = { light: "#FFFFFF", dark: "#1C1C1E" }
const GRID_BG: DynamicShapeStyle = { light: "#F8F8F8", dark: "#1E1E1F" }
const DIVIDER_COLOR: DynamicShapeStyle = { light: "#E0E0E4", dark: "#3A3A3C" }
// v1.1.46：网格分割线色——FotMob 实测：浅色白线（卡 #F8F8F8 上 3px 白线）、深色 #1A1A1A（卡 #1E1E1F 上偏暗 3px 线）；ListCard 沿用 DIVIDER_COLOR，唔郁
const GRID_DIVIDER_COLOR: DynamicShapeStyle = { light: "#FFFFFF", dark: "#1A1A1A" }
// v1.1.46：标题日期色——FotMob 实测：浅色 #333333、深色纯白；同 GRAY_COLOR（#8E8E93）唔同，日期唔再用灰
const DATE_COLOR: DynamicShapeStyle = { light: "#333333", dark: "#FFFFFF" }
const LABEL_COLOR: DynamicShapeStyle = { light: "#000000", dark: "#FFFFFF" }
const TIME_COLOR: DynamicShapeStyle = { light: "#717171", dark: "#9F9F9F" }
const GRAY_COLOR: DynamicShapeStyle = { light: "#8E8E93", dark: "#8E8E93" }
// v1.1.60：进行中分钟绿色（FotMob 样式；浅色深绿、深色亮绿）
const LIVE_GREEN: DynamicShapeStyle = { light: "#009E4D", dark: "#32D158" }
// v1.1.61：FotMob 官方完场钟仔（由 FotMob IPA WidgetExtension Assets.car 抽出嘅 ic_fulltime，托管喺 VPS）
const CLOCK_ICON = "https://yt.adi-ronnie.top/api/fotmob-clock.png"
// v1.1.63：标题图标改用 FotMob 官方 App 图标（由 FotMob IPA 内附文件 AppIcon60x60@2x.png 经 CgBI 还原，托管喺 VPS）
const TITLE_ICON = "https://yt.adi-ronnie.top/api/fotmob-icon.png"

/** 预览人数（v1.1.25，用户规格）：桌面实例参数填 preview:N（如 preview:7）先会用现有比赛
 *  循环复制凑够 N 场检查布局；无参数／格式唔啱／N<=0 一律用真实数据，代码里唔留常量 */
function previewCount(): number {
  try {
    const param = Widget.parameter
    if (typeof param !== "string") return 0
    const m = param.match(/preview:(\d+)/)
    if (m == null) return 0
    const n = parseInt(m[1], 10)
    return Number.isFinite(n) && n > 0 ? n : 0
  } catch {
    return 0
  }
}

function previewExpand(list: Match[]): Match[] {
  const n = previewCount()
  if (n <= 0 || list.length === 0) return list
  return Array.from({ length: n }, (_, i) => list[i % list.length])
}

/** 左右两边：队徽 + 三字缩写 */
function TeamCol({ team, size, abbrFont = "headline" }: { team: Match["home"]; size: number; abbrFont?: "headline" | "subheadline" }) {
  return (
    <VStack spacing={4} alignment="center">
      <Image imageUrl={team.logo} resizable={true} frame={{ width: size, height: size }} />
      <Text font={abbrFont} fontWeight="bold" lineLimit={1}>
        {team.code ?? ""}
      </Text>
    </VStack>
  )
}

/** 中间：进行中（比分+分钟）/ 完场（比分）/ 日期 + 开球时间 */
function CenterCol({ m }: { m: Match }) {
  const ko = koParts(m.date)
  if (LIVE.has(m.status)) {
    return (
      <VStack spacing={2} alignment="center" frame={{ width: 68 }}>
        <Text font="headline" fontWeight="bold" lineLimit={1}>
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" fontWeight="medium" foregroundStyle={TIME_COLOR} lineLimit={1}>
          {m.elapsed != null ? `${m.elapsed}'` : "进行中"}
        </Text>
      </VStack>
    )
  }
  if (DONE.has(m.status)) {
    return (
      <VStack spacing={2} alignment="center" frame={{ width: 68 }}>
        <Text font="headline" fontWeight="bold" lineLimit={1}>
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1}>
          完场
        </Text>
      </VStack>
    )
  }
  if (OFF.has(m.status)) {
    return (
      <Text font="subheadline" foregroundStyle="secondaryLabel" lineLimit={1}>
        延期
      </Text>
    )
  }
  return (
    <VStack spacing={2} alignment="center" frame={{ width: 68 }}>
      <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1}>
        {isToday(m.date) ? "今天" : ko.weekday}
      </Text>
      <Text font="caption" fontWeight="medium" foregroundStyle={TIME_COLOR} lineLimit={1}>
        {ko.time12}
      </Text>
    </VStack>
  )
}

/** 1 场：照 FotMob 单场 widget — 冇灰卡，中间联赛 logo＋「日期 时间」 */
function HeroCenter({ m }: { m: Match }) {
  const ko = koParts(m.date)
  const icon = Widget.family === "systemLarge" ? 30 : 24
  if (LIVE.has(m.status)) {
    return (
      <VStack spacing={2} alignment="center">
        <Text font="title3" fontWeight="bold" lineLimit={1}>
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" fontWeight="medium" foregroundStyle={TIME_COLOR} lineLimit={1}>
          {m.elapsed != null ? `${m.elapsed}'` : "进行中"}
        </Text>
      </VStack>
    )
  }
  if (DONE.has(m.status)) {
    return (
      <VStack spacing={2} alignment="center">
        <Text font="title3" fontWeight="bold" lineLimit={1}>
          {m.gh} - {m.ga}
        </Text>
        <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1}>
          完场
        </Text>
      </VStack>
    )
  }
  if (OFF.has(m.status)) {
    return (
      <Text font="subheadline" foregroundStyle="secondaryLabel" lineLimit={1}>
        延期
      </Text>
    )
  }
  return (
    <VStack spacing={6} alignment="center">
      {m.leagueLogo ? (
        <Image imageUrl={m.leagueLogo} resizable={true} frame={{ width: icon, height: icon }} />
      ) : (
        <Image systemName="trophy.fill" font="body" foregroundStyle="secondaryLabel" />
      )}
      <VStack spacing={2} alignment="center">
        <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1}>
          {isToday(m.date) ? "今天" : ko.weekday}
        </Text>
        <Text font="caption" fontWeight="medium" foregroundStyle={TIME_COLOR} lineLimit={1}>
          {ko.time12}
        </Text>
      </VStack>
    </VStack>
  )
}

/** 1 场：大版式，尺寸按 widget family 自适应 */
function HeroMatch({ m }: { m: Match }) {
  const small = Widget.family === "systemSmall"
  const medium = Widget.family === "systemMedium"
  const logo = small ? 36 : medium ? 40 : 62
  const padV = small ? 8 : medium ? 12 : 20
  return (
    <Link url={fotmobUrl(m)}>
      <HStack alignment="center" spacing={8} padding={{ horizontal: 24, vertical: padV }}>
        <TeamCol team={m.home} size={logo} />
        <VStack alignment="center" frame={{ maxWidth: "infinity" }}>
          <HeroCenter m={m} />
        </VStack>
        <TeamCol team={m.away} size={logo} />
      </HStack>
    </Link>
  )
}

/** 2–4 场：单列，行之间分隔线（large 先用，medium 太矮摆唔落）
 *  v1.1.25 高度修复（用户规格）：旧版每行约 74pt，4 场连标题/更新/padding 溢出约 28pt，
 *  标题俾挤出顶部。而家行高按可用高度计：（总高 − 上下 padding 24 − 标题 28 − 更新 14
 *  − 两个 spacing 12 − 分隔线总高度）÷ 场数，夹喺 56–78pt；displaySize.height 读唔到就用 382。
 *  行高取代旧上下 padding 8；卡内上下 Spacer 令夹到上限嘅行（2–3 场）垂直置中、卡撑满。
 *  4 场时队徽 30 + 缩写 subheadline；2–3 场维持 32 + headline。 */
function ListCard({ matches }: { matches: Match[] }) {
  const n = matches.length
  const dh = Widget.displaySize != null ? Widget.displaySize.height : 0
  const H = typeof dh === "number" && dh > 0 ? dh : 382
  const DIVIDER_H = 1
  const rowH = Math.max(56, Math.min(78, (H - 24 - 28 - 14 - 12 - DIVIDER_H * (n - 1)) / n))
  const four = n === 4
  const crest = four ? 30 : 32
  const abbrFont = four ? "subheadline" : "headline"
  return (
    <VStack spacing={0} frame={{ maxHeight: "infinity" }}>
      <Spacer />
      {matches.map((m, i) => (
        <VStack key={`${m.id}-${i}`} spacing={0}>
          {i > 0 && <Rectangle fill={DIVIDER_COLOR} frame={{ height: 0.5 }} />}
          <Link url={fotmobUrl(m)}>
            <HStack alignment="center" spacing={8} padding={{ horizontal: 24 }} frame={{ height: rowH }}>
              <TeamCol team={m.home} size={crest} abbrFont={abbrFont} />
              <Spacer />
              <CenterCol m={m} />
              <Spacer />
              <TeamCol team={m.away} size={crest} abbrFont={abbrFont} />
            </HStack>
          </Link>
        </VStack>
      ))}
      <Spacer />
    </VStack>
  )
}

/** 网格格仔中央（v1.1.61 FotMob 样式：比分夹住中间状态——进行中分钟绿色、半场半场字、点球途中按 FotMob 显示法定时间（90'）、无分钟回退开波时间；完场用 FotMob 官方钟仔图标夹中间；点球完场下行加 (ph - pa)；未开波唔变。字号比例跟 FotMob：比分大号 headline／中号 caption，中间字大号 subheadline／中号 caption2） */
function GridCenter({ m, medium }: { m: Match; medium: boolean }) {
  const scoreFont = medium ? "caption" : "headline"
  const midFont = medium ? "caption2" : "caption"  // v1.1.62：中间时间再细一级（大号 subheadline 15→caption 12；中号 caption2 11 已系最细，唔变）
  if (LIVE.has(m.status)) {
    const ko = koParts(m.date)
    const mid = m.ht ? halftimeLabel(displayLocale()) : m.elapsed != null ? `${m.elapsed}'` : ko.time12
    const midColor = m.ht ? TIME_COLOR : m.elapsed != null ? LIVE_GREEN : TIME_COLOR
    return (
      <HStack spacing={4} alignment="center">
        <Text font={scoreFont} fontWeight="bold" foregroundStyle={LABEL_COLOR} lineLimit={1} minScaleFactor={0.7}>
          {m.gh}
        </Text>
        <Text font={midFont} fontWeight="bold" foregroundStyle={midColor} lineLimit={1} minScaleFactor={0.7}>
          {mid}
        </Text>
        <Text font={scoreFont} fontWeight="bold" foregroundStyle={LABEL_COLOR} lineLimit={1} minScaleFactor={0.7}>
          {m.ga}
        </Text>
      </HStack>
    )
  }
  if (DONE.has(m.status)) {
    // v1.1.63：完场比分同钟仔间距由 4 拉远到 8
    const clockRow = (
      <HStack spacing={8} alignment="center">
        <Text font={scoreFont} fontWeight="bold" foregroundStyle={LABEL_COLOR} lineLimit={1} minScaleFactor={0.7}>
          {m.gh}
        </Text>
        <Image imageUrl={CLOCK_ICON} resizable={true} frame={{ width: medium ? 14 : 16, height: medium ? 14 : 16 }} />
        <Text font={scoreFont} fontWeight="bold" foregroundStyle={LABEL_COLOR} lineLimit={1} minScaleFactor={0.7}>
          {m.ga}
        </Text>
      </HStack>
    )
    if (m.status === "PEN") {
      return (
        <VStack spacing={2} alignment="center">
          {clockRow}
          {m.ph != null && m.pa != null && (
            <Text font="caption2" foregroundStyle={LABEL_COLOR} lineLimit={1}>
              ({m.ph} - {m.pa})
            </Text>
          )}
        </VStack>
      )
    }
    return clockRow
  }
  if (OFF.has(m.status)) {
    return (
      <Text font="subheadline" foregroundStyle="secondaryLabel" lineLimit={1}>
        延期
      </Text>
    )
  }
  const ko = koParts(m.date)
  if (isToday(m.date)) {
    return (
      <Text
        font="caption2"
        fontWeight="semibold"
        foregroundStyle={TIME_COLOR}
        lineLimit={1}
        minScaleFactor={0.75}
        multilineTextAlignment="center"
      >
        {ko.time12}
      </Text>
    )
  }
  return (
    <VStack spacing={2} alignment="center">
      <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1}>
        {ko.weekday}
      </Text>
      <Text
        font="caption2"
        fontWeight="semibold"
        foregroundStyle={TIME_COLOR}
        lineLimit={1}
        minScaleFactor={0.75}
        multilineTextAlignment="center"
      >
        {ko.time12}
      </Text>
    </VStack>
  )
}

/** 5–8 场（large）／2–4 场（medium）：两列网格，无分隔线
 *  v1.1.36：列宽 colW 由 displaySize 减 GRID_PAD 计出（固定值，唔用 maxWidth）；
 *  v1.1.42：每格改 ZStack 三层——时间文字置中，左队徽中心在列宽 22%、右队徽在 82%
 *  （offset = colW × −0.28／+0.32；队徽大 24／中 20）；奇数场最后一行右列用空 VStack 占位；
 *  v1.1.43：时间改固定 80pt 槽置中（GridCenter 原样，两边 Spacer 夹住），队徽 offset 改
 *  ±(48 + logo/2)（40 槽半 + 8 间距 + 队徽半），左右到时间嘅距离恒等，唔再用列宽百分比；
 *  v1.1.44：时间槽改 64pt，队徽大 26／中 22，offset = ±(32 + 6 + logo/2)（大 ±51、中 ±49），
 *  槽到队徽间隙恒为 6pt。注意：64 槽唔用两边 Spacer 夹住——(64−53)/2 = 5.5pt 细过 Spacer
 *  约 8pt 下限，会令“上午 10:00”缩到 0.91；改用 64 阔 VStack 置中包住 GridCenter（无 Spacer），
 *  CENTER_SLOT 只做 offset 公式嘅参考值，文字全大细、唔缩放、唔截断 */
function GridCell({ m, colW, rowH }: { m: Match; colW: number; rowH: number }) {
  const medium = Widget.family === "systemMedium"
  const logo = medium ? 22 : 26
  const CENTER_SLOT = 64
  const off = CENTER_SLOT / 2 + 6 + logo / 2
  return (
    <Link url={fotmobUrl(m)}>
      <ZStack alignment="center" frame={{ width: colW, height: rowH }}>
        <VStack frame={{ width: CENTER_SLOT }} alignment="center">
          <GridCenter m={m} medium={medium} />
        </VStack>
        <Image imageUrl={m.home.logo} resizable={true} frame={{ width: logo, height: logo }} offset={{ x: -off, y: 0 }} />
        <Image imageUrl={m.away.logo} resizable={true} frame={{ width: logo, height: logo }} offset={{ x: off, y: 0 }} />
      </ZStack>
    </Link>
  )
}

/* GridCard 列宽：同 WidgetView 外层水平内边距 8 一致 */
const GRID_PAD = 8

function GridCard({ matches, rowH }: { matches: Match[]; rowH: number }) {
  const pairs: Match[][] = []
  for (let i = 0; i < matches.length; i += 2) pairs.push(matches.slice(i, i + 2))
  const dw = Widget.displaySize != null && typeof Widget.displaySize.width === "number" && Widget.displaySize.width > 0
    ? Widget.displaySize.width
    : Widget.family === "systemMedium" ? 342 : 366
  const gridW = dw - GRID_PAD * 2
  // v1.1.46：列宽预留改 0.5→1（竖分割线而家系 1pt，FotMob 实测 3px）；算出嚟 colW 大／中都系 174／162，同之前一样
  const colW = Math.floor((gridW - 1) / 2)
  return (
    <VStack spacing={0}>
      {pairs.map((p, i) => (
        <VStack key={i} spacing={0}>
          {/* v1.1.46：恢复横分割线（FotMob 式 1pt 线；v1.1.41 按用户要求删过，而家按最新指示恢复） */}
          {i > 0 && <Rectangle fill={GRID_DIVIDER_COLOR} frame={{ height: 1 }} />}
          <HStack spacing={0} alignment="center">
            <VStack spacing={0} frame={{ width: colW }}>
              <GridCell m={p[0]} colW={colW} rowH={rowH} />
            </VStack>
            {p[1] != null ? (
              <HStack spacing={0} alignment="center">
                {/* v1.1.46：恢复竖分割线（1pt；只系格仔之间，唔包住任何 Link，唔会触发蓝底） */}
                <Rectangle fill={GRID_DIVIDER_COLOR} frame={{ width: 1 }} />
                <VStack spacing={0} frame={{ width: colW }}>
                  <GridCell m={p[1]} colW={colW} rowH={rowH} />
                </VStack>
              </HStack>
            ) : (
              <VStack frame={{ width: colW }} />
            )}
          </HStack>
        </VStack>
      ))}
    </VStack>
  )
}

function WidgetView({ data }: { data: FootballData | null }) {
  const all = previewExpand(data?.matches ?? [])
  const max = Widget.family === "systemSmall" ? 1 : Widget.family === "systemMedium" ? 4 : 8
  const shown = all.slice(0, max)
  const n = shown.length

  const hero = n === 1 ? shown[0] : null
  // v1.1.45：标题联赛——显示中比赛全部同一联赛就用该联赛名＋logo，否则 Matchday
  const firstLeague = shown.length > 0 ? shown[0].league : null
  const uniformLeague = shown.length > 0 && shown.every((m) => m.league === firstLeague)
  const titleLeague = uniformLeague ? firstLeague : null
  const titleLogo = uniformLeague ? shown.find((m) => m.leagueLogo != null)?.leagueLogo ?? null : null
  // v1.1.25：large 2–4 场（ListCard）专用——去卡外侧两个 Spacer、卡撑满，标题/更新行唔俾挤出
  const isList = Widget.family === "systemLarge" && n > 1 && n <= 4
  // v1.1.30：small 沿用现有布局（标题 title3、无日期、F 标 28），其余尺寸用 title2、日期、F 标 24
  const small = Widget.family === "systemSmall"
  const medium = Widget.family === "systemMedium"  // v1.1.58：中尺寸专用预算开关
  // v1.1.37：网格高度按实际尺寸计——dh 读唔到时按大 382／中 158 fallback；
  // gridH = dh − 16（顶部内边距）− 12（底部内边距）− 30（标题）− 24（底部刷新行）− 12（两处 spacing）− 12（上下留白）
  // v1.1.43 修正：spec 原写 −4 会令上下 Spacer 得 −8pt（内容超出 widget 8pt、页脚被裁）；
  // 改 −12 令 Spacer 归零、刚好贴合，网格到底部刷新行距离由 16pt 缩到 12pt（净返两处 6pt 间距）
  // v1.1.44：顶部内边距 12→16，内边距项同步 24→28（网格整体下移 4pt、网格高度缩 4pt，
  // 底部刷新行位置不变）；spec 原文 horizontal: 14 唔跟——外层水平而家系 8（同 GRID_PAD 配对），
  // 照写 14 会令行宽超出容器 12pt；spec 嘅 −4 同样唔跟（会再次溢出 8pt），继续用 −12
  // v1.1.45：底部刷新行 16→24，公式同步减多 8（dh−106）；spec 原写 dh−98（16＋12＋30＋24＋12＋4）
  // 只计两处 spacing，实际有四处 6pt 间距，差 8pt 会再次溢出页脚，所以留白项继续用 −12
  const dh = Widget.displaySize != null && typeof Widget.displaySize.height === "number" && Widget.displaySize.height > 0
    ? Widget.displaySize.height
    : Widget.family === "systemMedium" ? 158 : 382
  // v1.1.58：中尺寸解压扁——中号两行格实际约 30pt（caption2 行高＋2＋caption 行高），旧行高 25 会溢出挤压；
  // v1.1.59：用户定维持 4 场、尽量利用上下空隙——中号预算再压：顶距 4＋底距 4＋标题 30＋底部行 18＋四处间距 16＝72，gridH＝dh−72＝86，行高 (86−1)/2＝42；大／小号预算唔变
  const gridH = medium ? dh - 72 : dh - 16 - 12 - 30 - 24 - 12 - 12
  const rows = Math.max(1, Math.ceil(n / 2))
  // v1.1.46：行高预留改做 (rows - 1) × 1pt（横分割线而家系 1pt）；算出嚟大 68／大 9 系 54／中 25，同之前一模一样
  const rowH = Math.floor((gridH - (rows - 1)) / rows)

  return (
    <VStack spacing={medium ? 4 : 6} padding={{ top: medium ? 4 : 16, bottom: medium ? 4 : 12, horizontal: 8 }} frame={Widget.displaySize} widgetBackground={CARD_BG}>
      <HStack alignment="center" spacing={8} frame={{ height: 30 }} padding={{ horizontal: 6 }}>
          {/* 标题点开 FotMob App（用户 2026-10-28 定）：裸 Link 用 fotmob:// scheme 直开 App 首页（AASA 冇登记根路径 /，https 首页链接只会开网页；App Info.plist 有 fotmob scheme）；冇装 FotMob App 嘅机点标题会冇反应；唔好包 Button（Button 包 Link 会令桌面成格变蓝，D/E/F 实测）。旧 shortcutIndex=0 快捷指令入口随之取消，刷新继续行底部行。
              标题行右侧只留日期（F 标 2026-10-28 起删，用户定）。左侧：显示中比赛全部同一联赛就用该联赛 logo＋名，否则 FotMob 图标＋Matchday（v1.1.63 起，取代系统 soccerball）。 */}
          <Link url="fotmob://">
            <HStack alignment="center" spacing={8}>
              {titleLeague != null ? (
                titleLogo != null ? (
                  <Image imageUrl={titleLogo} resizable={true} frame={{ width: 26, height: 26 }} />
                ) : (
                  <Image systemName="trophy.fill" font="title3" />
                )
              ) : (
                <Image imageUrl={TITLE_ICON} resizable={true} frame={{ width: 26, height: 26 }} />
              )}
              <Text font={small ? "title3" : "title2"} fontWeight="bold" foregroundStyle={LABEL_COLOR} lineLimit={1} minScaleFactor={0.8}>
                {titleLeague ?? "Matchday"}
              </Text>
            </HStack>
          </Link>
          <Spacer />
          {!small && data?.date ? (
            <Text font="subheadline" foregroundStyle={DATE_COLOR} lineLimit={1}>
              {dateTitle(data.date)}
            </Text>
          ) : null}
        </HStack>

      {!isList ? <Spacer /> : null}

      {hero != null ? (
        <HeroMatch m={hero} />
      ) : n > 1 ? (
        <VStack
          spacing={0}
          frame={isList ? { maxHeight: "infinity" } : { height: gridH }}
          widgetBackground={
            isList
              ? {
                  style: GRID_BG,
                  shape: { type: "rect", cornerRadius: 16 },
                }
              : {
                  // v1.1.46：网格容器底色恢复 GRID_BG（v1.1.41 改过 CARD_BG 令卡隐形，而家跟 FotMob 灰卡＋分割线一齐恢复）
                  style: GRID_BG,
                  shape: { type: "rect", cornerRadius: 16 },
                }
          }
        >
          {isList ? (
            <ListCard matches={shown} />
          ) : (
            <GridCard matches={shown} rowH={rowH} />
          )}
        </VStack>
      ) : (
        <Text font="subheadline" foregroundStyle={GRAY_COLOR}>
          {data?.lastError != null ? "赛程加载失败" : "今日无比赛"}
        </Text>
      )}

      {!isList ? <Spacer /> : null}

      {/* v1.1.45：刷新入口搬到底部行——Button 只包底部行（无 Link，唔会触发蓝底），全卡唯一刷新入口 */}
      <Button buttonStyle="plain" intent={RefreshFootballStandaloneIntent()}>
        <HStack alignment="center" spacing={4} frame={{ height: medium ? 18 : 24 }}>
          <Spacer />
          <Image systemName="arrow.clockwise" font="caption" foregroundStyle={GRAY_COLOR} />
          <Text font="caption" foregroundStyle={GRAY_COLOR}>
            {data != null && data.fetchedAt > 0 ? clockZh(data.fetchedAt) : "--"}
          </Text>
          <Spacer />
        </HStack>
      </Button>
    </VStack>
  )
}

/** 自动刷新：刷新节奏按缓存中今日比赛状态分档（v1.1.23，档位表见 const.ts refreshTier）：
 *  进行中 2 分钟过期/3 分钟重画；就开波 5/5；一般 15/15（旧现状）；无波/全完场 60/60。
 *  过期先即场抓（总等待上限 10 秒），失败/超时就用缓存顶住，唔会白屏；
 *  成个 run 包入 try/catch，异常都 present。reloadPolicy 只系请求，iOS 有每日预算可能会拉长。
 *  点标题栏 ↻ 图标经 RefreshFootballStandaloneIntent 即时刷新（v1.1.32 起，唔再成卡刷新）。 */
async function run() {
  let presented = false
  const doPresent = (d: FootballData | null, reloadMin: number) => {
    presented = true
    Widget.present(
      <WidgetView data={d} />,
      { policy: "after", date: new Date(Date.now() + reloadMin * 60 * 1000) }
    )
  }
  try {
    const cached = Storage.get<FootballData>(footballKey) ?? null
    let data = cached
    const tier = refreshTier(cached)
    const ageMs =
      cached != null && cached.fetchedAt > 0 ? Date.now() - cached.fetchedAt : null
    const stale = cached == null || ageMs == null || ageMs >= tier.staleMs
    console.log(
      `[football] run @ ${new Date().toISOString()} 档位=${tier.name}（过期线 ${(tier.staleMs / 60000).toFixed(0)} 分钟）` +
        ` fetchedAt=${cached != null && cached.fetchedAt > 0 ? new Date(cached.fetchedAt).toISOString() : "无"}` +
        ` 缓存年龄=${ageMs != null ? `${(ageMs / 60000).toFixed(1)} 分钟` : "无"} 要刷新=${stale}`
    )
    if (stale) {
      try {
        const r = await Promise.race([
          refreshFootball(),
          new Promise<{ ok: boolean }>((resolve) =>
            setTimeout(() => resolve({ ok: false }), 10000),
          ),
        ])
        if (r.ok) data = Storage.get<FootballData>(footballKey) ?? cached
        console.log(`[football] 刷新${r.ok ? "成功" : "未成功（失败/超时，用缓存）"}`)
      } catch (e) {
        console.error("football auto refresh failed", e)
      }
    }
    // 用刷新后嘅数据重新判档，先决定今轮 reload 间隔（例如啱啱开波变 LIVE → 3 分钟）
    const finalTier = refreshTier(data)
    console.log(
      `[football] present 档位=${finalTier.name}，请求 ${finalTier.reloadMin} 分钟后重画`
    )
    doPresent(data, finalTier.reloadMin)
  } catch (e) {
    console.error("football run error", e)
    if (!presented) {
      try {
        doPresent(Storage.get<FootballData>(footballKey) ?? null, 15)
      } catch (e2) {
        console.error("football fallback present failed", e2)
      }
    }
  }
}

run()
